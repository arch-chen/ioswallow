<?php 	
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-27 01:44:13
 * @FilePath: \ioswallow\templates\share.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>		
<div class="d-block d-lg-none post-social-bottom text-center  wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.2s">
	<!-- 点赞 -->
	<?php iowen_like_button(get_the_ID());?>
	<!-- 点赞end -->
	
	<?php if(wp_is_mobile() && io_get_option('ioc_share')){ ?>
	<ul class="p-0">
		<?php
		$share_list = get_share_data();
		$share_item = io_get_option('i_share_item');
		foreach($share_item as $item){
			$d = $share_list[$item];
			echo '<li class="d-inline-block p-1" data-balloon="'.$d['title'].'" data-balloon-pos="up"><a class="btn btn-light w-40 p-0 rounded-circle '.$d['class'].'" rel="nofollow" href="'.$d['href'].'" '.$d['data'].' target="_blank"><i class="'.$d['ico'].'"></i></a></li>';
		}
		if(io_get_option('ioc_poster_cover')){
			$d = $share_list['cover'];
			echo '<li class="d-inline-block p-1" data-balloon="'.$d['title'].'" data-balloon-pos="up"><a class="btn btn-light w-40 p-0 rounded-circle '.$d['class'].'" rel="nofollow" href="'.$d['href'].'" '.$d['data'].' target="_blank"><i class="'.$d['ico'].'"></i></a></li>';
		}					
		$d = $share_list['clip'];
		echo '<li class="d-inline-block p-1" data-balloon="'.$d['title'].'" data-balloon-pos="up"><a class="btn btn-light w-40 p-0 rounded-circle '.$d['class'].'" href="'.$d['href'].'" '.$d['data'].'><i class="'.$d['ico'].'"></i></a></li>';
		?>	
	</ul>
	<?php } ?>
</div>