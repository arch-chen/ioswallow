<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-27 02:57:29
 * @FilePath: \ioswallow\templates\related.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="ws wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.3s" style="margin-top: 50px;">
    <h3><i class="iconfont icon-platform"></i><span class="noticom"> <?php _e('您可能感兴趣的','i_theme') ?></span></h3>
	<div class="related-posts">
		<div class="card-deck">
			<?php
			$post_num = 3;
			$exclude_id = $post->ID;
			$posttags = get_the_tags(); 
			$i = 0; 
			$w = 0;
			if ( $posttags ) {
				$tags = ''; foreach ( $posttags as $tag ) $tags .= $tag->term_id . ',';
				$args = array(
				'post_status' => 'publish',
				'tag__in' => explode(',', $tags),
				'post__not_in' => explode(',', $exclude_id),
				'ignore_sticky_posts' => 1,
				'orderby' => 'comment_date',
				'posts_per_page' => $post_num
				);
				$query = new WP_Query($args);
				while( $query->have_posts() ) { $query->the_post(); ?>
				<div class="custom-card">
					<div class="card bg-black text-white">
						<a href="<?php the_permalink(); ?>">
							<?php  echo io_get_thumbnail('medium','card-img') ?>
							<div class="card-img-overlay">
								<h4 class="card-title"><?php the_title(); ?></h4>
							</div>
						</a>
					</div>
					<?php io_related_meta() ?>
				</div>
				<?php
				$exclude_id .= ',' . $post->ID; $i ++;
				} 
				wp_reset_postdata();
			}
			if ( $i < $post_num ) {
				$cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
				$args = array(
				'category__in' => explode(',', $cats),
				'post__not_in' => explode(',', $exclude_id),
				'ignore_sticky_posts' => 1,
				'orderby' => 'comment_date',
				'posts_per_page' => $post_num - $i
				);
				$query = new WP_Query($args);
				while( $query->have_posts() ) { $query->the_post(); ?>
				<div class="custom-card">
					<div class="card bg-black text-white">
						<a href="<?php the_permalink(); ?>">
							<?php  echo io_get_thumbnail('medium','card-img') ?>
							<div class="card-img-overlay">
								<h4 class="card-title"><?php the_title(); ?></h4>
							</div>
						</a>
					</div>
					<?php io_related_meta() ?>
				</div>
				<?php $i++;
				} 
				wp_reset_postdata();
			}
			if ( $i == 0 )   {
				$month = date('m'); $year = date('Y'); 
				$args = array(
				'post_type' => 'post',
				'post__not_in' => explode(',', $exclude_id),
				'orderby' => 'comment_count',
				'order' => 'DESC',
				'year' => $year,
				'posts_per_page' => $post_num
				);
				$query = new WP_Query($args);
				while ($query->have_posts()) { $query->the_post(); ?>
				<div class="custom-card">
					<div class="card bg-black text-white">
						<a href="<?php the_permalink(); ?>">
							<?php  echo io_get_thumbnail('medium','card-img') ?>
							<div class="card-img-overlay">
								<h4 class="card-title"><?php the_title(); ?></h4>
							</div>
						</a>
					</div>
					<?php io_related_meta() ?>
				</div>
				<?php $w++;
				} 
				wp_reset_postdata();
			}
			if ( $i == 0 && $w == 0 ) {
				echo '<h4 class="card-title">'.__('暂无相关文章!','i_theme').'</h4>';
			}
			?>
		</div>
	</div>
</div>