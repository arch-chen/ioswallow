<?php
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-04 20:48:01
 * @FilePath: /ioswallow/templates/slider.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="thumbnail_canvas" class="swiper swiper-home wow fadeInUp" data-wow-duration="0.6s" data-wow-delay="0.3s" data-ride="carousel">
	<canvas id="header_canvas"style="position:absolute;bottom:0;z-index:2;pointer-events:none"></canvas>   
	<div class="swiper-wrapper">
		<?php
		$args  = array(
			'posts_per_page'      => io_get_option('banner_n'),
			'meta_key'            => '_slide_banner',
			'meta_query'          => array(
				'relation'     => 'AND',
				'slide_banner' => array(
					'key' => '_slide_banner',
				),
				'slide_order'  => array(
					'key' => '_slide_order',
				),
			),
			'orderby'             => array(
				'slide_order'  => 'DESC',
				'slide_banner' => 'DESC',
			),
			'ignore_sticky_posts' => 1
		);
		$query = new WP_Query($args);
		if(!$query->have_posts()){
			wp_reset_postdata();
			$args  = array(
				'posts_per_page'      => io_get_option('banner_n'),
				'ignore_sticky_posts' => 1
			);
			$query = new WP_Query($args);  
		}
		if ($query->have_posts()) : 
		while ($query->have_posts()) : $query->the_post();  
		?>
		<div class="swiper-slide">
			<a class="img-text-background" href="<?php the_permalink(); ?>">
				<?php echo '<img data-src="'.io_get_thumbnail_src('full').'" class="swiper-lazy d-block w-100 carousel-image" alt="'.get_the_title().'">'; ?>
			</a>
			<div class="carousel-caption d-block">
				<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
				<p class="d-none d-md-block text-sm">
					<a href="<?php the_permalink(); ?>"><?php echo io_strimwidth($post, 120) ?></a>
				</p>
			</div>
		</div> 
		<?php endwhile; endif; wp_reset_postdata();?> 
	</div>
	<div class="carousel-control-next"><i class="iconfont icon-arrow-right text-xxl" aria-hidden="true"></i></div>
    <div class="swiper-pagination"></div>
</div>