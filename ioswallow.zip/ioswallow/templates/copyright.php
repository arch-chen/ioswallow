<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-25 19:58:35
 * @FilePath: \ioswallow\templates\copyright.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="single-top-area clearfix wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.2s">
	<div class="author">
        <?php 
        //echo get_avatar( get_the_author_meta('email'), '64' ); 
        echo  get_avatar(get_the_author_meta('email'), 64); 
        ?>
        <div class="author-info">
        <?php $custom_fields = get_post_custom_keys();
        if (!in_array ('_copyright', $custom_fields)) : ?>
        <strong><?php _e('版权声明：','i_theme') ?></strong><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>" title="<?php bloginfo( 'name' ); ?>"><?php the_author_meta('nickname'); ?></a> <?php _e('发表于','i_theme') ?> <?php echo timeago(get_the_time('Y-m-d G:i:s')) ?>，<?php echo count_words('');?>。<br/>
        <strong><?php _e('转载请注明：','i_theme') ?></strong><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('本文固定链接','i_theme') ?> <?php the_permalink() ?>"><?php the_title(); ?> | <?php bloginfo('name');?></a>
        <?php else: ?>
        <?php  $custom = get_post_custom();
        $custom_value = $custom['_copyright']; 
        $custom_from = $custom['_from']; ?>
        <strong><?php _e('本文源自：','i_theme') ?></strong><a href="<?php echo $custom_value[0] ?>" target="_blank" rel="nofollow" > <?php echo $custom_from[0] ?></a>，<?php echo  sprintf(__('由%s于%s整理编辑，','i_theme'),'<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ) .'" title="'. get_bloginfo( 'name' ) .'">'. get_the_author_meta('nickname') .'</a>', timeago(get_the_time('Y-m-d G:i:s')) ) ?><?php echo count_words('');?>。<br/>
        <strong><?php _e('链接地址：','i_theme') ?></strong><a href="<?php the_permalink() ?> " rel="bookmark" title="<?php _e('本文固定链接','i_theme') ?> <?php the_permalink() ?>"><?php the_title(); ?> | <?php bloginfo('name');?></a>，<?php _e('转载请注明出处！','i_theme') ?>
        <?php endif; ?>
		</div>
	</div>
</div>
