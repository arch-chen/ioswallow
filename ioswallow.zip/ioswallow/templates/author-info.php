
<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:39
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-27 19:15:00
 * @FilePath: \ioswallow\templates\author-info.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
                    <div class="sidebar-author  wow <?php echo (wp_is_mobile()) ? 'fadeIn' : 'fadeInLeft' ?>" data-wow-duration="1s"  data-wow-delay="0.5s" >
                        <div class="theiaStickySidebar">
                            <div class="card card-sm author_meta">
                                <div class="author-avatar">
                                    <div class="flex-avatar mx-2 w-96 border border-3 border-white">
                                        <?php echo get_avatar(get_the_author_meta('email'), 96) ?>	      	    	
                                    </div>
                                </div>
                                <div class="author-meta text-center p-4">
                                    <div class="h6 mb-3"><?php echo get_the_author() ?><small class="d-block">
                                        <span class="badge badge-outline-primary mt-2">
                                            <?php $user_id=get_post($id)->post_author;
                                            if(user_can($user_id,'install_plugins')) {
                                                echo __('博主','i_theme');
                                            }elseif(user_can($user_id,'edit_others_posts')) {
                                                echo __('编辑','i_theme');
                                            }elseif(user_can($user_id,'publish_posts')) {
                                                echo __('作者','i_theme');
                                            }elseif(user_can($user_id,'delete_posts')) {
                                                echo __('投稿者','i_theme');
                                            }elseif(user_can($user_id,'read')) {
                                                echo __('订阅者','i_theme');
                                            }?>
                                        </span></small>
                                    </div>
                                    <div class="desc text-xs h-2x mb-3"><?php if(get_the_author_meta('description')){ echo the_author_meta( 'description' );}else{echo __('我还没有学会写个人说明！','i_theme'); }?></div>
                                    <div class="row no-gutters text-center" style="max-width: 200px;margin: 0 auto;">
                                        <a href="javascript:void(0);" class="col">
                                            <span class="font-theme font-weight-bold text-md"><?php ioo_postviews_round_number(the_author_posts()) ?></span></span><small class="d-block text-xs text-muted"><?php _e('文章','i_theme') ?></small>
                                        </a>
                                        <a href="javascript:void(0);" class="col">
                                            <span class="font-theme font-weight-bold text-md"><?php echo ioo_postviews_round_number(author_posts_comments( get_the_author_meta('ID') ,get_the_author_meta('user_email'))) ?></span><small class="d-block text-xs text-muted"><?php _e('评论','i_theme') ?></small>
                                        </a>
                                        <a href="javascript:void(0);" class="col">
                                            <span class="font-theme font-weight-bold text-md"><?php echo ioo_postviews_round_number(author_posts_likes(get_the_author_meta('ID'))) ?></span><small class="d-block text-xs text-muted"><?php _e('获赞','i_theme') ?></small>
                                        </a>
                                        <a href="javascript:void(0);" class="col">
                                            <span class="font-theme font-weight-bold text-md"><?php echo ioo_postviews_round_number(author_posts_views(get_the_author_meta('ID'))) ?></span><small class="d-block text-xs text-muted"><?php _e('浏览','i_theme') ?></small>
                                        </a>
                                    </div>
                                </div>
                                <div class="author-reward p-4">
                                    <div class="row row-sm">
                                        <div class="col">
                                            <?php if(io_get_option('reward_switcher')){ ?>
                                            <button class="btn vc-theme btn-shadow btn-block plus-power-popup" id="reward_btn"><i class="iconfont icon-creditcard-fill"></i><?php _e('给Ta赞赏','i_theme') ?></button>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>