<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-26 17:12:01
 * @FilePath: \ioswallow\templates\cms-top.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="io_cms_top" class="slice cms_top wow fadeInUp" data-wow-duration="0.6s" data-wow-delay="0.3s" >
	<div class="d-flex align-items-center mb-3 mb-md-4">
	<h2 class="slice-title m-0 text-xxl"><?php echo io_get_option('home_top_title', '推荐阅读') ?></h2>
	<?php if(io_get_option('home_top_pages')) : ?>
	<a class="move ml-auto" href="<?php echo get_permalink(io_get_option('home_top_pages')) ?>"><?php _e( '查看更多', 'i_theme' ); ?><i class="iconfont icon-arrow-right"></i></a>
	<?php endif; ?>
	</div>
	<?php $args =  array ( 
		//'meta_key' => '_cms_top', 
		'meta_query' => array(
			array(
				'key'     => '_cms_top',  
				'value'   => '',  
				'compare' => '!='
			)
		),
		'posts_per_page' => 3, 
		'post__not_in' => get_option( 'sticky_posts') 
	); 
	$query = new WP_Query($args);
	if ( !$query->have_posts() ) : ?> 
	<div class="text-center "> 
		<div class="nothing"> </div>
		<p><?php _e('没有推荐内容，请到文章开启推荐选项','i_theme'); ?></p>
	</div>
	<?php else : ?>
	<div class="io-card-deck">
		<?php while ($query->have_posts() ) : $query->the_post(); ?>
		<div class="top-card">
		<article class="card">
				<a href="<?php the_permalink(); ?>">
					<?php  echo io_get_thumbnail('medium','card-img') ?>
					<div class="card-img-overlay">
						<h3 class="card-title text-center overflowClip_1"><?php the_title(); ?></h3>
					</div>
				</a>
		</article>
		</div>
	<?php endwhile; ?>
	</div>
	<?php endif; ?>
	<?php wp_reset_postdata(); ?>
</div>
