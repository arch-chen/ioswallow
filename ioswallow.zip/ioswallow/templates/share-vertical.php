<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-24 14:32:51
 * @FilePath: \ioswallow\templates\share-vertical.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="post-social d-none d-lg-block wow fadeInLeft" data-wow-duration="1s"  data-wow-delay="0.8s" >
	<div class="theiaStickySidebar">
		<ul class="my-n2" style="list-style: none;margin: 0;padding: 0;">
			<?php iowen_like_button_vertical(get_the_ID());?>
			<?php if(io_get_option('comment_switcher',true)){ ?>
			<li class="py-1"><a href="javascript:;" class="to-comments btn btn-light w-40 p-0 rounded-circle"><i class="iconfont icon-news"></i><span class="count"><?php echo get_post($post->ID)->comment_count; ?></span></a></li>
			<?php } ?>
			<?php if(io_get_option('ioc_share')){ ?>
			<li class="py-1 mt-3"><span class="text-muted"><i class="iconfont icon-share"></i></span></li>
				<?php 
				$share_list = get_share_data();
				$share_item = io_get_option('i_share_item');
				foreach($share_item as $item){
					$d = $share_list[$item];
					echo '<li class="py-1" data-balloon="'.$d['title'].'" data-balloon-pos="left"><a class="btn btn-light w-40 p-0 '.$d['class'].'" rel="nofollow" href="'.$d['href'].'" '.$d['data'].' target="_blank"><i class="'.$d['ico'].'"></i></a></li>';
				}
				if(io_get_option('ioc_poster_cover')){
					$d = $share_list['cover'];
					echo '<li class="py-1" data-balloon="'.$d['title'].'" data-balloon-pos="left"><a class="btn btn-light w-40 p-0 '.$d['class'].'" rel="nofollow" href="'.$d['href'].'" '.$d['data'].' target="_blank"><i class="'.$d['ico'].'"></i></a></li>';
				}					
				$d = $share_list['clip'];
				echo '<li class="py-1" data-balloon="'.$d['title'].'" data-balloon-pos="left"><a class="btn btn-light w-40 p-0 '.$d['class'].'" href="'.$d['href'].'" '.$d['data'].'><i class="'.$d['ico'].'"></i></a></li>';
				?>
			<?php } ?>
		</ul>
	</div>
</div>