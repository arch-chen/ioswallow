<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-07 09:15:27
 * @FilePath: /ioswallow/templates/header-normal.php
 * @Description: 默认
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$type = io_get_option('head_region');
switch($type){
	case 'normal':
		$layout = 'flex-column';
		$logo = 'align-items-center';
		$is_ico = true;
		break;
	case 'centered':
		$layout = 'flex-column align-items-center';
		$logo = 'align-items-center';
		$is_ico = false;
		break;
	case 'tradition': // 传统
		$layout = 'align-items-center';
		$logo = 'align-items-center';
		$is_ico = false;
		break;
	default:
}

?>
<header id="header" class="header-<?php echo $type ?>">
	<div class="container custom-width">
		<nav class="header-layout d-flex <?php echo $layout ?>" data-layout="<?php echo $layout ?>">
			<div class="header-logo d-flex <?php echo $logo ?>">
				<?php getLogo() ?>
				<?php if ($is_ico) { ?>
				<div class="social-group ml-3 pl-2">
				<?php echo io_get_menu_ico('menu') ?>
				</div>
				<?php } ?>
				<div class="offcanvas-menu-button ml-auto" data-toggle="nav" data-target=".mobile-nav" aria-expanded="false" ><i class="iconfont icon-menu1"></i></div>
			</div>
			<div class="main-navigation">
				<ul class="menu">
				<?php io_wp_menu('main');?>
				</ul>
			</div>
		</nav>
		
		<?php if(io_get_option('ad_home_top')) { ?>
			<?php if(io_get_option('ad_home_top_onlyhome')) { 
				if(is_home() || is_front_page() ){?>
				<div class="post-ad mt-4"><?php echo stripslashes( io_get_option('ad_home_top_c') ); ?></div>
			<?php } ?>
			<?php }else{ ?>
				<div class="post-ad mt-4"><?php echo stripslashes( io_get_option('ad_home_top_c') ); ?></div>
		<?php }} ?> 
	</div>
</header>
<div class="mobile-header">
	<nav class="mobile-nav">
		<ul class="menu">
		<?php io_wp_menu('main', 'mobile-nav-arrow');?>
		</ul>
		<div class=" text-center my-3">
		<?php echo io_get_menu_ico('menu') ?>
		</div>
	</nav>
	<div class="fixed-body" data-toggle="nav" data-target=".mobile-nav" aria-expanded="false"></div>
</div>