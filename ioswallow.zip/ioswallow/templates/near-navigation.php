<?php 
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-25 20:01:39
 * @FilePath: \ioswallow\templates\near-navigation.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="near-navigation wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.3s">
	<?php
	$current_category = get_the_category();//获取当前文章所属分类ID
	$prev_post = get_previous_post($current_category,'');//与当前文章同分类的上一篇文章
	$next_post = get_next_post($current_category,'');//与当前文章同分类的下一篇文章
	?>
	<?php if (!empty( $prev_post )) { ?>
	<div class="nav previous">
		<?php io_theme_near_image($prev_post);?>
		<span><?php _e('上一篇','i_theme') ?></span>
		<h4 class="near-title"><?php echo $prev_post->post_title; ?></h4>
		<a class="near-permalink" href="<?php echo get_permalink( $prev_post->ID ); ?>"></a>
	</div>
	<?php } else { ?>
	<div class="nav none">
		<span><?php _e('上一篇','i_theme') ?></span>
		<h4 class="near-title"><?php _e('没有更多了...','i_theme') ?></h4>
	</div>
	<?php } ?>
	<?php if (!empty( $next_post )) { ?>
	<div class="nav next">
		<?php io_theme_near_image($next_post);?>
		<span><?php _e('下一篇','i_theme') ?></span>
		<h4 class="near-title"><?php echo $next_post->post_title; ?></h4>
		<a class="near-permalink" href="<?php echo get_permalink( $next_post->ID ); ?>"></a>
	</div>
	<?php } else { ?>
	<div class="nav none" style="text-align: right;">
		<span><?php _e('下一篇','i_theme') ?></span>
		<h4 class="near-title"><?php _e('没有更多了...','i_theme') ?></h4>	
	</div>
	<?php } ?>
</div>