<?php 
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-24 17:02:20
 * @FilePath: /ioswallow/templates/cat-list.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<main id="content" class="container custom-width">   
	<div class="site-title wow fadeIn" data-wow-duration="0.6s" data-wow-delay="0.3s">
	<?php if ( is_category() ) { ?>
		<?php $thiscat = get_category($cat); ?>
		<h1 class="text-xxl slice-title"><span class="archive-m-line"><?php echo $thiscat ->name;?></span></h1>
		<p>
			<?php echo category_description(); ?>
		</p>
	<?php } ?>
	<?php if ( is_tag() ) { ?>
		<h1 class="text-xxl slice-title"><span class="archive-m-line"><?php _e('标签：','i_theme'); ?><?php single_cat_title(); ?></span></h1>
		<p>
			<?php echo category_description(); ?>
		</p>
	<?php } ?>
	<?php if ( is_search() ) { ?>
		<?php echo io_search_body_html() ?>
		<h1 class="text-xxl slice-title"><span class="archive-m-line">“<?php echo $s; ?>” <?php _e('的搜索结果','i_theme'); ?></span></h1>
		<?php if ( !have_posts() ) : ?>
			<div class="text-center bg-muted border-radius py-5"> 
				<i class="iconfont icon-nothing3 text-64"> </i>
				<div class="mt-3 text-muted"><?php _e('没有找到相关的内容','i_theme'); ?></div>
			</div>
		<?php endif; ?>
	<?php } ?>
	<?php if ( is_author() ) { ?>
		<h1 class="text-xxl slice-title"><span class="archive-m-line"><?php _e('作者：','i_theme'); ?><?php echo get_the_author() ?></span></h1>
		<div class="taxonomy-description"><?php if(get_the_author_meta('description')){ echo the_author_meta( 'description' );}else{echo __('我还没有学会写个人说明！','i_theme'); }?></div>
	<?php } ?>
	
	</div>
	<div class="ioc_cat_list archive-list">
		<?php 
		if ( have_posts() ) : while (have_posts()):
			the_post();
			io_get_archive_list();
		endwhile; endif;
		?>
	</div>
	<?php //io_page_nav()?> 
</main>
<?php io_post_archive_nav() ?>