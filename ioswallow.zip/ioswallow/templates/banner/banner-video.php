<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:41
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-07 09:17:02
 * @FilePath: /ioswallow/templates/banner/banner-video.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<main class="container custom-width"> 
			<div class="single-thumbnail-card video-card wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.5s">
				<div class="video">
					<video class="breek-video" style="width: 100%;" src="<?php  echo get_post_meta( get_the_ID(), '_top_video', true ) ?>"  poster="<?php  echo io_get_thumbnail('full','',true) ?>" controls="controls"></video>
				</div> 
				<div class="card-video-info p-3">
					<div class="d-flex align-items-center">
						<div class="category text-xs">
							<?php  get_breadcrumbs('m-0') ?>
						</div>
						<div class="text-muted ml-auto text-sm">
						<span class="date"><i class="iconfont icon-time"></i> <?php echo timeago(get_the_time('Y-m-d G:i:s')) ?></span>
						<?php if(io_get_option('post_views',false)) : ?><span class="date ml-2"><i class="iconfont icon-eye"></i> <?php the_views(); ?></span><?php endif; ?>
						<?php edit_post_link(__('编辑','i_theme'), '<span class="edit-link ml-2">', '</span>' ); ?>
						</div>
					</div>
					<h1 class="text-lg mt-3 mb-0"><i class="iconfont icon-video mr-2" aria-hidden="true"></i><b><?php the_title(); ?></b></h1>
				</div>
			</div>