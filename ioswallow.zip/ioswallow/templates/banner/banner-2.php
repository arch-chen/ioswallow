<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:41
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-07 09:16:29
 * @FilePath: /ioswallow/templates/banner/banner-2.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="thumbnail_canvas" class="single-thumbnail-pass wow fadeIn" data-wow-duration="1s"  data-wow-delay="0.5s" style="background-image: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('<?php  echo io_get_thumbnail('full','',true) ?>')">
	<canvas id="header_canvas"style="position:absolute;bottom:0"></canvas>	
	<div class="container custom-width">
		<div class="single-thumbnail-pass-inside d-flex align-items-end">
			<div class="single-title-zone">
				<div class="category text-xs">
					<?php  
						if(io_get_option('shuoshuo') && get_post_type() == 'shuoshuo'){
							echo '<a class="text-light" href="'.get_permalink(io_get_option('shuoshuo_pages')).'">'.__('微语','i_theme').'</a>';
						}
						else{
							get_breadcrumbs('m-0');
						}
					?>
				</div>
				<h1><?php the_title(); ?></h1>
				<div class="text-muted text-sm mb-3">
				<span class="date"><i class="iconfont icon-time"></i>&nbsp;<?php echo timeago(get_the_time('Y-m-d G:i:s')) ?> &nbsp;&nbsp;
				<?php if(io_get_option('post_views')) : ?><i class="iconfont icon-eye"></i>&nbsp;<?php the_views(); ?>&nbsp;&nbsp;<?php endif; ?></span>
				<?php edit_post_link(__('编辑','i_theme'), '<span class="edit-link">', '</span>' ); ?>
				</div>
			</div>
		</div>
	</div>
</div>

<main class="container custom-width">