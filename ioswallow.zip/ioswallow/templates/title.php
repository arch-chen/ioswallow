<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-27 01:46:24
 * @FilePath: \ioswallow\templates\title.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } 


global $paged, $page, $post; 
$linker 		= io_get_option('io_seo_title_sep') ? : ' | ';
$title 			= '';
$title_after 	= $linker . get_bloginfo('name');
$keywords		= io_get_option('io_home_keywords');
$description	= io_get_option('io_home_description');
$type 			= 'article';
$url 			= home_url();
$img 			= io_get_option("og_home_img")? : get_theme_file_uri('/screenshot.png');

if( is_home() || is_front_page() ){
	$title 			= io_get_option('io_home_title') ? : get_bloginfo('name');
	$title_after 	= $linker . get_bloginfo('description');
	$type 			= 'website'; 
}
if( is_single() || is_page() ) {
	$id		= get_the_ID();
	$title 	= get_post_meta($id, '_title', true) ? : get_the_title();
	$tag 	= '';
	$tags	= get_post_meta($id, '_keywords', true) ? : get_the_tags();
	$url 	= get_permalink();
	$img 	= io_theme_get_thumb();
	
	$excerpt = io_get_excerpt( io_get_option('io_auto_description_num') ); 
	
	if( $tags && is_array($tags)){
		foreach($tags as $val){
			$tag.=','.$val->name;
		}
		$tag=ltrim($tag,',');
	}else{
		$tag = $tags;
	}
	if( $tag!="" ) $keywords=$tag;
	
	if( !empty($excerpt)) $description=$excerpt;
}
if( is_category() ){ 
	$cat_id = get_query_var('cat');
	$url 	= get_category_link($cat_id);
	$meta 	= get_term_meta( $cat_id, 'category_meta', true );
	if($meta && $meta['seo_title'])
		$title = $meta['seo_title'];
	else
		$title = single_cat_title("", false);
	if($meta && $meta['seo_metakey'])
		$keywords=$meta['seo_metakey'];
	else
		$keywords=single_cat_title('', false).','.get_bloginfo('name');
	if($meta && $meta['seo_desc'])
		$excerpt = $meta['seo_desc'];
	else
		$excerpt = category_description(); 
	if($excerpt!='')
		$description = $excerpt;
}
if( is_tag() ){ 
	$tag_id=get_query_var('tag_id');
	$url = get_tag_link($tag_id);	
	$meta = get_term_meta( $tag_id, 'post_tag_meta', true );  
	if($meta && $meta['seo_title'])
		$title = $meta['seo_title'];
	else
		$title = single_tag_title("", false);
	if($meta && $meta['seo_metakey'])
		$keywords=$meta['seo_metakey'];
	else
		$keywords=single_tag_title('', false).','.get_bloginfo('name');
	if($meta && $meta['seo_desc'])
		$excerpt = $meta['seo_desc'];
	else
		$excerpt = strip_tags(trim(tag_description()));  
	if($excerpt!='')
		$description = $excerpt;
}


if( is_search() ) {
	$title = sprintf( __('%s的搜索结果', 'i_theme'), '&#8220;'. htmlspecialchars($s) .'&#8221;' );
	$keywords= $s.','.get_bloginfo('name');
	$description= io_get_option('seo_home_desc');
} 
if ( is_year() ) 	$title = sprintf( __('“%s”年所有文章', 'i_theme'), get_the_time('Y') ) ; 
if ( is_month() ) 	$title = sprintf( __('“%s”份所有文章', 'i_theme'), get_the_time('F') )  ; 
if ( is_day() ) 	$title = sprintf( __('“%s”所有文章', 'i_theme'), get_the_time(__('Y年n月j日', 'i_theme')) ) ;
if ( is_author() ) 	$title = sprintf( __('“%s”发表的所有文章', 'i_theme'), get_the_author() ) ;
if ( is_404() ) 	$title = __('没有你要找的内容', 'i_theme'); 

if ( ( $paged >= 2 || $page >= 2 )  )
	$title = $title.$linker.sprintf( __('第 %s 页', 'i_theme'), max( $paged, $page ) );


if($custom_page = get_query_var('io_custom_page')){ 
	switch ($custom_page) {
		case 'down':
			$id    = $_GET['id'];
			$title = get_post($id)->post_title.__('-下载页', 'i_theme');
			break;
	}
}
?>
<title><?php echo $title . $title_after  ?></title>
<meta name="theme-color" content="<?php echo (theme_mode()=="ioc-dark-mode"?'#2C2E2F':'#f9f9f9') ?>" />
<meta name="keywords" content="<?php echo $keywords ?>" />
<meta name="description" content="<?php echo esc_attr(stripslashes($description)) ?>" />
<meta property="og:type" content="<?php echo $type ?>">
<meta property="og:locale" content="<?php echo get_bloginfo( 'language' ); ?>" />
<meta property="og:url" content="<?php echo $url ?>"/> 
<meta property="og:title" content="<?php echo $title . $title_after ?>">
<meta property="og:description" content="<?php echo $description ?>">
<meta property="og:image" content="<?php echo $img ?>">
<meta property="og:site_name" content="<?php bloginfo('name') ?>">
