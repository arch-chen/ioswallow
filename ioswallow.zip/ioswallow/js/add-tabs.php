<!DOCTYPE HTML>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>图文模块</title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<style>
.form-table{border-collapse: collapse;margin-top: .5em;width: 95%;clear: both;margin-left: 1rem;}
.form-table th {vertical-align: top;text-align: left;padding: 10px 10px 10px 0;width: 200px;line-height: 1.3;font-weight: 600;}
.form-table input{margin: 1px;padding: 3px 5px;}
.submitbox {padding: 8px 16px;background: #fcfcfc;border-top: 1px solid #dfdfdf;position: fixed;bottom: 0;left: 0;right: 0;}
#wp-link-cancel {line-height: 25px;float: left;}
.submitbox .submitdelete {text-decoration: none;padding: 1px 2px;color: #a00;}
#wp-link-update {line-height: 23px;float: right;}
.button-primary {display: inline-block;font-size: 13px;line-height: 26px;height: 28px;margin: 0;padding: 1px 15px ;cursor: pointer;border-width: 0px;-webkit-border-radius: 3px;border-radius: 3px;background: #3ca3ff;color: #fff;}
#wp-link-submit{float: right;margin-bottom: 0;}
</style>
</head>	
<body>
<form onsubmit="InsertValue();return false;" id="form-table">

<div id="wplist_tips"></div>

<table class="form-table">
	<tr>
		 <th style="width: 20%;"><label for="post_title">标题</label></th>
		<td><input type="text" name="post_title" id="post_title" value="标题" size="30" tabindex="30" style="width: 80%;" /></td>
	</tr>
	<tr>
		<th style="width: 20%;"><label for="btn">序号</label></th>
		<td><input type="text" name="wp[btn]" id="btn" value="1" size="30" tabindex="30" style="width: 80%;" /></td>
	</tr>

</table>
<p style="color: #ff2222;">请注意序号的唯一性<br>需添加标签请复制[wptab][/wptab]短代码</p>
<div class="submitbox">
	<div id="wp-link-cancel">
		<a class="submitdelete" href="javascript:window.parent.tinyMCE.activeEditor.windowManager.close();">取消</a>
	</div>
	<div id="wp-link-update">
		<input type="submit" value="插入" class="button button-primary" id="wp-link-submit" name="wp-link-submit">
	</div>
</div>

</form>

<script type="text/javascript">
function getId(e) {
	return document.getElementById(e)
}
function InsertValue() { 
	var title = getId("post_title").value;
	var btn = getId("btn").value;
	html = '[start_tab]<p>[wptab number="' + btn + '" title="' + title + '"  ]' + '编辑添加内容' + '[/wptab]</p><p>[wptab number="2" title="标签2"  ]' + '标签2内容' + '[/wptab]</p>[end_tab]';
	window.parent.tinyMCE.activeEditor.execCommand('mceInsertContent', 0, html);
	window.parent.tinyMCE.activeEditor.windowManager.close()
}
</script>
</body>
</html>