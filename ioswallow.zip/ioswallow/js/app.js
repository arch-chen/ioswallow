/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-12-29 16:03:56
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-24 17:29:02
 * @FilePath: /ioswallow/js/app.js
 * @Description: 
 */
"use strict";
const waitForLoad = new Promise(resolve => {
    if (document.readyState === 'complete') {
        resolve();
    } else {
        window.addEventListener('load', resolve);
    }
});
jQuery.cookie = function (cookieName, cookieValue, expirationDays) {
	const date = new Date();
	date.setTime(date.getTime() + (expirationDays * 24 * 60 * 60 * 1000));
	const expires = `expires=${date.toUTCString()}`;
	document.cookie = `${cookieName}=${cookieValue}; ${expires}; path=/`;
};
(function($){ 
	$(document).ready(function() {
		switch_mode(false);
		sticky_sidebar($('.post-social'),90,200);
		sticky_sidebar($('.sidebar-author'),120,20);
		sticky_sidebar($('.small-menu'),90,50);
		if ($("#small-menu-ul")[0]) load_menu();
		rotate_elements('.io-card-deck .top-card');
        // 粘性页脚
		stickFooter();
		load_post_btn();
	});
	// 点赞
	$(document).on("click",'.like', function(e) {
		var _this =$(this);
		if (_this.hasClass('liked')) {
			iPopupTips(0, localize.liked);
		} else {
			_this.addClass('liked');
			$.ajax({
				url : Theme.ajaxurl, 
				data : {
					action: "post_like",
					post_id: _this.data("id")
				},
				type : 'POST',
				success : function( data ){
					iPopupTips(1, localize.like);
					if(_this.hasClass('ss-favorite'))
						_this.children('.count').html(data);
					else
						$('.like').addClass('liked').children('.count').html(data);
				},
				error: function(error) {
					iPopupTips(0, error.statusText);
					_this.removeClass('liked');
				}
			});
		}
		return false;
	});
	$(document).on("click",'a.down_count', function(e) { 
		$.ajax({
			type:"POST",
			url:Theme.ajaxurl,
			data: $(this).data(),
			success : function( data ){
				$('.down-count-text').html(data);
			}
		});
	});
    // 提交链接
    $(".io-add-link-form").on("submit", function() {
        var t = $(this); 
        $.ajax({
            url: Theme.ajaxurl,
            type: 'POST', 
            dataType: 'json',
            data : t.serialize(),
        })
        .done(function(response) { 
            iPopupTips(response.status,response.msg);  
			return;
            if(response.status !=1){
                iPopupTips(response);
                return;
            }
        })
        .fail(function() {  
            iPopupTips(0, localize.networkerror);  
            return;
        })
        return false;
    });
	//夜间模式
	$(document).on("click", ".switch-dark-mode", function(event) {
		event.preventDefault();
		$("html").toggleClass("ioc-dark-mode");
		switch_mode(true);
	});
	function switch_mode(set_cookie){
		if($("html").hasClass("ioc-dark-mode") === true){
			if(set_cookie) setCookie('io_night_mode',0,30);
			$(".theme-mode").attr("data-balloon", localize.lightMode);
			$(".mode-ico").removeClass("icon-moon");
			$(".mode-ico").addClass("icon-sun");
		}else{
			if(set_cookie) setCookie('io_night_mode',1,30);
			$(".theme-mode").attr("data-balloon", localize.nightMode);
			$(".mode-ico").removeClass("icon-sun");
			$(".mode-ico").addClass("icon-moon");
		}
	}
	function themeChange() {
		try {
            var night = getCookie('io_night_mode');
			if (night === "0" || (!night && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
				document.documentElement.classList.add("ioc-dark-mode");
			} else {
				document.documentElement.classList.remove("ioc-dark-mode");
			}
			switch_mode(false);
		} catch (_) {}
	}
	const mediaQueryListDark = window.matchMedia("(prefers-color-scheme: dark)");
	mediaQueryListDark.addEventListener("change", themeChange);

    $(".container .post img:not(.unfancybox)").each(function(i) {
        var _this = $(this);
        if (Theme.is_box=="1" && !_this.hasClass('wp-smiley') && !this.parentNode.href) {
            if(Theme.lazyload == '1')
                _this.wrap("<a class='js' href='" + _this.data('src') + "' data-fancybox='fancybox' data-caption='" + this.alt + "'></a>");
            else
                _this.wrap("<a class='js' href='" + this.src + "' data-fancybox='fancybox' data-caption='" + this.alt + "'></a>");
        }
    });
	if(is_function('Swiper')){
	var swiper = new Swiper(".post-img-swiper", {
		autoplay: {
			disableOnInteraction: false,
		},
        slidesPerView: "auto",
        spaceBetween: 10, 
		centeredSlides: true, //居中
		centeredSlidesBounds: true,
        pagination: {
			el: ".swiper-pagination",
			clickable: true,
        },
        navigation: {
			nextEl: ".swiper-button-next",
			prevEl: ".swiper-button-prev",
        },
    });
	var swiper_home = new Swiper(".swiper-home", {
		autoplay: {
			disableOnInteraction: false,
		},
		lazy: {
			loadPrevNext: true,
		},
        slidesPerView: 1,
        loop: true,
        pagination: {
			el: ".swiper-pagination",
			clickable: true,
        },
        navigation: {
			nextEl: ".carousel-control-next",
        },
		on:{
			init:function(swiper){
				var slide=this.slides.eq(0);
				slide.addClass('ani-slide');
			},
			transitionStart: function(){
				for(var i=0;i<this.slides.length;i++){
					var slide=this.slides.eq(i);
					slide.removeClass('ani-slide');
				}
			},
			transitionEnd: function(){
				var slide=this.slides.eq(this.activeIndex);
				slide.addClass('ani-slide');
			},
		}
    });
	}
	$(document).on("click", ".btn-bigger-cover", function(event) {
		event.preventDefault();
		var t = $(this);
		var _cover = iPopup("cover", '<div class="image-loading"><i></i></div>', "background:rgba(0,0,0,0.5);");
		$.ajax({
			url: Theme.ajaxurl,
			type: "POST",
			dataType: "json",
			data: t.data()
		}).done(function(response) {
			200 == response.s ? _cover.find(".ioc-bomb-content").html(response.html) : ($(_cover).remove(), iPopupTips(0, response.m))
		}).fail(function() {
			$(_cover).remove();
			iPopupTips(0, localize.networkerror);
		})
	});
	$(function() {
		var text = document.querySelectorAll(".copy_url"),
		clipboard = new ClipboardJS(text);
		clipboard.on("success", function() {
			iPopupTips(1, localize.copied)
		});
		clipboard.on("error", function() {
			iPopupTips(0, localize.uncopied)
		})
	});
	//关闭窗口
	$(document).on("click",'.poster-close, .poster-back',function() {
		$(".poster-back").removeClass("poster-open");
		$(".poster-share").removeClass("poster-open");
		$(".poster-share").removeClass("open");
	});
	$(".btn-open-share").on("click", function(event) {
		event.preventDefault();
		$('.poster-right').addClass('open');
		$('.btn-open-share').hide();
		$('.poster-close').hide();
		$('.btn-close-share').show()
	});
	$(".btn-close-share").on("click", function(event) {
		event.preventDefault();
		$('.btn-close-share').hide();
		$('.poster-right').removeClass('open');
		$('.poster-right').addClass('close');
		$('.btn-open-share').show();
		$('.poster-close').show();
		setTimeout(function() {
				$('.poster-right').removeClass('close')
		}, 200)
	}); 
	//微信分享
	$(document).on("click", '.single-popup', function(event) {
		event.preventDefault();
		var img = $(this).data("img");
		var title = $(this).data("title");
		var desc = $(this).data("desc");
		var html = '<div class="text-center"><h6 class="py-2">' + title + '</h6>\
					<img src="' + img + '" alt="' + title + '" style="width:100%;height:auto;">\
					<p class="text-muted text-xs">('+ desc +')</p></div>'
		iPopup('small', html)
	});

	$(document).on("click ", "#reward_btn",function(event) {
		event.preventDefault();
		var reward = iPopup("reward", '<div class="image-loading"><i></i></div>', "background:rgba(0,0,0,0.5);");
		$.ajax({
			url: Theme.ajaxurl,
			data: {
				action: "show_reward"
			},
			type: "POST",
			dataType: "html"
		}).done(function(response) {
			reward.find(".ioc-bomb-content").html(response);
		}).fail(function() {
			$(reward).remove();
			iPopupTips(0, localize.networkerror);
		})
	});
	$(document).on("click ", "#reward_popup ul.platform li", function() {
		$("#reward_popup ul.platform li").each(function() {
			$(this).removeClass("active")
		}),
		$("#reward_popup div.qrcode .qrcode-li").each(function() {
			$(this).hide()
		}),
		$(this).addClass("active");
		var type = $(this).attr("data-type"),
		bgColor = $(this).attr("data-bg-color"),
		thanks = $(this).attr("data-thanks");
		$("#reward_popup").css("background-color", bgColor);
		$("#reward_popup .head").html(thanks);
		$("#reward_popup div.qrcode div." + type).each(function() {
			$(this).show()
		})
	});
	/* 回到顶部按钮 */
	$(function() {
		var offset = 300,
		offset_opacity = 200,
		scroll_top_duration = 700,
		$back_to_top = $('.buttontop-top');
		$(window).scroll(function() { ($(this).scrollTop() > offset) ? $back_to_top.addClass('buttontop-is-visible') : $back_to_top.removeClass('buttontop-is-visible buttontop-fade-out');
			if ($(this).scrollTop() > offset_opacity) {
				$back_to_top.addClass('buttontop-fade-out')
			}
		});
		$back_to_top.on("click", function(event) {
			event.preventDefault();
			$('body,html').animate({
				scrollTop: 0,
			},
			scroll_top_duration)
		})
	});
	
	$(".to-comments").click(function() {
		$("html,body").animate({
			scrollTop: $("#comments").offset().top-80
		},800)
	});
	$(".smooth").click(function() {
		$("html,body").animate({
			scrollTop: $($(this).attr("href")).offset().top - 100
		}, 1e3);
		return false;
	});


	/**1111111111111111111111111111111111111111111 */
	function sticky_sidebar(sidebar,top,bottom){
		sidebar.theiaStickySidebar({ 
			additionalMarginTop: top,
			additionalMarginBottom: bottom,
			defaultPosition: 'absolute'
		});
	}
	// 循环轮播
	function rotate_elements(selector) {
		var elements = $(selector);
		if (elements.length === 0) {
			return;
		}
		var index = 0;
		var auto;
		function show(index) {
			elements.removeClass('show').eq(index).addClass('show');
		}
		function set_auto() {
			auto = setTimeout(function () {
				index = (index + 1) % elements.length;
				show(index);
				set_auto();
			}, 3500);
		}
		if ('ontouchstart' in window || navigator.msMaxTouchPoints) {
			var startX = 0;
			var moveX = 0;
			elements.on('touchstart', function (event) {
				startX = event.originalEvent.touches[0].clientX;
				clearTimeout(auto);
			});
			elements.on('touchmove', function (event) {
				moveX = event.originalEvent.touches[0].clientX;
			});
			elements.on('touchend', function () {
				var diffX = moveX - startX;
				if (diffX > 50) {
					index = (index - 1 + elements.length) % elements.length;
					show(index);
				} else if (diffX < -50) {
					index = (index + 1) % elements.length;
					show(index);
				}
				set_auto();
			});
		}
		show(index);
		set_auto();
	}
	
    //粘性页脚
    function stickFooter() {
        var main_footer = $('.main-footer');
        main_footer.attr('style', '');
        if(main_footer.hasClass('footer-stick'))
        {
            var win_height          = jQuery(window).height(),
                footer_height       = main_footer.outerHeight(true),
                main_content_height = main_footer.position().top + footer_height ;
            if(win_height > main_content_height - parseInt(main_footer.css('marginTop'), 10))
            {
                main_footer.css({
                    marginTop: win_height - main_content_height  
                });
            }
        }
	}
	
	function load_menu() {
		var index = 1,
		_index = 1,
		menu = new Array,
		first_level = 10;//第一级目录 H level
		menu[0] = 0;
		var _html = "",
		_menu = new Array;
		$(".entry-content>:header").each(function() {
				var _title = $(this).eq(0).prop("tagName").replace("H", "");
				var leaf = "";
				var ico = "";
				if(_title <= first_level)
					first_level = _title;//确定第一级目录
				if(_title - first_level <= 1 ) {//构建两级
					if(_title > first_level){
						ico = '<i class="iconfont icon-circle-o" aria-hidden="true"></i>';
						leaf = "leaf-" + (_title - first_level)
					}else{
						ico = '<i class="iconfont icon-dot-circle-o" aria-hidden="true"></i>';
						leaf = ""
					}
					_html += '<li id="ti' + index + '" class="' + leaf + '"><a href="javascript:;">' + ico + "<span>" + $(this).eq(0).text().trim() + "</span></a></li>";
					$(this).eq(0).attr("id", "in" + index);
					$(this).eq(0).addClass("link");
					menu[index] =$(this).eq(0).offset().top;
					index++;
					_menu.push(parseInt(_index++))
				}
		}); 
		if(index > 2) {
			$("#small-menu-ul").html(_html),
			$(".small-menu-body").css("display", "unset");
			var leaf_id = 0,
			_leaf_id = 0;
			$(window).scroll(function() {
				for (var a = $(this).scrollTop() + 75, e = 1e4, o = 0; o < _menu.length; o++) {
					var i = Math.abs($("#in" + _menu[o]).offset().top - a);
					if(e > i && $("#in" + _menu[o]).offset().top < a){
						e = i;
						leaf_id = _menu[o]
					}
					if( _menu[0] == leaf_id && $("#in" + leaf_id).offset().top > a ){
						leaf_id = 0
					}
				}
				if(leaf_id != 0 && leaf_id != _leaf_id ) {
					if( _leaf_id != 0 )
						$("#ti" + _leaf_id).removeClass("active");
					_leaf_id = leaf_id;
					$("#ti" + _leaf_id).addClass("active");
				} else { 
					if( leaf_id == 0 && _leaf_id == 1 ) {
						$("#ti" + _leaf_id).removeClass("active");
						_leaf_id = 0;
					}
				}
			})
		} else $(".small-menu").remove();
		$("#small-menu-ul li").click(function() {
			$("html,body").animate({
				scrollTop: $("#in" + $(this).eq(0).attr("id").replace("ti", "")).offset().top - 70
			}, 800)
		})
	}
	/**1111111111111111111111111111111111111111111 */

	
	/*手机导航*/
	$(document).on("click", ".mobile-nav .mobile-dropdown-arrow", function (event) {
		event.stopPropagation();
		$(this).siblings('ul').slideToggle(200);
		return false;
	});
	$(document).on("click", '[data-toggle=nav]', function () {
		var c = 'show';
		var e = $(this).attr('data-target') || this;
		return $(e).toggleClass(c), !1;
	});
	
	if ($('.scrolling-hide').length) {
		$(window).scroll(debounce(function () {
			$('body').addClass('scroll-ing');
		}, 500, true)).scroll(debounce(function () {
			$('body').removeClass('scroll-ing');
		}, 500));
	}
	
    $(window).resize(debounce(function() {
        stickFooter(); 
    },500));
	
	/*粘性导航*/
	$(function() {
		var scrollTimeOut = true,
			lastYPos = 0,
			yPos = 0,
			yPosDelta = 5,
			nav = $("#header"),
			layout = $(".header-layout"),
			navHeight = nav.outerHeight();
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				nav.addClass('header-fixed blur-bg'); 
				layout.removeClass("flex-column").addClass("align-items-center"); 
			} else {
				nav.removeClass('header-fixed blur-bg'); 
				layout.removeClass("align-items-center").addClass(layout.data("layout")); 
			}
		});
		var setNavClass = function() {
			scrollTimeOut = false;
			yPos = $(window).scrollTop();
			if (Math.abs(lastYPos - yPos) >= yPosDelta) {
				if (yPos > lastYPos && yPos > navHeight) {
					nav.removeClass('show'); 
				} else {
					nav.addClass('show'); 
				}
				lastYPos = yPos
			}
		};
		$(window).scroll(function(e) {
			scrollTimeOut = true
		});
		setInterval(function() {
			if (scrollTimeOut) {
				setNavClass()
			}
		},
		500)
	});
	
	$(function() {
		var wait; 
		if(! 0 === $("#whisper").hasClass("show")) {
			if("1" == sessionStorage.getItem("whispershow")){
				$("#whisper").removeClass("show");
			}else{ 
				setTimeout(function() {
					$("#whisper").toggleClass("unavailable");
					$("#whisper").removeClass("show");
					wait = setTimeout(function() {
						$("#whisper").toggleClass("unavailable")
					},1e4)
				},1e3)
			}
		}
		$(document).on("click", ".shuoshuo_box", function() {
			$("#whisper").toggleClass("unavailable");
			if(!0 === $("#whisper").hasClass("unavailable")){
				$(this).children("i").removeClass("fa-times");
				$(this).children("i").addClass("fa-sign-language");
			}else{
				$(this).children("i").removeClass("fa-sign-language");
				$(this).children("i").addClass("fa-times");
			}
			sessionStorage.setItem("whispershow", "1");
			clearTimeout(wait);
		})
	});
	//清空搜索关键词
	$(document).on('click', '.trash-history-search', function (e) {
		if (confirm("确认要清空全部搜索记录？") == true) {
			$('.search-keywords-box').slideUp().delay(1000, function () {
				$(this).remove();
			});
			$.cookie('io_history_search', '');
		}
	});
	waitForLoad.then(() => {
		$('[auto-load]').click();
	});
	$(document).on('click', '[auto-load]', function (e) {
		var _this = $(this);
		var remote = _this.data('box');
		if (remote) {
			$.get(remote, null, function (data, status) {
				_this.html(data).removeAttr('data-box');
			});
		}
	});
	//搜索功能
	$(document).on('click', ".main-search-btn", function () {
		var _this = $(this);
		var _search_form = $('.search-body form');
		if (_search_form.length) {
			setTimeout(function () {
				_search_form.find('[name="s"]').focus();
			}, 100);
		}
	});

	// Ajax分页
	function load_content(_this,_cat="",pop=false) {
		if (location.href.split("page").length > 1) {
			var _href = location.href.split("page")[1].split("#")[0].replace(/[^\d]/g, "");
			if(_href && "" == _cat && !pop )
			 	_this.data("page", 1 * _href + 1);
		}
		var action = _this.data("action"),
		target = action,
		page = _this.data("page"),
		text = _this.text(),
			tabcat = _this.data("tabcat");
		if (_this.data("target")) {
			target = _this.data("target");
		}
		_this.text(localize.loading),
		_this.attr("disabled", !0),
		$.ajax({
			url: Theme.ajaxurl,
			type: "POST",
			dataType: "html",
			data: _this.data()
		}).done(function(response) {
			if (0 != response) {
				if ($("." + target).append(response), pop) text = localize.more;
				else if ("" == _cat) {
					var obj = new Object;
					obj.page = page,
					obj.cat = tabcat;
					var d = "",
					p = "page/" + page;
					tabcat && "-1" != tabcat && (d = "?cat=" + tabcat + "/", p = "&paged=" + page),
					text = localize.more;
					var u = location.href.split("page")[0];
					history.pushState(obj, null, u.split("?")[0].split("#")[0] + d + p)
				} else {
					var obj = new Object;
					obj.page = 1,
					obj.cat = tabcat;
					var u = location.href.split("page")[0];
					history.pushState(obj, null, u.split("?")[0].split("#")[0] + "?cat=" + tabcat)
				}
				_this.data("page", 1 * page + 1),
				_this.text(text),
				_this.attr("disabled", !1),
				_this.removeClass("loading")
			} else _this.text(localize.none)
		}).fail(function() {
			iPopupTips(0, localize.networkerror),
			_this.attr("disabled", !1),
			_this.removeClass("loading")
		})
	}
	$(document).on("click", ".list-ajax-nav button", function(a) {
		a.preventDefault();
		var _this = $(this);
		if (!_this.hasClass("active")) {
			$(".list-ajax-nav button").removeClass("active");
			_this.addClass("active");
			var _cat = _this.data("cat"),
			home_but = $(".ajax_load_home");
			"" != _cat ? home_but.data("tabcat", _cat) : home_but.removeData("tabcat");
			home_but.data("page", 1);
			$("." + home_but.data("action")).html("");
			home_but.addClass("loading");
			load_content(home_but, _cat);
		}
	}),
	$(document).on("click", ".ajax_load_home", function(event) {
		event.preventDefault();
		if(!1 === $(".ajax_load_home").hasClass("loading")){
			$(".ajax_load_home").addClass("loading");
			load_content($(this));
		}
	});
	$(document).on("click ", ".post-list-history", function () {
		history.replaceState(history.state, null, "#" + $(this).data("id"));
	});
	window.addEventListener("popstate", function() {
		var _page, _cat, 
		_this = $(".ajax_load_home");
		if (_this[0]) {
			if (history.state) {
				_page = history.state.page,
				_cat = history.state.cat ? history.state.cat: "-1",
				_this.data("page", _page);
				var _body = $("#cat" + _cat);
				if(_body.length){
					$('.list-ajax-nav button').removeClass("active");
					_body.addClass("active");
				}
				if("" != _cat){
					_this.data("tabcat", _cat)
				}else{ 
					_this.removeData("tabcat")
				}
			} else {
				_cat = "-1";
				var _body = $("#cat-1");
				if(_body.length) {
					$(".list-ajax-nav button").removeClass("active");
					_body.addClass("active");
				}
				_this.data("tabcat", -1),
				_this.data("page", 1)
			}
			$("." + _this.data("action")).html(""),
			load_content(_this, _cat, true)
		}
	});
	$(document).on("click", '.button-fx',function(event) {
		//event.preventDefault();
		var _this = $(this);
		if (_this.hasClass('animate')) return;
		
		_this.addClass('animate');
		setTimeout(function(){
			_this.removeClass('animate');
		},700);
	});

	$("#qq").blur(function() {
		if($("#qq").val() != "") { 
			if(isNaN($("#qq").val())){
				$("#textloading").slideUp();
				$("#error").slideDown().html('<span class="sub-no"></span>请输入正确的 QQ 号码');
				setTimeout(function() {
					$submit.attr("disabled", !1).fadeTo("slow", 1);
					$("#error").slideUp();
				},3e3);
			}else{ 
				$("#error").slideUp();
				$("#textloading").slideDown().html('<span class="sub-load"></span>正在获取 QQ 信息'); 
				setTimeout(function() {
					$submit.attr("disabled", !1).fadeTo("slow", 1);
					$("#textloading").slideUp();
				},3e3);
				$.ajax({
					url: Theme.qqinfourl,
					type: "POST",
					data: {
						type: "qq",
						qq: $("#qq").val()
					},
					dataType: "json",
					success: function(response) {
						$("#textloading").slideUp();
						if(response.status == 0) { 
							if( response.name == "" ){
								$("#textloading").slideUp();
								$("#error").slideDown().html('<span class="sub-no"></span>没有找到这个 QQ 号码的信息');
								setTimeout(function() {
									$submit.attr("disabled", !1).fadeTo("slow", 1),
									$("#error").slideUp()
								},3500);
							}else{ 
								$("#author").val(response.name);
								$("#email").val(response.email);
							}
						}else{
							$("#textloading").slideUp();
							$("#error").slideDown().html('<span class="sub-no"></span>' + response.message);
							setTimeout(function() {
								$submit.attr("disabled", !1).fadeTo("slow", 1);
								$("#error").slideUp();
							},3e3);
						}
					},
					error: function(error) {
						$("#textloading").slideUp();
						$("#error").slideDown().html('<span class="sub-no"></span>网络错误: ' + error.statusText);
						setTimeout(function() {
							$submit.attr("disabled", !1).fadeTo("slow", 1);
							$("#error").slideUp();
						},3e3);
					}
				})
			}
		}else{ 
			$("#textloading").slideUp();
			$("#error").slideDown().html('<span class="sub-no"></span>请输入您的 QQ 号');
			setTimeout(function() {
				$submit.attr("disabled", !1).fadeTo("slow", 1);
				$("#error").slideUp();
			},3e3)
		}
	});
	//实时头像
	$("input#email").blur(function(){
		var _email=$(this).val();
		$.ajax({
			type:"GET",
			data:{
				action:'ajax_avatar_get',
				form:Theme.ajaxurl,
				email:_email
			},
			success:function(data){
				$('.v-avatar').attr('src',data)
			}
		})
	})
	//评论分页
	$(document).on("click", '#comments-navi a',function(e) {
		e.preventDefault();
		$.ajax({
			type: "GET",
			url: $(this).attr('href'),
			beforeSend: function(){
				$('#comments-navi').remove();
				$('ul.commentwrap').remove();
				$('#loading-comments').slideDown()
			},
			dataType: "html",
			success: function(out) {
				var result = $(out).find('ul.commentwrap');
				var nextlink = $(out).find('#comments-navi');
				$('#loading-comments').slideUp(550);
				$('#loading-comments').after(result.fadeIn(800));
				$('ul.commentwrap').after(nextlink);
				if (result.find('pre').length && $('link#enlighterjs').length) {
					result.find('pre').enlight({
						linenumbers: !0,
						indent: 2,
						textOverflow: 'scroll',
						theme: 'enlighter', 
						title: Theme.pre_c,
					});
				} else {
					highlightJs();
				}
			}
		})
	});
	highlightJs();

	function load_post_btn() {
		var post_data = $('.post-archive-nav-data');
		if (post_data[0]) {
			var start = parseInt(post_data.data('start')) + 1;
			var max = parseInt(post_data.data('max'));
			var next = post_data.data('next');
			if (start <= max) {
				$('#content')
					.append('<div class="ioc_cat_list-' + start + ' archive-list"></div>')
					.append('<div class="load-more-posts-container wow flipInX" data-wow-duration="1s" data-wow-delay="0.3s"><a href="javascript:;" class="ajax_load btn-load-more-posts button-fx" data-start="' + start + '" data-max="' + max + '" data-next="' + next + '">' + localize.clickMore + '</a></div>');
				$('#load').remove();
			}
		}
	}
	$(document).on('click','.load-more-posts-container .ajax_load',function () {
		var _this = $(this);
		if (_this.data('load')) return;
		
		var start = parseInt(_this.data('start'));
		var max = parseInt(_this.data('max'));
		var next = _this.data('next');
		_this.data('load', true);
		if(start <= max) {
			_this.text(localize.loading);
			$('.ioc_cat_list-'+ start).load(next + ' .load-posts', function () {
				_this.data('load', false);
				start++
				_this.data('start', start);
				_this.data('next', next.replace(/\/page\/([0-9]{1,})?/, '/page/' + start));
				$('.load-more-posts-container')
					.before('<div class="ioc_cat_list-'+ start +'"></div>')
				if(start <= max) {
					$('.load-more-posts-container .ajax_load').text(localize.clickMore);
				} else {
					$('.load-more-posts-container .ajax_load').text(localize.none2);
				}
			});
		} else {
			_this.data('load', false);
			$('.load-more-posts-container .ajax_load').append('');
		}
	});
})(jQuery);

console.log("\n %c Swallow V" + Theme.version + " By 一为 %c https://www.iowen.cn/ \n", "color: #ffffff; background: #f1404b; padding:5px 0;", "background: #030307; padding:5px 0;");


function highlightJs(){
	if(Theme.is_code=="1" && $('pre')[0]){ 
	let script = document.createElement("script"); 
	script.src = Theme.url+'/js/enlighterjs.min.js';
	document.body.appendChild(script);
	$("link#enlighterjs").length || $("head").append('<link type="text/css" rel="stylesheet" href="'+Theme.url+'/css/enlighterjs.min.css" id="enlighterjs">');
	}
}

function is_function(functionName){
    try {
        if (typeof eval(functionName) === "function") { 
            return true;
        } else { 
            return false;
        }
    } catch (e) {
        console.log(functionName+" is not defined");
    }
    return false;
}

function setCookie(cname,cvalue,exdays){
    var expires = '';
    if(exdays!=''){
        var d = new Date();
        d.setTime(d.getTime()+(exdays*24*60*60*1000));
        expires = "expires="+d.toGMTString();
    }
    document.cookie = cname+"="+cvalue+"; "+expires+"; path=/";
}
function getCookie(cname){
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name)==0) { return c.substring(name.length,c.length); }
    }
    return "";
}

function iPopupTips(type, msg) {
	var ico = type ? '<span class="d-block h1 text-success mb-2"><?xml version="1.0" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg t="1553065772988" class="icon w-56" style="" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2922" xmlns:xlink="http://www.w3.org/1999/xlink" width="200" height="200"><defs><style type="text/css"></style></defs><path d="M666.272 472.288l-175.616 192a31.904 31.904 0 0 1-23.616 10.4h-0.192a32 32 0 0 1-23.68-10.688l-85.728-96a32 32 0 1 1 47.744-42.624l62.144 69.6 151.712-165.888a32 32 0 1 1 47.232 43.2m-154.24-344.32C300.224 128 128 300.32 128 512c0 211.776 172.224 384 384 384 211.68 0 384-172.224 384-384 0-211.68-172.32-384-384-384" p-id="2923"></path></svg></span>' : '<span class="d-block h1 text-danger mb-2"><?xml version="1.0" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg t="1553065784656" class="icon w-56" style="" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3053" xmlns:xlink="http://www.w3.org/1999/xlink" width="200" height="200"><defs><style type="text/css"></style></defs><path d="M544 576a32 32 0 0 1-64 0v-256a32 32 0 0 1 64 0v256z m-32 160a32 32 0 1 1 0-64 32 32 0 0 1 0 64z m0-608C300.256 128 128 300.256 128 512s172.256 384 384 384 384-172.256 384-384S723.744 128 512 128z" p-id="3054"></path></svg></span>';
	var c = type ? 'tips-success' : 'tips-error';
	var html = '<section class="ioc-bomb '+c+' ioc-bomb-sm ioc-bomb-open">'+
					'<div class="ioc-bomb-overlay"></div>'+
					'<div class="ioc-bomb-body text-center">'+
						'<div class="ioc-bomb-content px-5">'+ico+
							'<p class="text-md">'+msg+'</p>'+
						'</div>'+
					'</div>'+
				'</section>';
	var tips = $(html);
	$('body').append(tips);
	setTimeout(function(){
		tips.removeClass('ioc-bomb-open');
		tips.addClass('ioc-bomb-close');
		setTimeout(function(){
			tips.removeClass('ioc-bomb-close');
			setTimeout(function(){
				tips.remove();
			}, 200);
		},400);
	},1200);
}
function iPopup(type, html, maskStyle, btnCallBack) {
	var maskStyle = maskStyle ? 'style="' + maskStyle + '"' : '';
	var size = '';
	if( type == 'big' ){
		size = 'ioc-bomb-lg';
	}else if( type == 'no-padding' ){
		size = 'ioc-bomb-nopd';
	}else if( type == 'cover' ){
		size = 'ioc-bomb-cover ioc-bomb-nopd';
	}else if( type == 'full' ){
		size = 'ioc-bomb-xl';
	}else if( type == 'small' ){
		size = 'ioc-bomb-sm';
	}else if( type == 'reward' ){
		size = 'ioc-bomb-reward ioc-bomb-nopd';
	}
	var template = '\
	<div class="ioc-bomb ' + size + ' ioc-bomb-open">\
		<div class="ioc-bomb-overlay" ' + maskStyle + '></div>\
		<div class="ioc-bomb-body">\
			<div class="ioc-bomb-content">\
				'+html+'\
			</div>\
			<div class="btn-close-bomb">\
				<?xml version="1.0" standalone="no"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd"><svg t="1553064665406" class="icon w-32" style="" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="3368" xmlns:xlink="http://www.w3.org/1999/xlink" width="200" height="200"><defs><style type="text/css"></style></defs><path d="M512 12C235.9 12 12 235.9 12 512s223.9 500 500 500 500-223.9 500-500S788.1 12 512 12z m166.3 609.7c15.6 15.6 15.6 40.9 0 56.6-7.8 7.8-18 11.7-28.3 11.7s-20.5-3.9-28.3-11.7L512 568.6 402.3 678.3c-7.8 7.8-18 11.7-28.3 11.7s-20.5-3.9-28.3-11.7c-15.6-15.6-15.6-40.9 0-56.6L455.4 512 345.7 402.3c-15.6-15.6-15.6-40.9 0-56.6 15.6-15.6 40.9-15.6 56.6 0L512 455.4l109.7-109.7c15.6-15.6 40.9-15.6 56.6 0 15.6 15.6 15.6 40.9 0 56.6L568.6 512l109.7 109.7z" p-id="3369"></path></svg>\
			</div>\
		</div>\
	</div>';
	var popup = $(template);
	$('body').append(popup);
	var close = function(){
		$(popup).removeClass('ioc-bomb-open');
		$(popup).addClass('ioc-bomb-close');
		setTimeout(function(){
			$(popup).removeClass('ioc-bomb-close');
			setTimeout(function(){
				popup.remove();
			}, 200);
		},600);
	}
	$(popup).on('click touchstart', '.btn-close-bomb, .ioc-bomb-overlay', function(event) {
		event.preventDefault();
		close();
	});
	if( typeof btnCallBack == 'object' ){
		Object.keys(btnCallBack).forEach(function(key){
			$(popup).on('click touchstart', key, function(event) {
				var ret = btnCallBack[key](event, close);
			});
		});
	}
	return popup;
}

if(document.getElementById("clickCanvas")) {
	function Particle(x, y, radius) {
		this.init(x, y, radius);
	}

	Particle.prototype = {
		init : function(x, y, radius) {
			this.alive = true;
			this.radius = radius || 10;
			this.wander = 0.15;
			this.theta = random(TWO_PI);
			this.drag = 0.92;
			this.color = '#ffeb3b';

			this.x = x || 0.0;
			this.y = y || 0.0;
			this.vx = 0.0;
			this.vy = 0.0;
		},

		move : function() {
			this.x += this.vx;
			this.y += this.vy;
			this.vx *= this.drag;
			this.vy *= this.drag;
			this.theta += random(-0.5, 0.5) * this.wander;
			this.vx += sin(this.theta) * 0.1;
			this.vy += cos(this.theta) * 0.1;
			this.radius *= 0.96;
			this.alive = this.radius > 0.5;
		},

		draw : function(ctx) {
			ctx.beginPath();
			ctx.arc(this.x, this.y, this.radius, 0, TWO_PI);
			ctx.fillStyle = this.color;
			ctx.fill();
		}
	};

	// ----------------------------------------
	// Example
	// ----------------------------------------
	var MAX_PARTICLES = 50;
	var COLOURS = [ "#5ee4ff", "#f44033", "#ffeb3b", "#F38630", "#FA6900", "#f403e8", "#F9D423" ];
	var particles = [];
	var pool = [];

	var clickparticle = Sketch.create({
		container : document.getElementById('clickCanvas'),
		retina: 'auto'
	});
	clickparticle.spawn = function(x, y) {
		var particle, theta, force;
		if (particles.length >= MAX_PARTICLES)
			pool.push(particles.shift());
		particle = pool.length ? pool.pop() : new Particle();
		particle.init(x, y, random(5, 20));
		particle.wander = random(0.5, 2.0);
		particle.color = random(COLOURS);
		particle.drag = random(0.9, 0.99);
		theta = random(TWO_PI);
		force = random(1, 5);
		particle.vx = sin(theta) * force;
		particle.vy = cos(theta) * force;
		particles.push(particle);
	};
	clickparticle.update = function() {
		var i, particle;
		for (i = particles.length - 1; i >= 0; i--) {
			particle = particles[i];
			if (particle.alive)
				particle.move();
			else
				pool.push(particles.splice(i, 1)[0]);
		}
	};
	clickparticle.draw = function() {
		clickparticle.globalCompositeOperation = 'lighter';
		for ( var i = particles.length - 1; i >= 0; i--) {
			particles[i].draw(clickparticle);
		}
	};
	
	document.addEventListener("click", function(e) {
	var max, j;
	//排除一些元素
	"TEXTAREA" !== e.target.nodeName && "INPUT" !== e.target.nodeName && "A" !== e.target.nodeName && "I" !== e.target.nodeName && "IMG" !== e.target.nodeName 
	&& function() {
		for (max = random(15, 20), j = 0; j < max; j++) 
		clickparticle.spawn(e.clientX, e.clientY);
	}();
});
}
function debounce(callback, delay, immediate) {
    var timeout;
    return function () {
        var context = this,
            args = arguments;
        var later = function () {
            timeout = null;
            if (!immediate) {
                callback.apply(context, args);
            }
        };
        var callNow = (immediate && !timeout);
        clearTimeout(timeout);
        timeout = setTimeout(later, delay);
        if (callNow) {
            callback.apply(context, args);
        }
    };
}

(function() {
	var canvas, ctx, panel, width, height, bubbles, animateHeader = true;
	//panel = $("#thumbnail_canvas");
	panel = document.getElementById('thumbnail_canvas');
	if(panel){
		initHeader();
		//原生js版本
		window.onresize = function(){
			window_resize();
		}
		//Jquery 版本
		//$(window).resize(function(){
		//	window_resize();
		//});
	}
	function initHeader() {
		canvas = document.getElementById('header_canvas');
		window_resize();
		ctx = canvas.getContext('2d');
		//建立泡泡
		bubbles = [];
		var num = width * 0.04;//气泡数量
		for (var i = 0; i < num; i++) {
			var c = new Bubble();
			bubbles.push(c);
		}
		animate();
	}
	function animate() {
		if (animateHeader) {
			ctx.clearRect(0, 0, width, height);
			for (var i in bubbles) {
				bubbles[i].draw();
			}
		}
		requestAnimationFrame(animate);
	}
	function window_resize() {
		//canvas铺满窗口
		//width = window.innerWidth;
		//height = window.innerHeight;

		//如果需要铺满内容可以换下面这个
		//Jquery 版本
		//width=panel.width();
		//height=panel.height();
		//原生js版本
		width=panel.offsetWidth;
		height=panel.offsetHeight;

		canvas.width = width;
		canvas.height = height;
	}
	function Bubble() {
		var _this = this;
		(function() {
			_this.pos = {};
			init();
		})();
		function init() {
			_this.pos.x = Math.random() * width;
			_this.pos.y = height + Math.random() * 100;
			_this.alpha = 0.1 + Math.random() * 0.3;//气泡透明度
			_this.alpha_change = 0.0002 + Math.random() * 0.0005;//气泡透明度变化速度
			_this.scale = 0.2 + Math.random() * 0.5;//气泡大小
			_this.scale_change = Math.random() * 0.002;//气泡大小变化速度
			_this.speed = 0.1 + Math.random() * 0.4;//气泡上升速度
		}
		//气泡
		this.draw = function() {
			if (_this.alpha <= 0) {
				init();
			}
			_this.pos.y -= _this.speed;
			_this.alpha -= _this.alpha_change;
			_this.scale += _this.scale_change;
			ctx.beginPath();
			ctx.arc(_this.pos.x, _this.pos.y, _this.scale * 10, 0, 2 * Math.PI, false);
			ctx.fillStyle = 'rgba(255,255,255,' + _this.alpha + ')';
			ctx.fill();
		}; 
	}
})();