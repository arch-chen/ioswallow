/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2019-09-23 19:45:05
 * @LastEditors: iowen
 * @LastEditTime: 2021-12-29 15:58:26
 * @FilePath: \ioswallow\js\buttons.js
 * @Description: 
 */
(function($) {
	tinymce.create('tinymce.plugins.MyButtons', {
		init : function(ed, url) {
			ed.addButton( 'reply', {
				title : '回复可见',
				icon: 'ioxiaoxi',
				onclick : function() {
					ed.selection.setContent('[need_reply]隐藏的内容' + ed.selection.getContent() + '[/need_reply]');
				}
			});

			ed.addButton( 'login', {
				title : '登录可见',
				icon: 'ioruzhi',
				onclick : function() {
					ed.selection.setContent('[login_reply]隐藏的内容' + ed.selection.getContent() + '[/login_reply]');
				}
			});

			ed.addButton( 'password', {
				title : '密码保护',
				icon: 'iomima',
				onclick : function() {
					ed.selection.setContent('[password_reply key=密码]' + ed.selection.getContent() + '加密的内容[/password_reply]');
				}
			});

			ed.addButton( 'field', {
				title : 'fieldset标签',
				icon: 'iorenwu',
				onclick : function() {
					ed.selection.setContent('<fieldset><legend>我是标题</legend><p>这里是内容</p></fieldset>' + ed.selection.getContent() + '');
				}
			});

			ed.addButton( 'embedpost', {
				title : '卡片文章内链',
				icon: 'iolianjie',
				onclick : function() {
					ed.selection.setContent('[embed_post ids=文章ID_1,文章ID_2]' + ed.selection.getContent() + '');
				}
			});

			ed.addButton( 'ad', {
				title : '插入广告',
				icon: 'ioad',
				onclick : function() {
					ed.selection.setContent('[ad]' + ed.selection.getContent() + '');
				}
			});

			ed.addButton( 'buttons', {
				title : '添加按钮',
				icon: 'iobtn',
				type: 'menubutton',
				menu: [
					{
						text: '普通按钮',
						icon: 'minus',
						onclick: function() {
							ed.selection.setContent('[button href=链接地址 center=0(1为居中) full=0(1为全宽)]按钮名称[/button]');
						}
					},
					{
						text: '下载按钮',
						icon: 'minus',
						onclick: function() {
							ed.selection.setContent('[down href=下载链接地址 center=0(1为居中) full=0(1为全宽)]按钮名称[/down]');
						}
					},
					{
						text: '预览按钮',
						icon: 'minus',
						onclick: function() {
							ed.selection.setContent('[preview href=预览链接地址 center=0(1为居中) full=0(1为全宽)]按钮名称[/preview]');
						}
					}
				]
			});
			
			ed.addButton('tabs', {
				title: "添加Tabs模块",
				icon: 'iobianqian',
				cmd: 'tabs_code_plugin'
			});

			ed.addCommand('tabs_code_plugin', function() {
				ed.windowManager.open(
					{
						title: "添加一个Tabs模块",
						file: url + '/add-tabs.php',
						width: 350,
						height: 200,
						inline: 1
					}
				);
			});

			ed.addButton('promptbox', {
				title : '插入提示框',
				icon: 'iotonggao',
				onclick : function() {
				var h = '<div id="info_div"><style>';
				h += '.single_doc{ position:fixed; width:280px; height:200px; border-radius:5px; padding:20px; background:#fff; margin:auto; top:0;left:0; right:0; bottom:0; z-index:100101; box-shadow:0 5px 20px 5px rgba(0,0,0,.2); }';
				h += '.form_doc{ width:100%;line-height:20px;}';
				h += '.form_doc input{margin-right:5px;margin-left:10px;}';
				h += '.form_doc .but-con{margin-top:30px;text-align:center;}';
				h += '.form_doc .but-con button{cursor:pointer;width:100px;height:30px;border:transparent;border-radius:6px;margin:5px;transition:.3s}';
				h += '.form_doc .but-con button:hover{box-shadow:0px 10px 10px -5px rgba(68,68,68,.4)}';
				h += '.form_doc .but-con #single_submit{background:#3ca3ff;color:#fff;}';
				h += '</style>';
				var input = '<div class="single_doc"><div class="form_doc"><h4>选择颜色</h4><input type="radio" name="radio" value="info" checked>蓝色<input type="radio" name="radio" value="success">绿色<input type="radio" name="radio" value="worning">黄色<input type="radio" name="radio" value="error">红色<h4>全宽样式<input type="checkbox" name="fullwidth" checked></h4><div class="but-con"><button id="single_submit">确定</button><button id="single_close">关闭</button></div></div></div><div id="mce-modal-block" class="mce-reset mce-fade mce-in" style="z-index: 100100;"></div></div>';
				
				h += input;
				
				$("body").append(h);
				$("#single_submit").click(function(){
					var type= $("input[name='radio']:checked").val();
					var display= 'display="inlineBlock"';
					var content = '输入内容';
					if($("input[name='fullwidth']").is(":checked")){
						display = '';
					}
					if(ed.selection.getContent()!=''){
						content=ed.selection.getContent();
					}
					var tex = '[tip type="' + type + '" ' + display + ']' + content + '[/tip]';
					ed.selection.setContent(tex);
					$("#info_div").remove();
				}) 
								
				$("#single_close").click(function(){
					$("#info_div").remove();
				}) 
				
				}
			});

			ed.addButton('aplayerbox', {
				title : '插入音乐播放器',
				icon: 'ioyinle',
				onclick : function() {
				var h = '<div id="aplayer_div"><style>';
				h += '.aplayer_doc{position:fixed;width:330px;display:table;border-radius:8px;padding:20px;background:#fff;margin:auto;top:20%;left:0;right:0;bottom:0;z-index:100101;box-shadow:0 5px 20px 5px rgba(0,0,0,.2)}';
				h += '.form_doc{ width:100%;line-height:20px;}';
				h += '.form_doc input{margin-right:5px;margin-left:10px;}';
				h += '.form_doc .but-con{margin-top:30px;text-align:center;}';
				h += '.form_doc .but-con button{cursor:pointer;width:100px;height:30px;border:transparent;border-radius:6px;margin:5px;transition:.3s}';
				h += '.form_doc .but-con button:hover{box-shadow:0px 10px 10px -5px rgba(68,68,68,.4)}';
				h += '.form_doc .but-con #aplayer_submit{background:#3ca3ff;color:#fff;}';
				h += '.form_doc input[type="text"]{margin:0px 0 10px;width:100%}';
				h += '.form_doc .con{display: none;}';
				h += '.form_doc .active{display: unset;}';
				h += '</style>';
				
				var input = '<div class="aplayer_doc"><div class="form_doc"><h4>模式</h4><input type="radio" name="mode" id="idm" value="idm" checked>ID模式<input type="radio" name="mode" id="urlm" value="urlm">链接模式<input type="radio" name="mode" id="rainymood" value="rainymood">自托管<div class="con netease active"><h4>参数</h4>选择平台：<input type="radio" name="server" value="netease" checked>网易音乐<input type="radio" name="server" value="tencent">qq音乐<input type="radio" name="server" value="xiami">虾米<br><br>音乐 ID：<input type="text" name="id" value="60198">选择类型：<input type="radio" name="type" value="song" checked>单曲<input type="radio" name="type" value="album">专辑<input type="radio" name="type" value="playlist">歌单</div><div class="con tencent"><h4>参数</h4>音乐地址：(音乐链接支持：网易、腾讯、虾米)<input type="text" name="auto" value="https://y.qq.com/n/yqq/song/001RGrEX3ija5X.html"></div><div class="con rainymood"><h4>参数</h4>名称：<input type="text" name="i_name" value="歌名">歌手：<input type="text" name="i_artist" value="歌手">地址：<input type="text" name="i_url" value="https://rainymood.com/audio1110/0.m4a">封面：<input type="text" name="i_cover" value="https://rainymood.com/i/badge.jpg">歌词：<input type="text" name="i_lyric" value="[00:00.00]This[00:04.01]is[00:08.02]lyric"></div><h4>自动播放<input type="checkbox" name="autoplay" checked></h4><a href="https://github.com/metowolf/MetingJS" target="_blank">帮助？</a><div class="but-con"><button id="aplayer_submit">确定</button><button id="aplayer_close">关闭</button></div></div></div><div id="mce-modal-block" class="mce-reset mce-fade mce-in" style="z-index: 100100;"></div></div>';
				h += input; 
				$("body").append(h);
				$("#aplayer_submit").click(function(){ 
					var mode= $("input[name='mode']:checked").val();
					var server= $("input[name='server']:checked").val();
					var type= $("input[name='type']:checked").val();
					var ID= $("input[name='id']").val();
					var name= $("input[name='i_name']").val();
					var artist= $("input[name='i_artist']").val();
					var url= $("input[name='i_url']").val();
					var cover= $("input[name='i_cover']").val();
					var lyric= $("input[name='i_lyric']").val();
					var auto= $("input[name='auto']").val();
					var autoplay= 'false';
					if($("input[name='autoplay']").is(":checked")){
						autoplay = 'true';
					}
					if(mode=="idm"){
						var tex = '[aplayer id="'+ ID +'" server="'+ server +'" type="' + type + '" autoplay="' + autoplay + '"]'; 
					}else if(mode=="urlm"){
						var tex = '[aplayer auto="'+ auto +'" autoplay="' + autoplay + '"]'; 
					}else{
						var tex = '[aplayer name="'+ name +'" artist="'+ artist +'" url="' + url + '" cover="' + cover + '" lyric="' + lyric.replace(/\[/ig, '《').replace(/\]/ig, '》') + '" autoplay="' + autoplay + '"]'; 
					}
					ed.selection.setContent(tex);
					$("#aplayer_div").remove();
				});			
				$("#aplayer_close").click(function(){
					$("#aplayer_div").remove();
				});
				$('#idm').click(function(){
					var checkValue = $(this).val(); 
					$('.netease').addClass('active');
					$('.tencent').removeClass('active');
					$('.rainymood').removeClass('active');  
				});
				$('#urlm').click(function(){
					var checkValue = $(this).val(); 
					$(".netease").removeClass('active');
					$(".tencent").addClass('active');
					$(".rainymood").removeClass('active');  
				});
				$('#rainymood').click(function(){
					var checkValue = $(this).val(); 
					$(".netease").removeClass('active');
					$(".tencent").removeClass('active');
					$(".rainymood").addClass('active');  
				});
				}
			});

			ed.addButton('videobox', {
				title : '插入视频',
				icon: 'ioshipin',
				onclick : function() {
				var h = '<div id="info_div"><style>\
				.single_doc{ position:fixed; width:330px; height:260px; border-radius:5px; padding:20px; background:#fff; margin:auto; top:0;left:0; right:0; bottom:0; z-index:100101; box-shadow:0 5px 20px 5px rgba(0,0,0,.2); }\
				.form_doc{ width:100%;line-height:20px;}\
				.form_doc input{margin-right:5px}\
				.form_doc .but-con{margin-top:30px;text-align:center;}\
				.form_doc button{cursor:pointer;width:100px;min-height:30px;border:transparent;border-radius:6px;transition:.3s}\
				.form_doc button:hover{box-shadow:0px 10px 10px -5px rgba(68,68,68,.4)}\
				.form_doc #single_submit{background:#3ca3ff;color:#fff;}\
				.file-box{display:flex;margin-bottom:5px;}\
				.box-type{margin:15px 0;}\
				.file-textarea{width: 100%;resize:none;}\
				</style>';
				var input = '<div class="single_doc"><div class="form_doc">\
				<h4>选择类型</h4>\
				<input type="radio" name="video-type" value="mp4" checked>直链(MP4文件)\
				<input type="radio" name="video-type" value="iframe">iframe嵌入\
				<div id="mp4" class="box-type">\
					<div class="file-box"><input type="text" size="40" name="video-url" class="video-url" value="" placeholder="输入视频地址" style="width:90%;"/><button class="io_btn_file">选择视频</button></div>\
					<div class="file-box"><input type="text" size="40" name="cover-url" class="cover-url" value="" placeholder="输入封面地址" style="width:90%;"/><button class="io_btn_file">选择封面</button></div>\
					<div style="margin-top:5px">自动播放<input type="checkbox" name="autoplay"> 循环<input type="checkbox" name="loop"> 静音<input type="checkbox" name="mute"> 隐藏控件<input type="checkbox" name="controls"></div>\
				</div>\
				<div id="iframe" class="box-type" style="display:none">\
					<textarea name="iframe-url" class="file-textarea iframe-url" rows="4"></textarea>\
				</div>\
				<div class="but-con"><button id="single_submit">确定</button>\
					<button id="single_close">关闭</button>\
				</div>\
			</div></div>\
			<div id="mce-modal-block" class="mce-reset mce-fade mce-in" style="z-index: 100100;"></div>\
			</div>';
				
				h += input;
				
				$("body").append(h);
				$('input[name=video-type]').change(function() {
					if (this.value == 'mp4'){
						$("#mp4").css({"display":"block"});
						$("#iframe").css({"display":"none"});
					}else{
						$("#mp4").css({"display":"none"});
						$("#iframe").css({"display":"block"});
					}
				});
				$("#single_submit").click(function(){
					var type= $("input[name='video-type']:checked").val();
					if(type == "mp4"){
						var video = $(".video-url").val();  
						var cover = $(".cover-url").val(); 
						var autoplay = '';
						var loop = '';
						var muted = '';
						var controls = ' controls="controls"';
						if($("input[name='autoplay']").is(":checked")){
							autoplay = ' autoplay="autoplay"';
						}
						if($("input[name='loop']").is(":checked")){
							loop = ' loop="loop"';
						}
						if($("input[name='muted']").is(":checked")){
							muted = ' muted="muted"';
						}
						if($("input[name='controls']").is(":checked")){
							controls = '';
						}
						var tex = '<div class="video"><video class="video-file" style="width: 100%;" src="' + video + '" poster="' + cover + '"'+autoplay+loop+muted+controls+'"></div>';
					}else{
						var content = $(".iframe-url").val();  
						var tex = '<div class="video video-iframe">' + content + '</div>';
					}
					ed.selection.setContent(tex);
					$("#info_div").remove();
				});			
				$("#single_close").click(function(){
					$("#info_div").remove();
				});
				if (typeof wp !== 'undefined' && wp.media && wp.media.editor) {
					$(document).on('click', '.io_btn_file', function(e) {
						e.preventDefault();
						var button = $(this);
						var id = button.prev();
						wp.media.editor.send.attachment = function(props, attachment) {
							if ($.trim(id.val()) != '') {
								id.val(id.val() + '\n' + attachment.url);
							} else {
								id.val(attachment.url);
							}
						};
						wp.media.editor.open(button);
						return false;
					});
				}
				}
			});

		},
		createControl : function(n, cm) {
			return null;
		},
	});

	tinymce.PluginManager.add( 'io_button_script', tinymce.plugins.MyButtons );
})(jQuery);
 

