/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-09-23 19:45:05
 * @LastEditors: iowen
 * @LastEditTime: 2021-12-01 00:26:06
 * @FilePath: \ioswallow\js\editor-code.js
 * @Description: 
 */
(function() {
	tinymce.create('tinymce.plugins.iochButtons', {
		init: function(ed, url) {
			ed.addCommand('ioch_code',
			function() {
				ed.windowManager.open({
					title: '插入代码',
					file: url +'/insert-code.php',
					width: 660,
					height: 430,
					inline: 1
				},
				{
					plugin_url: url // Plugin absolute URL
				});
			});

			ed.addButton('ioch_code', {
				title: '代码高亮',
				cmd: 'ioch_code',
				icon: 'iocode'

			});
		},
		createControl: function(n, cm) {
			return null;
		},
		getInfo: function() {
			return null;
		}
	});
	tinymce.PluginManager.add('ioch_code_button', tinymce.plugins.iochButtons);
})();
