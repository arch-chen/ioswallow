<?php 
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:11
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-27 13:57:46
 * @FilePath: \ioswallow\archive.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

get_template_part('templates/cat', 'list');

get_footer(); 