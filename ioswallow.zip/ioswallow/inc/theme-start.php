<?php 
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-03-01 10:19:06
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-27 18:21:46
 * @FilePath: \ioswallow\inc\theme-start.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }


/**
 * 注册菜单
 */
register_nav_menus( array(
    'main' => __( '主菜单' , 'i_theme' ),
));

/**
 * 启用主题重置缩略图的默认尺寸后进主题设置仪表盘 
 */
function Init_theme(){
    global $pagenow;
    if ( 'themes.php' == $pagenow && isset( $_GET['activated'] ) ) {
        update_option( 'thumbnail_size_w',0 );
        update_option( 'thumbnail_size_h', 0 );
        update_option( 'thumbnail_crop', 0 );
        update_option( 'medium_size_w',0 );
        update_option( 'medium_size_h', 0 );
        update_option( 'large_size_w',0 );
        update_option( 'large_size_h', 0 );
        update_option( 'comments_notify', 0 );
        update_option( 'moderation_notify', 0 ); 
        update_option( 'comment_order', 'desc' );  
        io_add_pages();
        wp_redirect( admin_url( '/admin.php?page=theme_settings' ) );
        exit;
    }
}
add_action('load-themes.php', 'Init_theme');

require get_theme_file_path('/inc/primary.php');
require get_theme_file_path('/inc/inc.php'); 
require get_theme_file_path('/inc/functions/functions.php'); 
require get_theme_file_path('/inc/adminbar-menu.php');
require_once get_theme_file_path('/inc/reward.php'); 
if(io_get_option('post_views')) require_once get_theme_file_path('/inc/postviews/postviews.php');
if(io_get_option('site_map')) require_once get_theme_file_path('/inc/classes/do.sitemap.class.php' );
if( LOGIN_007 && io_get_option('tcaptcha_007')) require_once get_theme_file_path('/inc/qq-captcha.php');

getAlibabaIco('ico');
function my_theme_setup(){
    load_theme_textdomain( 'i_theme', get_template_directory() . '/languages' );
    load_theme_textdomain( 'io_setting', get_template_directory() . '/languages' );
}
add_action('after_setup_theme', 'my_theme_setup');

function io_add_pages() {     
	io_add_page('归档','articlearchive','template-archives.php');  
	io_add_page('LINKS','links','template-links.php');  
	io_add_page('RAND','tryluck','template-rand.php');  
	io_add_page('微语','talk','template-shuoshuo.php');  
	io_add_page('博客地图','blogmap','template-sitemap.php');  
	io_add_page('推荐阅读','recommended','template-top.php'); 
	io_add_page('Topics','topics','template-topics.php');    
}      

// 主题更新功能
function io_theme_update_checker(){
    if (io_get_option('update_theme', false)) {
        /**
         * @var string 子主题支持的最大版本
         * HOOK : io_sub_max_version_filters
         */
        $max_v = apply_filters('io_sub_max_version_filters', '');
        require_once get_theme_file_path('/inc/classes/theme.update.checker.class.php');
        $example_update_checker = new ThemeUpdateChecker(
            'ioswallow',
            'https://www.iotheme.cn/update/',
            $max_v
        );
    }
}
add_action('init', 'io_theme_update_checker');
