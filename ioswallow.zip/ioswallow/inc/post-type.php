<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:26
 * @LastEditors: iowen
 * @LastEditTime: 2022-02-15 20:59:55
 * @FilePath: \ioswallow\inc\post-type.php
 * @Description: 
 */

// 说说（公告）
if(io_get_option('shuoshuo')) add_action( 'init', 'post_type_shuoshuo' );
function post_type_shuoshuo() {
	$labels = array(
		'name'               => '微语', 'post type general name', 'your-plugin-textdomain',
		'singular_name'      => '微语', 'post type singular name', 'your-plugin-textdomain',
		'menu_name'          => '微语', 'admin menu', 'your-plugin-textdomain',
		'name_admin_bar'     => '微语', 'add new on admin bar', 'your-plugin-textdomain',
		'add_new'            => '发布微语', 'shuoshuo', 'your-plugin-textdomain',
		'add_new_item'       => '发布新微语', 'your-plugin-textdomain',
		'new_item'           => '新微语', 'your-plugin-textdomain',
		'edit_item'          => '编辑微语', 'your-plugin-textdomain',
		'view_item'          => '查看微语', 'your-plugin-textdomain',
		'all_items'          => '所有微语', 'your-plugin-textdomain',
		'search_items'       => '搜索微语', 'your-plugin-textdomain',
		'parent_item_colon'  => 'Parent 微语:', 'your-plugin-textdomain',
		'not_found'          => '你还没有发布微语。', 'your-plugin-textdomain',
		'not_found_in_trash' => '回收站中没有微语。', 'your-plugin-textdomain'
	);

	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => io_get_option('shuo_rewrite','shuo','post') ),
		'capability_type'    => 'post',
		'menu_icon'          => 'dashicons-share-alt',
		'has_archive'        => false,
		'hierarchical'       => false,
		'menu_position'      => 10,
		'supports'           => array( 'title', 'editor', 'author',  'comments', 'custom-fields')
	);

	register_post_type( 'shuoshuo', $args );
} 


// --------------------------------------[自定义文章]--------------------------------------------------------------

/**
 * 设置自定义文章类型的固定链接结构为 ID.html 
 * ---------------------------------------------------------------------------------------------------------------
 * https://www.wpdaxue.com/custom-post-type-permalink-code.html
 */
$_iotpostypes = array(
	'shuoshuo'	   => io_get_option('shuo_rewrite','shuo','post'),
);
global $IOPOSTTYPE;
$IOPOSTTYPE = apply_filters( 'io_rewrites_post_type', $_iotpostypes );
if(get_option('permalink_structure')):
if (!io_get_option('rewrites_types') || (io_get_option('rewrites_types') == 'post_id')) {
	add_filter('post_type_link', 'io_custom_post_type_link_id', 1, 2);
	if( is_admin() ) add_action( 'rewrite_rules_array', 'io_custom_post_type_rewrites_init_id' );
}elseif (io_get_option('rewrites_types') == 'postname' && io_get_option('rewrites_end')) {
	add_filter('post_type_link', 'io_custom_post_type_link_name', 1, 2);
	if( is_admin() ) add_action( 'rewrite_rules_array', 'io_custom_post_type_rewrites_init_name' );
}
endif;
// ID
function io_custom_post_type_link_id( $link, $post = 0 ){
	global $IOPOSTTYPE;
	if ( in_array( $post->post_type,array_keys($IOPOSTTYPE) ) ){
        //return add_query_arg( $_GET, home_url( $IOPOSTTYPE[$post->post_type].'/' . $post->ID . (io_get_option('rewrites_end')?'.html':'') ) );
		return home_url( $IOPOSTTYPE[$post->post_type].'/' . $post->ID . (io_get_option('rewrites_end')?'.html':'') );
	} else {
		return $link;
	}
}
function io_custom_post_type_rewrites_init_id( $rules ){
	global $IOPOSTTYPE, $is_new_page;
	$new_rule = array();
	if($is_new_page){
        $post_rule = '/([0-9]+)?(/([0-9]+))?/?$';
        $comment_rule = '/([0-9]+)?/comment-page-([0-9]{1,})/?$';
	}else{
		$post_rule = '/([0-9]+)?(?:/([0-9]+))?/?$';
		$comment_rule = '/([0-9]+)?/comment-page-([0-9]{1,})/?$';
    }
	if(io_get_option('rewrites_end')){
		if($is_new_page){
            $post_rule = '/([0-9]+)?(-([0-9]+))?.html/?$';
            $comment_rule = '/([0-9]+)?/comment-page-([0-9]{1,}).html/?$';
		}else{
			$post_rule = '/([0-9]+)?.html(?:/([0-9]+))?/?$';
			$comment_rule = '/([0-9]+)?.html/comment-page-([0-9]{1,})/?$';
        }
	}
	foreach( $IOPOSTTYPE as $k => $v ) {
		foreach ($rules as $rule => $rewrite) {
			if ($rule == $v.'/([^/]+)/comment-page-([0-9]{1,})/?$' || 
				$rule == $v.'/([^/]+)(?:/([0-9]+))?/?$' 
			) {
				unset($rules[$rule]);
			}
		}
		$new_rule[ $v.$comment_rule ] = 'index.php?post_type='.$k.'&p=$matches[1]&cpage=$matches[2]';
		$new_rule[ $v.$post_rule ] = 'index.php?post_type='.$k.'&p=$matches[1]&page=$matches[3]';
	}

	return $new_rule + $rules;
}
// post_name
function io_custom_post_type_link_name( $link, $post = 0 ){
	global $IOPOSTTYPE;
	if ( in_array( $post->post_type,array_keys($IOPOSTTYPE) ) ){
		return home_url( $IOPOSTTYPE[$post->post_type].'/' . $post->post_name . (io_get_option('rewrites_end')?'.html':'') );
	} else {
		return $link;
	}
}
function io_custom_post_type_rewrites_init_name( $rules ){
	$new_rule = array();
	$end = '';
	if(io_get_option('rewrites_end')){$end = '.html';}
	global $IOPOSTTYPE, $is_new_page;
	foreach( $IOPOSTTYPE as $k => $v ) {
		foreach ($rules as $rule => $rewrite) {
			if ($rule == $v.'/([^/]+)/comment-page-([0-9]{1,})/?$' || 
				$rule == $v.'/([^/]+)(?:/([0-9]+))?/?$' 
			) {
				unset($rules[$rule]);
			}
		}
		if($is_new_page){
            $new_rule[ $v.'/([^/]+)?/comment-page-([0-9]{1,})'.$end.'/?$' ] = 'index.php?'.$k.'=$matches[1]&cpage=$matches[2]';
            $new_rule[ $v.'/([^/]+)?(?:/([0-9]+))?'.$end.'/?$' ] = 'index.php?'.$k.'=$matches[1]&page=$matches[2]';
		}else{
			$new_rule[ $v.'/([^/]+)?'.$end.'(?:/([0-9]+))?/?$' ] = 'index.php?'.$k.'=$matches[1]&cpage=$matches[2]';
			$new_rule[ $v.'/([^/]+)?'.$end.'/comment-page-([0-9]{1,})/?$' ] = 'index.php?'.$k.'=$matches[1]&page=$matches[2]';
        }
	}

	return $new_rule + $rules;
}

// --------------------------------------[自定义文章] END--------------------------------------------------------------