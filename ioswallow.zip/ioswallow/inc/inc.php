<?php
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:26
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-24 17:25:59
 * @FilePath: /ioswallow/inc/inc.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }


//开启文章格式
//add_theme_support('post-formats', array('image', 'gallery', 'video'));
/**
 * 获取CF框架image图片地址
 */
function io_theme_img ($value,$default){
    $cs_value= io_get_option($value);
    if (!empty($cs_value )){
        if(is_numeric( $cs_value )){
            $id_url= wp_get_attachment_image_src( $cs_value, 'full' );
            return $id_url[0];
        }else{
            return $cs_value;
        }
    }
    elseif (empty($cs_value )){
        return $default;
    }
}

/**
 * 时间格式转化
 */
function timeago( $ptime ) {
    $ptime = strtotime($ptime);
    $etime = current_time( 'timestamp' ) - $ptime;
    if($etime < 1) return __('刚刚', 'i_theme');
    $interval = array (
        12 * 30 * 24 * 60 * 60  =>  __('年前', 'i_theme'),//.' ('.date('Y-m-d', $ptime).')',
        30 * 24 * 60 * 60       =>  __('个月前', 'i_theme'),//.' ('.date('m-d', $ptime).')',
        7 * 24 * 60 * 60        =>  __('周前', 'i_theme'),//.' ('.date('m-d', $ptime).')',
        24 * 60 * 60            =>  __('天前', 'i_theme'),
        60 * 60                 =>  __('小时前', 'i_theme'),
        60                      =>  __('分钟前', 'i_theme'),
        1                       =>  __('秒前', 'i_theme')
    );
    foreach ($interval as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . $str;
        }
    };
}

/**
 * 激活友情链接模块
 */
add_filter( 'pre_option_link_manager_enabled', '__return_true' );

/**
 * 自定义后台版权
 */
function remove_footer_admin () {
echo '感谢选择 <a href="https://www.iowen.cn" target="_blank">一为</a> 为您设计！</p>';
}
add_filter('admin_footer_text', 'remove_footer_admin');


/**
 * 禁止自动生成 768px 缩略图
 */
function shapeSpace_customize_image_sizes($sizes) {
    unset($sizes['medium_large']);
    return $sizes;
}
add_filter('intermediate_image_sizes_advanced', 'shapeSpace_customize_image_sizes');
/**
 * wordpress禁用图片属性srcset和sizes
 */
add_filter( 'add_image_size', function(){return 1;} );
add_filter( 'wp_calculate_image_srcset_meta', '__return_false' );
add_filter( 'big_image_size_threshold', '__return_false' );

/**
 * 禁止WordPress自动生成缩略图
 */
function ztmao_remove_image_size($sizes) {
    unset( $sizes['small'] );
    unset( $sizes['medium'] );
    unset( $sizes['large'] );
    return $sizes;
}
add_filter('image_size_names_choose', 'ztmao_remove_image_size');
function io_is_login() {
    return in_array($GLOBALS['pagenow'], array('wp-login.php', 'wp-register.php'));
}
/**
 * 启用静态资源cdn
 */
function io_rewrite_cdn_url(){
    function io_rewrite_assets($html){
        $cdn_path    = io_get_option('cdn_path', 'wp-');
        $pattern     = '/' . str_replace('/', '\/', home_url()) . '\/' . $cdn_path . '([^"\']*?)\.(' . get_option('io_swallow_option')["cdn_res"] . ')/i';
        $replacement = get_option('io_swallow_option')['cdn_url'].'/' . $cdn_path . '$1.$2';
        $html        = preg_replace($pattern, $replacement, $html);
        return $html;
    }
    if(!is_admin() && !io_is_login()){// TODO 
        ob_start("io_rewrite_assets");
    }
}
if(io_get_option('io_cdn_on')) add_action('init', 'io_rewrite_cdn_url',55);

/**
 * 字体增加
 */
function custum_fontfamily($initArray){  
    $initArray['font_formats'] = "微软雅黑='微软雅黑';宋体='宋体';黑体='黑体';仿宋='仿宋';楷体='楷体';隶书='隶书';幼圆='幼圆';";  
    return $initArray;  
}  
add_filter('tiny_mce_before_init', 'custum_fontfamily');

/**
 * 去掉描述P标签
 */
function deletehtml($description) {
    $description = trim($description);
    $description = strip_tags($description,"");
    return ($description);
}
add_filter('category_description', 'deletehtml');


/**
 * 评论作者链接跳转
 * or
 * 评论作者链接新窗口打开
 */
if (io_get_option('comment_to')) {
    add_filter('get_comment_author_link', 'comment_author_link_to');
    function comment_author_link_to() {
        $encodeurl = get_comment_author_url();
        $url = go_to($encodeurl);
        $author = get_comment_author();
        if ( empty( $encodeurl ) || 'http://' == $encodeurl )
            return $author;
        else
            return "<a href='$url' target='_blank' rel='external nofollow' class='url'>$author</a>";
    }
} else {
    add_filter('get_comment_author_link', 'comment_author_link_blank');
    function comment_author_link_blank() {
        $url    = get_comment_author_url();
        $author = get_comment_author();
        if ( empty( $url ) || 'http://' == $url )
            return $author;
        else
            return "<a target='_blank' href='$url' rel='external nofollow' class='url'>$author</a>";
    }
}


function io_get_delimiter()
{
	return io_get_option('io_seo_title_sep') ? : '-';
}


/**
 * 搜索结果排除所有页面
 */
function search_filter_page($query) {
    if ($query->is_search) {
        $query->set('post_type', 'post');
    }
    return $query;
}
add_filter('pre_get_posts','search_filter_page');

/**
 * 正文外链跳转和自动nofollow
 * --------------------------------------------------------------------
 */
function ioc_seo_wl( $content ) {
    //$regexp = "<a\s[^>]*href=(\"??)([^\" >]*?)\\1[^>]*>";
    $regexp = "<a(.*?)href=('|\")([^>]*?)('|\")(.*?)>(.*?)<\/a>";
    if(preg_match_all("/$regexp/i", $content, $matches, PREG_SET_ORDER)) { // s 匹配换行
        if( !empty($matches) ) {
            $srcUrl = get_option('siteurl') ?: home_url();
            for ($i=0; $i < count($matches); $i++)
            { 
                $url = $matches[$i][3];
                if ( "#" !==substr($url, 0, 1) && false === strpos($url, $srcUrl) ) {
                    $_url=$matches[$i][3];
                    if(io_get_option('link_to', false) && is_go_exclude($_url)===false && !preg_match('/\.(jpg|jpeg|png|ico|bmp|gif|tiff)$/i',$_url) && !preg_match('/(ed2k|thunder|Flashget|flashget|qqdl):\/\//i',$_url)) {
                        $_url= go_to($_url);
                    }
                    $tag = '<a'.$matches[$i][1].'href='.$matches[$i][2].$_url.$matches[$i][4].$matches[$i][5].'>';
                    $tag2 = '<a'.$matches[$i][1].'href='.$matches[$i][2].$url.$matches[$i][4].$matches[$i][5].'>';
                    $noFollow = '';
                    $pattern = '/target\s*=\s*"\s*_blank\s*"/';
                    preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
                    if( count($match) < 1 ){
                        $noFollow .= ' target="_blank" ';
                    }
                    $pattern = '/rel\s*=\s*"\s*[n|d]ofollow\s*"/';
                    preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE);
                    if( count($match) < 1 ){
                        $noFollow .= ' rel="nofollow noopener" ';
                    }
                    if(strpos($matches[$i][6],'<img') === false){
                        $pattern = '/class\s*=\s*"\s*(.*?)\s*"/';  //追加class的方法-------------------------------------------------------------
                        preg_match($pattern, $tag2, $match, PREG_OFFSET_CAPTURE); 
                        if( count($match) > 0 ){
                            $tag = str_replace($match[1][0],'external '.$match[1][0],$tag); 
                        }else{
                            $noFollow .= ' class="external" ';
                        }
                    }
                    $tag = rtrim ($tag,'>');
                    $tag .= $noFollow.'>';
                    $content = str_replace($tag2,$tag,$content); 
                }
            }
        }
    }
    return $content;
}
add_filter( 'the_content', 'ioc_seo_wl',10);

/**
 * 网址块 go 跳转
 * @param string $url 外链地址
 * @param bool $forced 强制转换
 * @return string
 */
function go_to($url, $forced=false){
    if($forced)
        return esc_url(home_url()).'/go/?url='.urlencode(base64_encode($url)) ;
    if(io_get_option('link_to',false)){
        if(is_go_exclude($url))
            return $url;
        else
            return esc_url(home_url()).'/go/?url='.urlencode(base64_encode($url)) ;
    }
    else
        return $url;
}
/**
 * 添加go跳转，排除白名单
 * ******************************************************************************************************
 */
function is_go_exclude($url){ 
    $exclude_links = array();
    $site = esc_url(home_url());
    if (!$site)
        $site = get_option('siteurl');
    $site = str_replace(array("http://", "https://"), '', $site);
    $p = strpos($site, '/');
    if ($p !== FALSE)
        $site = substr($site, 0, $p);/*网站根目录被排除在屏蔽之外，不仅仅是博客网址*/
    $exclude_links[] = "http://" . $site;
    $exclude_links[] = "https://" . $site;
    $exclude_links[] = 'javascript';
    $exclude_links[] = 'mailto';
    $exclude_links[] = 'skype';
    $exclude_links[] = '/';/* 有关相对链接*/
    $exclude_links[] = '#';/*用于内部链接*/

    
    if($ex = io_get_option('exclude_links')){
        $a = explode(PHP_EOL , $ex);
        $exclude_links = array_merge($exclude_links, $a);
    }
    foreach ($exclude_links as $val){
        if (stripos(trim($url), trim($val)) === 0) {
            return true;
        }
    }
    return false;
}

function get_post_banner(){
    global $post;
    if(get_post_meta( get_the_ID(), '_top_video', true )){
        get_template_part( 'templates/banner/banner','video' );
    }else{
    switch(io_get_option('single_region')){
        case 'list1':
            get_template_part( 'templates/banner/banner','1' );
            break;
        case 'list2':
            get_template_part( 'templates/banner/banner','2' );
            break;
        case 'list3':
            get_template_part( 'templates/banner/banner','3' );
            break;
        case 'no_img':
            get_template_part( 'templates/banner/banner','no-img' );
            break;
        default:
            get_template_part( 'templates/banner/banner','2' );
    } 
    }
}


/**
 * 添加菜单
 * --------------------------------------------------------------------
 */
function io_wp_menu($location, $class = ''){
    if (function_exists('wp_nav_menu') && has_nav_menu($location)) {
        wp_nav_menu(
            array(
                'container'       => false,
                'items_wrap'      => '%3$s',
                'theme_location'  => $location,
                'container_class' => $class
            )
        );
    } else {
        if (current_user_can('manage_options')) {
            echo '<li><a href="' . get_option('siteurl') . '/wp-admin/nav-menus.php">' . __('请到[后台->外观->菜单]中设置菜单。', 'i_theme') . '</a></li>';
        }
    }
}
/**
 * 编辑菜单后删除相应菜单缓存
 * --------------------------------------------------------------------
 */
function io_delete_menu_cache($menu_id) {  
    if (wp_using_ext_object_cache()){
        //$_menu = wp_get_nav_menu_object( $menu_id );
        wp_cache_delete('io_menu_list_'.$menu_id);
    }
    delete_transient('io_menu_list_'.$menu_id);
}
add_action( 'wp_update_nav_menu', 'io_delete_menu_cache', 10, 1 );
/**
 * 隐藏 姓，名 和 显示的名称，三个字段
 */
add_action('show_user_profile','io_edit_user_profile');
add_action('edit_user_profile','io_edit_user_profile');
function io_edit_user_profile($user){
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('#first_name').parent().parent().hide();
        $('#last_name').parent().parent().hide();
        $('#display_name').parent().parent().hide();
        $('.show-admin-bar').hide();
    });
    </script>
<?php
}
//更新时候，强制设置显示名称为昵称
add_action('personal_options_update','io_edit_user_profile_update');
add_action('edit_user_profile_update','io_edit_user_profile_update');
function io_edit_user_profile_update($user_id){
    if (!current_user_can('edit_user', $user_id))
        return false;

    $user = get_userdata($user_id);

    $_POST['nickname']        = ($_POST['nickname'])?:$user->user_login;
    $_POST['display_name']    = $_POST['nickname'];

    $_POST['first_name']    = '';
    $_POST['last_name']        = '';
}

/**
 * 百度主动推送
 */
if (io_get_option('baidu_submit')) {
    // 主动推送
    if(!function_exists('Baidu_Submit')){
        function Baidu_Submit($post_ID) {
            $WEB_DOMAIN = home_url();
            if(get_post_meta($post_ID,'Baidusubmit',true) == 1) return;
            $url = get_permalink($post_ID);
            $api = 'http://data.zz.baidu.com/urls?site='.$WEB_DOMAIN.'&token='.io_get_option('token_p');
            $request = new WP_Http;
            $result = $request->request( $api , array( 'method' => 'POST', 'body' => $url , 'headers' => 'Content-Type: text/plain') );
            $result = json_decode($result['body'],true);
            if (array_key_exists('success',$result)) {
                add_post_meta($post_ID, 'Baidusubmit', 1, true);
            }
        }
        add_action('publish_post', 'Baidu_Submit', 0);
    }
}

/**
 * 面包屑
 */
function get_breadcrumbs($class = ""){
    global $wp_query;
    if ( !is_home() || !is_front_page() ){
        echo '<nav class = "crumb-menu '.$class.'">';
        echo '<i class="iconfont icon-location mr-1"></i><a href="'. home_url() .'">'.__('首页','i_theme').'</a>';
        if ( is_category() ) {
            $catTitle = single_cat_title( "", false );
            $cat = get_cat_ID( $catTitle );
            echo  get_category_parents( $cat, TRUE, "" );
        } elseif ( is_archive() && !is_category() ) {
            echo __("类目",'i_theme');
        } elseif ( is_search() ) {
            echo __("搜索列表",'i_theme');
        } elseif ( is_404() ) {
            echo "404 Not Found";
        } elseif ( is_single() ) {
            $category = get_the_category();
            $category_id = get_cat_ID( $category[0]->cat_name );
            echo get_category_parents( $category_id, TRUE, "" );
            echo __("正文",'i_theme');
        }
        elseif ( is_page() ) {
            $post = $wp_query->get_queried_object();
            if ( $post->post_parent == 0 ){
                echo the_title('','', FALSE);
            } else {
                $title = the_title('','', FALSE);
                $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
                array_push($ancestors, $post->ID);
                foreach ( $ancestors as $ancestor ){
                    if( $ancestor != end($ancestors) ){
                        echo '<a href="'. get_permalink($ancestor) .'">'. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</a>';
                    } else {
                    echo strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) );
                    }
                }
            }
        }
        echo '</nav>';
    }
}

/**
 * 识别当前作者身份
 */
function ioc_level() { 
    $user_id=get_post(get_the_ID())->post_author;   
    if(user_can($user_id,'install_plugins')){
        echo'<span>'.__('博主','i_theme').'</span>';
    } elseif(user_can($user_id,'edit_others_posts')) {
        echo'<span>'.__('编辑','i_theme').'</span>';
    } elseif(user_can($user_id,'publish_posts')) {
        echo'<span>'.__('作者','i_theme').'</span>';
    } elseif(user_can($user_id,'delete_posts')) {
        echo'<span>'.__('投稿者','i_theme').'</span>';
    } elseif(user_can($user_id,'read')) {
        echo'<span>'.__('订阅者','i_theme').'</span>';
    }
}

/**
 * 去掉正文图片外围标签p、自动添加 a 标签和 data-src
 * ******************************************************************************************************
 */
function lazyload_fancybox($content) {
    global $post;
    $title = $post->post_title;
    $loadimg_url=get_template_directory_uri().'/images/t.png';
      //判断是否为文章页或者页面
    if(!is_single())
        return $content;
    if(!is_feed()||!is_robots()) {
        $content = preg_replace('/<p>\s*(<a .*>)?\s*(<img .* \/>)\s*(<\/a>)?\s*<\/p>/iU', '$1$2$3', $content);
        if(io_get_option('img_box',true)){
            //添加 fancybox，仅添加自带a标签的图片，其余的js处理
            $pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>(.*?)<\/a>/i";
            $replacement = '<a$1href=$2$3.$4$5 data-fancybox="images" data-caption="'.$title.'"$6>$7</a>';
            $content = preg_replace($pattern, $replacement, $content);
        }
        //添加懒加载
        $imgpattern   = '/<img(.*?)src=[\'|"]([^\'"]+)[\'|"](.*?)>/i';
        //$imgpattern = "/<img(.*?)src=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>/i";
        if(io_get_option('lazyload')){
            $imgreplacement = '<img$1data-src="$2" src="'.$loadimg_url.'" alt="'.$title.'"$3>';
        } else {
            $imgreplacement = '<img$1src="$2" alt="'.$title.'"$3>';
        }
        $content = preg_replace($imgpattern,$imgreplacement,$content);
    }
    return $content;
} 
add_filter ('the_content', 'lazyload_fancybox',10);

function theme_mode(){
    if (isset($_COOKIE['io_night_mode'])) {
        return (trim($_COOKIE['io_night_mode']) == '0' ? 'ioc-dark-mode' : ''); 
    } else{
        $time = current_time('G');
        $time_auto = io_get_option('time_auto',array('from'=>'07','to'=>'18')); 
        switch (io_get_option('night_theme', 'light')) {
            case 'time-auto':
                if ($time > $time_auto['to']  || $time <  $time_auto['from'] ) {
                    return 'ioc-dark-mode';
                }
                break;
            case 'dark':
                return 'ioc-dark-mode';
                break;
        }
    }
    return '' ; 
}

function io_html_class(){
    echo theme_mode();
}
function io_auto_theme_mode(){
    if(get_query_var('bookmark_id')){
        return '';
    }
    $auto_mode = io_get_option('night_theme', 'light');
    if ($auto_mode=='auto-system' || (defined( 'WP_CACHE' ) && WP_CACHE)) {
        $ars = '';
        if($auto_mode=='auto-system')
            $ars = ' || (!night && window.matchMedia("(prefers-color-scheme: dark)").matches)';
        echo '<script>
    var night = document.cookie.replace(/(?:(?:^|.*;\s*)io_night_mode\s*\=\s*([^;]*).*$)|^.*$/, "$1"); 
    try {
        if (night === "0"'.$ars.') {
            document.documentElement.classList.add("ioc-dark-mode");
        } else {
            document.documentElement.classList.remove("ioc-dark-mode");
        }
    } catch (_) {}
</script>';
    }
}

function get_ref_url($args, $url, $raw){
    if($raw) return $url;
    if(is_array($args)&& count($args)>0){
        $temp = array();
        foreach($args as $v){
            $temp[$v['key']] = $v['value'];
        }
        return add_query_arg( $temp, $url );
    }else{
        return $url;
    }
}
/**
 * 分页代码
 */
if ( !function_exists('par_pagenavi') ) {
    function par_pagenavi( $p = 2 ) { // 取当前页前后各 2 页
        if ( is_singular() ) return; // 文章与插页不用
        global $wp_query, $paged;
        $max_page = $wp_query->max_num_pages;
        if ( $max_page == 1 ) return; // 只有一页不用
        if ( empty( $paged ) ) $paged = 1;
        
        if ( $paged > 1 ) p_link( $paged - 1, __('上一页' , 'i_theme' ), '&lt;' );/* 如果当前页大于1就显示上一页链接 */
        if ( $paged > $p + 1 ) p_link( 1, __('最前页' , 'i_theme' ) );
        if ( $paged > $p + 2 ) echo '<a class="page-numbers">...</a>';
        for( $i = $paged - $p; $i <= $paged + $p; $i++ ) { // 中间页
            if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<a class='page-numbers current' href='javascript:void(0);'>{$i}</a> " : p_link( $i );
        }
        if ( $paged < $max_page - $p - 1 ) echo '<a class="page-numbers" href="javascript:void(0);">...</a> ';
        if ( $paged < $max_page - $p ) p_link( $max_page, __('最后页' , 'i_theme' ) );
        if ( $paged < $max_page ) p_link( $paged + 1,__('下一页' , 'i_theme' ), ' &gt;' );/* 如果当前页不是最后一页显示下一页链接 */
        echo '<a class="page-numbers" href="javascript:void(0);">' . $paged . ' / ' . $max_page . ' </a> '; // 显示页数
    }
    function p_link( $i, $title = '', $linktype = '' ) {
        if ( $title == '' ) $title = sprintf(__('第 %s 页' , 'i_theme' ),$i);
        if ( $linktype == '' ) { $linktext = $i; } else { $linktext = $linktype; }
        echo "<a class='page-numbers' href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$linktext}</a> ";
    }
}

/**
 * 文章内分页
 */
function iowen_link_pages($args = '') {      
    $defaults = array(      
        'before'            => '<p>' . __('页:' , 'i_theme' ), 
        'after'             => '</p>',      
        'link_before'       => '', 
        'link_after'        => '',      
        'next_or_number'    => 'number', 
        'nextpagelink'      => __('下一页' , 'i_theme' ),      
        'previouspagelink'  => __('上一页' , 'i_theme' ), 
        'pagelink'          => '%',      
        'echo'              => 1      
    );      
    $r = wp_parse_args( $args, $defaults );      
    $r = apply_filters( 'wp_link_pages_args', $r );      
    extract( $r, EXTR_SKIP );      
    global $page, $numpages, $multipage, $more, $pagenow;      
    $output = '';      
    if ( $multipage ) {      
        if ( 'number' == $next_or_number ) {      
            $output .= $before;      
            for ( $i = 1; $i < ($numpages+1); $i = $i + 1 ) {      
                $j = str_replace('%',$i,$pagelink);      
                $output .= ' ';      
                if ( ($i != $page) || ((!$more) && ($page==1)) ) {      
                    $output .= _wp_link_page($i);      
                    $output .= $link_before . $j . $link_after;//将原本在下面的那句移进来了      
                }else{  //加了个else语句，用来判断当前页，如果是的话输出下面的      
                    $output .= '<a href="javascript:void(0);" class="page-numbers current">' . $j . '</a>';      
                }      
                //原本这里有一句，移到上面去了      
                if ( ($i != $page) || ((!$more) && ($page==1)) )      
                    $output .= '</a>';      
            }      
            $output .= $after;      
        } else {      
            if ( $more ) {      
                $output .= $before;      
                $i = $page - 1;      
                if ( $i && $more && $previouspagelink ) { //if里面的条件加了$previouspagelink也就是只有参数有“上一页”这几个字才显示      
                    $output .= _wp_link_page($i);      
                    $output .= $link_before. $previouspagelink . $link_after . '</a>';      
                }      
                $i = $page + 1;      
                if ( $i <= $numpages && $more && $nextpagelink ) {      
                //if里面的条件加了$nextpagelink也就是只有参数有“下一页”这几个字才显示      
                    $output .= _wp_link_page($i);      
                    $output .= $link_before. $nextpagelink . $link_after . '</a>';      
                }      
                $output .= $after;      
            }      
        }      
    }      
    if ( $echo )      
        echo $output;      
    return $output;      
}  

/**
 * 关键词加链接
 * ******************************************************************************************************
 */
if (io_get_option('tag_c', false, 'switcher')) {
    add_filter('the_content','tag_link',8);
    function tag_link($content){
        $option = io_get_option('tag_c');
        global $post_type;
        $match_num_from = 1;        //配置：一个关键字少于多少不替换  
        $match_num_to = $option['chain_n'];        //配置：一个关键字最多替换，建议不大于2  
        if ( isset($option['tags']) && $custom_tag = $option['tags']) {
            $case = false ? "i" : ""; //配置：忽略大小写 true是开，false是关  
            foreach($custom_tag as $tag) {
                $link = $tag['url'];
                $keyword = $tag['tag'];
                $cleankeyword = stripslashes($keyword);
                $describe = $tag['describe']?:str_replace('%s',addcslashes($cleankeyword, '$'),__('查看与 %s 相关的文章', 'i_theme' ));
                $limit = rand($match_num_from,$match_num_to);
                $content = tag_to_url($link,$cleankeyword,$describe,$limit,$content,$case);
            }
        }
        if($option['auto']){
            $post_tags = get_the_tags(); 
            if ($post_tags) {
                $sort_func = function($a, $b){
                    if ( $a->name == $b->name ) return 0;
                    return ( strlen($a->name) > strlen($b->name) ) ? -1 : 1;
                };
                usort($post_tags, $sort_func);//重新排序
                $case = false ? "i" : ""; //配置：忽略大小写 true是开，false是关  
                foreach($post_tags as $tag) {
                    $link = get_tag_link($tag->term_id);
                    $keyword = $tag->name;
                    $cleankeyword = stripslashes($keyword);
                    $describe = str_replace('%s',addcslashes($cleankeyword, '$'),__('查看与 %s 相关的文章', 'i_theme' ));
                    $limit = rand($match_num_from,$match_num_to);
                    $content = tag_to_url($link,$cleankeyword,$describe,$limit,$content,$case);
                }
            }
        }
        return $content;
    }
}
function tag_to_url($link,$cleankeyword,$describe,$limit,$content,$case,$ex_word=''){
    $url = "<a class=\"external balloon\" href=\"$link\" title=\"".$describe."\"";
    $url .= ' target="_blank"';
    $url .= "><span data-balloon=\"$describe\" data-balloon-pos=\"up\">".addcslashes($cleankeyword, '$')."</span></a>"; 
    $ex_word = preg_quote($cleankeyword, '\''); 
    $content = unlink_pre($content,$ex_word,"%&&&&&%");//代码，免混淆处理 
    /*$content = preg_replace( '|(<a[^>]+>)(.*)<pre.*?>('.$ex_word.')(.*)<\/pre>(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);*///a标签，免混淆处理  
    $content = preg_replace( '|(<a[^>]+>)(.*)('.$ex_word.')(.*)(</a[^>]*>)|U'.$case, '$1$2%&&&&&%$4$5', $content);//a标签，免混淆处理  
    $content = preg_replace( '|(<img)(.*?)('.$ex_word.')(.*?)(>)|U'.$case, '$1$2%&&&&&%$4$5', $content);//img标签
    $content = preg_replace( '|(\[)(.*?)('.$ex_word.')(.*?)(\])|U'.$case, '$1$2%&&&&&%$4$5', $content);//短代码标签
    $cleankeyword = preg_quote($cleankeyword,'\'');
    $regEx = '\'(?!((<.*?)|(<a.*?)))('. $cleankeyword . ')(?!(([^<>]*?)>)|([^>]*?</a>))\'s' . $case;
    $content = preg_replace($regEx,$url,$content,$limit);
    $content = str_replace( '%&&&&&%', stripslashes($ex_word), $content);//免混淆还原处理  
    return $content;
}
function unlink_pre($content,$ex_word,$replace){
    preg_match_all("/(<pre[^>]+>)([\s\S]*)($ex_word)([\s\S]*)(<\/pre[^>]*>)/",$content,$matches);
    if(count($matches[3])>0){
        $content = preg_replace( '|(<pre[^>]+>)([\s\S]*)('.$ex_word.')([\s\S]*)(</pre[^>]*>)|U', '$1$2'.$replace.'$4$5', $content);//代码，免混淆处理  
        return unlink_pre($content,$ex_word,$replace);
    }
    return $content;
}

function unlink_pre_o($content,$ex_word,$replace){
    preg_match_all("/(.*?<pre[^>]+>)(.*?)(<\/pre[^>]*>.*?)/s",$content,$matches);
    if(count($matches[1])>0){
        $h="";
        for($i=0;$i<count($matches[1]);$i++){
            if(!empty($matches[2][$i])){
                $h .= $matches[1][$i].str_replace($ex_word,$replace,$matches[2][$i]).$matches[3][$i];
            }else{
                $h .= $matches[0][$i];
            }
        }
        return $h;
    }
    return $content;
}
//获取作者所有文章点赞数
if(!function_exists('author_posts_likes')) {
    function author_posts_likes($author_id = 'all' ,$display = false) {
        global $wpdb;
        if($author_id == 'all')
            $sql = "SELECT sum(meta_value) FROM $wpdb->postmeta WHERE meta_key='_like_count'";
        else
            $sql = "SELECT SUM(meta_value+0) FROM $wpdb->posts left join $wpdb->postmeta on ($wpdb->posts.ID = $wpdb->postmeta.post_id) WHERE meta_key = '_like_count' AND post_author = $author_id ";
        $posts_likes = intval($wpdb->get_var($sql));        
        if($display) {
            echo number_format_i18n($posts_likes);
        } else {
            return $posts_likes;
        }
    }
}

//获取作者参与评论的评论数
if(!function_exists('author_posts_comments')) {
    function author_posts_comments( $author_id = 'all' ,$author_email='' ,$display = false) {
        global $wpdb;
        if($author_id == 'all')
            $sql = "SELECT COUNT(*) FROM $wpdb->comments";
        else
            $sql = "SELECT count(comment_author) FROM $wpdb->comments WHERE comment_approved='1' AND comment_type='' AND (user_id = '$author_id'  OR comment_author_email='$author_email' )";
        $posts_comments = intval($wpdb->get_var($sql));        
        if($display) {
            echo number_format_i18n($posts_comments);
        } else {
            return $posts_comments;
        }
    }
}

/**
 * 浏览总数
 */
function author_posts_views($author_id = 'all',$display = false){
    global $wpdb;
    if($author_id == 'all')
        $sql = "SELECT sum(meta_value) FROM $wpdb->postmeta WHERE meta_key='views'";
    else
        $sql = "SELECT SUM(meta_value+0) FROM $wpdb->posts left join $wpdb->postmeta on ($wpdb->posts.ID = $wpdb->postmeta.post_id) WHERE meta_key = 'views' AND post_author =$author_id";    
    $comment_views = intval($wpdb->get_var($sql));
    if($display) {
        echo number_format_i18n($comment_views);
    } else {
        return $comment_views;
    }
}

/**
 * 文章归档更新
 */
add_action('save_post','clear_archives');
function clear_archives() {
    update_option('io_archives_list', '');
}

/**
 * 搜索关键词为空
 */
function mt_redirect_blank_search( $query_variables ) {
    if (isset($_GET['s']) && !is_admin()) {
        if (empty($_GET['s']) || ctype_space($_GET['s'])) {
            wp_redirect( home_url() );
            exit;
        }
    }
    return $query_variables;
}
add_filter( 'request', 'mt_redirect_blank_search' );


/**
 * 评论格式
 */
if(!function_exists('io_comment_format')){
    function io_comment_format($comment, $args, $depth){
        $GLOBALS['comment'] = $comment;
        ?>
        <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
            <div id="comment-<?php comment_ID(); ?>" class="comment_body contents">    
                <div class="profile"> 
                    <?php 
                    //$avatarimg = get_avatar( $comment, 96, '', get_comment_author() );
                    $avatarimg = get_avatar($comment->comment_author_email, 96,'',$comment->display_name, array('class'=>'v-avatar'));
                    ?>
                    <?php if (io_get_option('lazyload')) { ?>
                    <?php echo '<img class="avatar" src="' . get_template_directory_uri() . '/images/loading.gif" alt="avatar" data-src="' . preg_replace(array('/^.+(src=)(\"|\')/i','/(\"|\')\ssrcset=(\"|\').+$/i', '/(\"|\')\sclass=(\"|\').+$/i'), array('', '', ''), $avatarimg ) . '" />'; ?>
                    <?php } else { ?>
                    <?php echo $avatarimg ?>
                    <?php } ?>
                </div>                    
                <section class="commeta">
                    <div class="left">
                        <h4 class="author"><?php comment_author_link(); ?>
                        <?php is_master( $comment->comment_author_email ); echo site_rank( $comment->comment_author_email, $comment->user_id ); ?>
                        </h4> 
                        <?php if(io_get_option('ip_location',false,'comment')){ ?>
                        <span class="info-location text-xs mt-2 d-block"><i class="iconfont icon-location mr-1"></i><?php echo io_get_ip_location(get_comment_author_ip()) ?></span>
                        <?php } ?>
                    </div>
                    <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
                    <div class="right">
                        <div class="info"><time itemprop="datePublished" datetime="<?php echo get_comment_date( 'c' );?>"><?php echo timeago(get_comment_date('Y-m-d G:i:s'));?></time></div>
                    </div>
                </section>
                <div class="body">
                    <?php comment_text(); ?> 
                    <?php
                    if ($comment->comment_approved == '0'){
                        echo '<span class="cl-approved">('.__('您的评论需要审核后才能显示！', 'i_theme' ).')</span><br />';
                    } 
                    ?>
                </div>
            </div>
        
        <?php
    }
}

/**
 * 禁止冒充管理员评论
 */
function usercheck($incoming_comment) {
    $isSpam = 0;
    if (trim($incoming_comment['comment_author']) == ''.io_get_option('admin_name').'')
    $isSpam = 1;
    if (trim($incoming_comment['comment_author_email']) == ''.io_get_option('admin_email').'')
    $isSpam = 1;
    if(!$isSpam)
    return $incoming_comment;
    err(__('请勿冒充管理员发表评论！', 'i_theme' ));
}
if (!is_user_logged_in()) {
    add_filter('preprocess_comment', 'usercheck');
}


// 用户文章
function num_of_author_posts($authorID=''){
    if ($authorID) {
        $author_query = new WP_Query( 'posts_per_page=-1&author='.$authorID );
        $i=0;
        while ($author_query->have_posts()) : $author_query->the_post(); ++$i; endwhile; wp_reset_postdata();
        return $i;
    }
    return false;
}
/**  
 * 创建页面
 * @param string $title 页面标题  
 * @param string $slug 页面别名  
 * @param string $page_template 模板名  
 * @return null
 */  
function io_add_page($title,$slug,$page_template=''){   
    $allPages = get_pages();//获取所有页面   
    $exists = false;   
    foreach( $allPages as $page ){   
        //通过页面别名来判断页面是否已经存在   
        if( strtolower( $page->post_name ) == strtolower( $slug ) ){   
            $exists = true;   
        }   
    }   
    if( $exists == false ) {   
        $new_page_id = wp_insert_post(   
            array(   
                'post_title' => $title,   
                'post_type'     => 'page',   
                'post_name'  => $slug,   
                'comment_status' => 'closed',   
                'ping_status' => 'closed',   
                'post_content' => '',   
                'post_status' => 'publish',   
                'post_author' => 1,   
                'menu_order' => 0   
            )   
        );   
        //如果插入成功 且设置了模板   
        if($new_page_id && $page_template!=''){   
            //保存页面模板信息   
            update_post_meta($new_page_id, '_wp_page_template',  $page_template);   
        }   
    }   
}

/**
 * 在启用WP_CACHE的情况下切换主题状态
 */
//add_action('wp_print_scripts','dark_mode_js');
function dark_mode_js(){
    if( defined( 'WP_CACHE' ) && WP_CACHE ){
    echo '<script type="text/javascript"> 
    var night = document.cookie.replace(/(?:(?:^|.*;\s*)io_night_mode\s*\=\s*([^;]*).*$)|^.*$/, "$1"); 
    if(night == "1"){
        document.body.classList.remove("ioc-dark-mode");
    }else if(night == "0"){
        document.body.classList.add("ioc-dark-mode");
    }
    </script> ';
    }
}

//iowen-----
//屏蔽长链接
function lang_url_spamcheck($approved, $commentdata) {
    return (strlen($commentdata['comment_author_url']) > 50) ?
    'spam' : $approved;
}
add_filter('pre_comment_approved', 'lang_url_spamcheck', 99, 2);

/**
 * 修改url重写后的作者存档页的链接变量
 */
add_filter('author_link', 'author_link', 10, 2);
function author_link( $link, $author_id) {
    global $wp_rewrite;
    $author_id = (int) $author_id;
    $link = $wp_rewrite->get_author_permastruct();
    if ( empty($link) ) {
        $file = home_url( '/' );
        $link = $file . '?author=' . $author_id;
    } else {
        $link = str_replace('%author%', $author_id, $link);
        $link = home_url( user_trailingslashit( $link ) );
    }
    return $link;
}
add_filter('request', 'author_link_request');
function author_link_request( $query_vars ) {
    if ( array_key_exists( 'author_name', $query_vars ) ) {
        global $wpdb;
        $author_id=$query_vars['author_name'];
        if ( $author_id ) {
            $query_vars['author'] = $author_id;
            unset( $query_vars['author_name'] );    
        }
    }
    return $query_vars;
}

/**
 * 屏蔽用户名称类
 */
add_filter('comment_class','remove_comment_body_author_class');
add_filter('body_class','remove_comment_body_author_class');
function remove_comment_body_author_class( $classes ) {
    foreach( $classes as $key => $class ) {
    if(strstr($class, "comment-author-")||strstr($class, "author-")) {
            unset( $classes[$key] );
        }
    }
    return $classes;
}

/**
 * 评论机器评论验证
 */
function ma_robot_comment(){
    if ( !isset($_POST['no-robot']) && !is_user_logged_in()) {
        err(__('请解锁后再提交评论!' , 'i_theme' ));
    }
}
if(io_get_option('ma_comment_unlock')) add_action('pre_comment_on_post', 'ma_robot_comment');    


function author_custom_post($query) {
    if ( !is_admin() && is_page('shuoshuo') ) :
        $query->set('post_type', array('shuoshuo'));
        //$query->set('post_per_page', 10);  // 每页显示的文章数量必须与author.php 中的保持一致
        endif;
    }
//add_action('pre_get_posts', 'author_custom_post');


//新文章标识
function new_post($post_date){
    $t2=current_time( 'timestamp' );
    $t3=168;
    $diff=($t2-strtotime($post_date))/3600;
    if($diff<$t3){ return '<span class="slice-sign">NEW</span>'; }
}
//新微语提升
function new_shuo($post_date){
    $t2=current_time( 'timestamp' );
    $t3=168;
    $diff=($t2-strtotime($post_date))/3600;
    if($diff<$t3){ return 'show'; }
}
/**
 * 获取大分类文章总数。
 */
function get_all_cat_postcount($id) { 
    // 获取当前分类信息 
    $cat = get_category($id); 
    // 当前分类文章数 
    $count = (int) $cat->count; 
    // 获取当前分类所有子孙分类 
    $tax_terms = get_terms('category', array('child_of' => $id)); 
    foreach ($tax_terms as $tax_term) { 
        // 子孙分类文章数累加 
        $count +=$tax_term->count; 
    } 
    return $count; 
}

if (io_get_option('baidu_xzh')) { require get_template_directory() . '/inc/baidu-xzh.php';}

/**
 * 定制CSS
 */
add_action('wp_head','modify_css');
function modify_css(){
    if (io_get_option("custom_css")) {
        $css = substr(io_get_option("custom_css"), 0);
        echo "<style>" . $css . "</style>";
    }
}

/**
 * 获取各种Url
 */
function get_url_for($key, $arg = null, $relative = false){
    $endpoint = null;
    switch ($key){
        case 'shop_archive':
            $endpoint = 'sdasd';
            break;
        case 'edit_post':
            $endpoint = '';
            break;
        case 'download':
            $endpoint = '';
            break;
    }
    if($endpoint){
        return $relative ? '/' . $endpoint : home_url('/' . $endpoint);
    }
    return false;
}

/**
 * 页脚年份
 */
function io_copyright_year(){
    $now_year = date('Y');
    $open_date = io_get_option('io_site_open_date');
    $open_year = substr($open_date, 0, 4);

    return $open_year . '-' . $now_year;
}

/**
 * 字数统计
 */
function count_words ($text) {
    global $post;
    if ( '' == $text ) {
        $output='';
        $text = $post->post_content;
        if (mb_strlen($output, 'UTF-8') < mb_strlen($text, 'UTF-8')) $output .= ''.sprintf(__( '共', 'i_theme' )).' ' . mb_strlen(preg_replace('/\s/','',html_entity_decode(strip_tags($post->post_content))),'UTF-8') . ' '.sprintf(__( '字', 'i_theme' )).'';
        return $output;
    }
}

/**
 * 查询IP地址
 * @param mixed $ip
 * @param mixed $level 1国家 2省 3市 4国家加省 5省加市 6详细
 * @return mixed
 */
function io_get_ip_location($ip, $level = '') {
    if (empty($ip))
        return '无记录';
    $option = io_get_option('ip_location', array('level' => 2, 'v4_type' => 'qqwry'));
    $level  = $level ?: (int) $option['level'];
    require_once get_theme_file_path('/inc/classes/ip/function.php');
    $isQQwry = $option['v4_type'] == 'qqwry';
    //$url     = 'http://freeapi.ipip.net/' . $ip;
    $data    = itbdw\Ip\IpLocation::getLocation($ip, $isQQwry);
    if (isset($data['error'])) {
        return '错误：' . $data['msg'];
    }
    switch ($level) {
        case 1:
            $loc = $data['country'];
            break;
        case 2:
            $loc = $data['province'];
            break;
        case 3:
            $loc = $data['city'];
            break;
        case 4:
            $loc = $data['country'] . $data['province'];
            break;
        case 5:
            $loc = $data['province'] . $data['city'];
            break;
        case 6:
            $loc = $data['area'];
            break;
        default:
            $loc = $data['province'];
            break;
    }
    if (empty($loc))
        $loc = '未知';
    return $loc;
}

/**
 * 对于部分链接，拒绝搜索引擎索引
 *
 * @since   2.0.0
 *
 * @param   string  $output    Robots.txt内容
 * @param   bool    $public
 * @return  string
 */
function io_robots_modification( $output, $public ){
    $output .= "\nDisallow: /down";
    return $output;
}
add_filter( 'robots_txt', 'io_robots_modification', 10, 2 );


// 评论链接
add_filter( 'comment_reply_link', 'begin_reply_link', 10, 4 );
function begin_reply_link( $link, $args, $comment, $post ) {
	$onclick = sprintf( 'return addComment.moveForm( "%1$s-%2$s", "%2$s", "%3$s", "%4$s" )',
		$args['add_below'], $comment->comment_ID, $args['respond_id'], $post->ID
	);
	$link = sprintf( "<a rel='nofollow' class='comment-reply-link' href='%s' onclick='%s' aria-label='%s'>%s</a>",
		esc_url( add_query_arg( 'replytocom', $comment->comment_ID, get_permalink( $post->ID ) ) ) . "#" . $args['respond_id'],
		$onclick,
		esc_attr( sprintf( $args['reply_to_text'], $comment->comment_author ) ),
		$args['reply_text']
	);
	return preg_replace( '/href=\'(.*(\?|&)replytocom=(\d+)#respond)/', 'href=\'#comment-$3', $link );
}

// 菜单php
function article_index($content) {
    $matches = array();
    $ul_li = '';
    //匹配出h2、h3标题
    $rh = "/<h[34]>(.*?)<\/h[34]>/im";
    $h3_num = 0;
    $h4_num = 0;
    //判断是否是文章页
    if(is_single()){
        if(preg_match_all($rh, $content, $matches)) {
            // 找到匹配的结果
            foreach($matches[1] as $num => $title) {
                $hx = substr($matches[0][$num], 0, 3);      //前缀，判断是h2还是h3
                $start = stripos($content, $matches[0][$num]);  //匹配每个标题字符串的起始位置
                $end = strlen($matches[0][$num]);       //匹配每个标题字符串的结束位置
                if($hx == "<h3"){
                    $h3_num += 1; //记录h2的序列，此效果请查看百度百科中的序号，如1.1、1.2中的第一位数
                    $h4_num = 0;
                    // 文章标题添加id，便于目录导航的点击定位
                    $content = substr_replace($content, '<h3 id="h3-'.$num.'">'.$title.'</h3>',$start,$end);
                    $title = preg_replace('/<.+?>/', "", $title); //将h2里面的a链接或者其他标签去除，留下文字
                    $ul_li .= '<li id="in'.$num.'" class="h2_smenu"><a class="smooth" href="#h3-'.$num.'"  title="'.$title.'"><i class="iconfont icon-dot-circle-o"></i>'.$title."</a></li>\n";
                }else if($hx == "<h4"){
                    $h4_num += 1; //记录h3的序列，此熬过请查看百度百科中的序号，如1.1、1.2中的第二位数
                    $content = substr_replace($content, '<h4 id="h3-'.$num.'">'.$title.'</h4>',$start,$end);
                    $title = preg_replace('/<.+?>/', "", $title); //将h3里面的a链接或者其他标签去除，留下文字
                    $ul_li .= '<li id="in'.$num.'" class="h3_smenu"><a class="smooth" href="#h4-'.$num.'" title="'.$title.'"><i class="iconfont icon-circle-o"></i>'.$title."</a></li>\n";
                }  
            }
        }
        // 将目录拼接到文章
        $content = '
        <div class="small-menu" >
            <div class="theiaStickySidebar">
                <div class="card card-sm small-menu-body">
                    <h3><i class="iconfont icon-list"></i>'.__('文章目录', 'i_theme' ).'</h3>
                    <ul class="menu_ul">
                        '. $ul_li .'
                    </ul>
                </div>
            </div>
        </div>"'. $content;
    }
    return $content;
}
//add_filter( "the_content", "article_index" );
function io_theme_article_index($content) {
    $matches = array();
    $ul_li = '';
    
    $r = '/<h([2-6]).*?\>(.*?)<\/h[2-6]>/is';
    
    if(is_single() && preg_match_all($r, $content, $matches)) {
    foreach($matches[1] as $key => $value) {
        $title = trim(strip_tags($matches[2][$key]));
        $content = str_replace($matches[0][$key], '<h' . $value . ' id="title-' . $key . '">'.$title.'</h2>', $content);
        $ul_li .= '<li><a href="#title-'.$key.'" title="'.$title.'">'.$title."</a></li>\n";
    }
    
    $content = "\n<div id=\"ui-article-index\">
                <strong>".__('文章目录', 'i_theme' )."</strong>
                <ol id=\"ui-index-ul\">\n" . $ul_li . "</ol>
                </div>\n" . $content;
    }
    return $content;
}
//add_filter( 'the_content', 'io_theme_article_index' );
// 文章内容添加文章目录
function io_content_index($content) {
    if(is_single()){
        $matches = array();
        $ul_li = '';
        $r = "/<h3>([^<]+)<\/h3>/im";
        $i='1';
        if(preg_match_all($r, $content, $matches)) {
            foreach($matches[1] as $num => $title) {
                $content = str_replace($matches[0][$num], '<h3 id="title-'.$num.'">'.$title.'</h3>', $content);
                $ul_li .= '<li><a class="smooth" href="#title-'.$num.'" title="'.$title.'">'.$i.'.'.$title."</a></li>\n";
                $i ++;
            }
            $content = "\n<div id=\"article-index\"><i class=\"fa fa-angle-double-right\" ></i><h4>".__('目 录', 'i_theme' )."</h4>
                    <ul id=\"index-ul\">\n" . $ul_li . "</ul>
                </div>\n" . $content;
        }
    }
    return $content;
}
//add_filter( "the_content", "io_content_index", 13 );

/**
 * 自定义登录地址
 * ------------------------------------------------------------------------------------
 */
function login_protect(){
	if($_GET[io_get_option('login_link','','pass_h')] != io_get_option('login_link','','word_q') )header('Location: '.io_get_option('login_link','','go_link'));
}
if (CUSTOM_URL && io_get_option('login_link','','pass_h'))  add_action('login_enqueue_scripts','login_protect'); // TODO 初始化报错

/**
 * 缓存自动清理
 * 编辑文章-清理文章缓存
 * @description: 
 * @param int $post_id
 * @return null
 */
function io_cache_delete_posts($post_id)
{
	//文章缩略图
	wp_cache_delete($post_id, 'post_thumbnail_url_thumbnail');
	wp_cache_delete($post_id, 'post_thumbnail_url_medium');
	wp_cache_delete($post_id, 'post_thumbnail_url_large');
	wp_cache_delete($post_id, 'post_thumbnail_url_full');
}
add_action('save_post', 'io_cache_delete_posts');


/**
 * 每天执行的定时任务
 *
 */
function io_setup_common_daily_schedule()
{
    if(IO_PRO && !wp_next_scheduled('io_daily_state_event')){
        wp_schedule_event(time(), 'daily', 'io_daily_state_event');
    }
}
add_action('init', 'io_setup_common_daily_schedule');

add_action('generate_rewrite_rules', 'io_rewrite_rules' );   
/**********重写规则************/  
function io_rewrite_rules( $wp_rewrite ){   
    $new_rules = array(    
        'go/?$'          => 'index.php?io_custom_page=go',   
        'down/?$'        => 'index.php?io_custom_page=down', 
        'preview/?$'     => 'index.php?io_custom_page=preview', 
    ); //添加翻译规则   
    $wp_rewrite->rules = $new_rules + $wp_rewrite->rules;   
    //php数组相加   
}  
/*******添加query_var变量***************/  
add_action('query_vars', 'io_add_query_vars');   
function io_add_query_vars($public_query_vars){     
    $public_query_vars[] = 'io_custom_page'; //往数组中添加添加io_custom_page   
    return $public_query_vars;     
}  
//模板载入规则   
add_action("template_redirect", 'io_template_redirect');   
function io_template_redirect(){   
    global $wp;   
    global $wp_query, $wp_rewrite;

    //查询io_custom_page变量   
    if( !isset($wp_query->query_vars['io_custom_page']) )   
        return;   
    $reditect_page =  $wp_query->query_vars['io_custom_page'];   
    //如果io_custom_page等于go，则载入go.php页面   
    //注意 my-account/被翻译成index.php?io_custom_page=hello_page了。  
    switch($reditect_page){
		case "go":
            $wp_query->is_home = false;
			include(TEMPLATEPATH.'/go.php');   
            die();   
			break;
		case "down":
            $wp_query->is_home = false;
			include(TEMPLATEPATH.'/down.php');   
            die(); 
			break;
		case "preview":
            $wp_query->is_home = false;
			include(TEMPLATEPATH.'/preview.php');   
            die(); 
			break;
	}   
}

/**
 * 刷新固定连接
 * @return void
 */
function io_admin_init(){
    if (isset($_REQUEST['page']) &&isset($_REQUEST['action']) && 'theme_settings' === $_REQUEST['page'] && 'rewrite_rules' === $_REQUEST['action']) {
        flush_rewrite_rules();
    }
}
add_action('admin_init', 'io_admin_init', 1);
