<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2022-02-09 21:11:15
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-24 18:03:59
 * @FilePath: \ioswallow\inc\functions\io-login.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*----------------------------------连续登录验证--------------------------------------*/
function io_login_failed($username){
	$key	= IOTOOLS::get_ip();
	$times	= get_transient($key)?: 0;
    if ($times <= io_get_option('login_limit',5)) {
        set_transient($key, $times+1, MINUTE_IN_SECONDS * io_get_option('login_limit_time',10));
    }else{
        set_transient($key, $times+1);
    }
}

function io_login_authenticate($user, $username, $password){
	$key	= IOTOOLS::get_ip();
	$times	= get_transient($key) ?: 0;

	if($times > io_get_option('login_limit',5)){
		remove_filter('authenticate', 'wp_authenticate_username_password', 20, 3);
		remove_filter('authenticate', 'wp_authenticate_email_password', 20, 3);

		return new WP_Error( 'too_many_retries', sprintf(__('你已尝试多次失败登录，请%s分钟后重试！', 'i_theme'),io_get_option('login_limit_time',10)) );
	}

	return $user;
}

function io_shake_error_codes($error_codes){
	$error_codes[]	= 'too_many_retries';
	return $error_codes;
    
}
if (io_get_option('login_limit', 5)>0) {
    add_action('wp_login_failed', 'io_login_failed');
    add_filter('authenticate', 'io_login_authenticate', 1, 3);
    add_filter('shake_error_codes', 'io_shake_error_codes');
}
/*----------------------------------连续登录验证 END----------------------------------*/


function custom_login_style(){
    $login_color = io_get_option('login_color',array('color-l'=>'','color-r'=>''));
    $color       = '#f1404b';
    if(io_get_option('theme_color_s',false)){
        $color = io_get_option('theme_color','#f1404b');
    }

    echo '<style type="text/css">
    body{background:'.$login_color['color-l'].';background:-o-linear-gradient(45deg,'.$login_color['color-l'].','.$login_color['color-r'].');background:linear-gradient(45deg,'.$login_color['color-l'].','.$login_color['color-r'].');height:100vh}
    .login h1 a{background-image:url('.io_get_option('logo',get_template_directory_uri() .'/images/logo.png').');width:180px;background-position:center center;background-size:'.io_get_option('login_logo_size',160).'px}
    .login-container{position:relative;display:flex;align-items:center;justify-content:center;height:100vh}
    .login-body{position:relative;display:flex;margin:0 1.5rem}
    .login-img{display:none}
    .img-bg{color:#fff;padding:2rem;bottom:-2rem;left:0;top:-2rem;right:0;border-radius:10px;background-image:url('.io_get_option('login_ico',get_template_directory_uri() .'/images/login.jpg').');background-repeat:no-repeat;background-position:center center;background-size:cover}
    .img-bg h2{font-size:2rem;margin-bottom:1.25rem}
    #login{position:relative;background:#fff;border-radius:10px;padding:28px;width:280px;box-shadow:0 1rem 3rem rgba(0,0,0,.175)}
    .flex-fill{flex:1 1 auto}
    .position-relative{position:relative}
    .position-absolute{position:absolute}
    .shadow-lg{box-shadow:0 1rem 3rem rgba(0,0,0,.175)!important}
    .footer-copyright{bottom:0;color:rgba(255,255,255,.6);text-align:center;margin:20px;left:0;right:0}
    .footer-copyright a{color:rgba(255,255,255,.6);text-decoration:none}
    #login form{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none;border-width:0;padding:0}
    #login form .forgetmenot{float:none}
    .login #login_error,.login .message,.login .success{border-left-color:#40b9f1;box-shadow:none;background:#d4eeff;border-radius:6px;color:#2e73b7}
    .login #login_error{border-left-color:'.$color.';background:#ffd4d6;color:#b72e37}
    #login form p.submit{padding:20px 0 0}
    #login form p.submit .button-primary{float:none;background-color:'.$color.';font-weight:bold;color:#fff;width:100%;height:40px;border-width:0;text-shadow:none!important;border-color:none;transition:.5s}
    #login form input{box-shadow:none!important;outline:none!important}
    #login form p.submit .button-primary:hover{background-color:#444}
    .login #backtoblog,.login #nav{padding:0}
    @media screen and (min-width:768px){.login-body{width:1200px}
    .login-img{display:block}
    #login{margin-left:-60px;padding:40px}
    }
</style>';
}
add_action('login_head', 'custom_login_style');

function io_login_header(){
    echo '<div class="login-container">
    <div class="login-body">
        <div class="login-img shadow-lg position-relative flex-fill">
            <div class="img-bg position-absolute">
                <div class="login-info">
                    <h2>'. get_bloginfo('name') .'</h1>
                    <p>'. get_bloginfo('description') .'</p>
                </div>
            </div>
        </div>';
}

function io_login_footer(){
    echo '</div><!--login-body END-->
    </div><!--login-container END-->
    <div class="footer-copyright position-absolute">
            <span>Copyright © <a href="'. esc_url(home_url()) .'" class="text-white-50" title="'. get_bloginfo('name') .'" rel="home">'. get_bloginfo('name') .'</a></span> 
    </div>';
}
add_action('login_header', 'io_login_header');
add_action('login_footer', 'io_login_footer');

   
//登录页面的LOGO链接为首页链接
add_filter('login_headerurl',function() {return esc_url(home_url());});
//登陆界面logo的title为博客副标题
add_filter('login_headertext',function() {return get_bloginfo( 'description' );});

//移除重置密码按钮
function Remove_lostpassword_text($translations,$text,$domain){
    if($text== 'Lost your password?' && $domain== 'default' ) return;
    return$translations;
}
//add_filter( 'gettext', 'Remove_lostpassword_text', 10, 3 );
