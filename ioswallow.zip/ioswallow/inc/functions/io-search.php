<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2024-01-26 22:08:55
 * @LastEditors: iowen
 * @LastEditTime: 2024-01-27 23:20:43
 * @FilePath: \ioswallow\inc\functions\io-search.php
 * @Description: 
 */

function io_set_history_search($s)
{
    $s      = strip_tags($s);
    if (io_strlen($s) >= 0 && io_strlen($s) < 90) {
        $old_k = !empty($_COOKIE['io_history_search']) ? json_decode(stripslashes($_COOKIE['io_history_search'])) : array();
        if (!is_array($old_k)) {
            $old_k = array();
        }

        foreach ($old_k as $k => $v) {
            if ($v == $s) {
                unset($old_k[$k]);
            }
        }

        $expire = time() + 3600 * 24 * 30;  
        array_unshift($old_k, $s);
        setcookie('io_history_search', json_encode($old_k), $expire, '/', '', false); 
    }
}

/**
 * 获取搜索历史关键词
 * @return string|bool
 */
function io_get_history_search()
{
    $keywords = !empty($_COOKIE['io_history_search']) ? json_decode(stripslashes($_COOKIE['io_history_search'])) : '';
    if (!is_array($keywords)) {
        return false;
    }

    $k_i          = 1;
    $keyword_link = '';
    
    $k_text_array = array();
    foreach ($keywords as $key) {

        if (io_strlen($key) < 1) {
            continue;
        }

        // 判断重复
        if (in_array($key, $k_text_array)) {
            continue;
        }
        $k_text_array[] = $key;

        $keyword_link .= '<a class="s-key btn btn-sm mr-2 mb-2" href="' . esc_url(home_url('/')) . '?s=' . esc_attr($key) . '">' . esc_attr($key) . '</a>';

        $k_i++;
    }
    return $keyword_link;
}

function io_nav_search_html()
{
    if (is_search() || is_404() ) {
        return;
    }

    $args = array(
        'class'      => '',
        'show_posts' => true,
        'ajax_posts' => true,
    );

    echo '<div class="main-search">';
    echo '<div class="nav-search">';
    echo '<div class="container">';
    echo io_search_body_html($args);
    echo '<div class="text-center"><a class="nav-search-close" href="javascript:;" data-toggle="nav" data-target=".nav-search"><i class="iconfont icon-error"></i></a></div>';
    echo '</div>';
    echo '</div>';
    echo '<div class="fixed-body blur-fixed" data-toggle="nav" data-target=".nav-search"></div>';
    echo '</div>';
}
add_action('wp_footer', 'io_nav_search_html');

function io_search_body_html($args = array())
{
    $defaults = array(
        'class'          => '',
        'history_title'  => io_get_option('search_history_title', '历史搜索'),
        'placeholder'    => io_get_option('search_placeholder', '你想了解些什么'),
        'hot_title'      => io_get_option('search_hot_title', '热门文章'),
        'show_history'   => true,
        'show_posts'     => false,
        'ajax_posts'     => false,
        'echo'           => false,
    );
    $args         = wp_parse_args($args, $defaults);
    $class        = $args['class'];
    
    $form_html    = '<form role="search" method="get" class="search-form my-4" action="' . esc_url( home_url( '/' ) ) . '">';
    $form_html    .= '<div class="search-box">';
    $form_html    .= '<input type="search" class="search-field" placeholder="' . $args['placeholder'] . '" value="' . get_search_query() . '" name="s" />';
    $form_html    .= '<button type="submit" class="search-submit"><i class="iconfont icon-search"></i></button>';
    $form_html    .= '</div>';
    $form_html    .= '</form>';

    $history_html = '';
    if($args['show_history']){
        $keyword_link = io_get_history_search();
        if ($keyword_link) {
            $history_html = '<div class="search-keywords-box mt-3">
                                <div class="text-muted d-flex">
                                    <span>' . $args['history_title'] . '</span>
                                    <a href="javascript:;" class="ml-auto trash-history-search"><i class="iconfont icon-delete px-1" aria-hidden="true"></i></a>
                                </div>
                                <div class="mt-2 search-keywords">' . $keyword_link . '</div>
                            </div>';
        }
    }
    $posts_html   = '';
    if($args['show_posts']){
        $hot_post = '<div class="mt-2 hot-post px-1">' . io_get_hot_posts() . '</div>';
        if($args['ajax_posts']){
            $hot_post = '<div class="mt-2 hot-post px-1" auto-load data-box="'. esc_url(admin_url( 'admin-ajax.php?action=search_hot_post' )).'"><div class="py-4 text-muted text-center null-loading border-radius-md">Lading...</div></div>';
        }
        $posts_html = '<div class="hot-post-box mt-3">
        <div class="text-muted">' . $args['hot_title'] . '</div>
        '.$hot_post.'
    </div>';
    }

    $html = '<div class="search-body ' . $class . '">' . $form_html . $history_html . $posts_html . '</div>';
    if ($args['echo']) {
        echo $html;
    } else {
        return $html;
    }
}

/**
 * 搜索频率限制
 * 
 * TODO 自定义提示页
 * @param mixed $query
 * @return mixed
 */
function io_limit_search_frequency($query){
    if (!$query->is_search) {
        return $query;
    }

    $user       = wp_get_current_user();
    $user_roles = $user->roles;
    if (in_array('administrator', $user_roles)) {
        //return;
    }

    $defaults = array(
        'limit' => 1,
        'time'  => 10,
        'msg'   => '10秒1次'
    );
    $options  = io_get_option('search_limit_ip', $defaults);
    $limit    = $options['limit']; // 搜索限制（计数）
    $l_time   = $options['time']; // 时间（秒）
    $l_msg    = $options['msg'];

    $current_time = time();
    $cookie_name  = 'search_frequency';
    $cookie_data  = isset($_COOKIE[$cookie_name]) ? json_decode(stripslashes($_COOKIE[$cookie_name]), true) : array();

    if (empty($cookie_data)) {
        $count       = 1;
        $cookie_data = array(
            'timestamp' => $current_time,
            'count'     => $count
        );
        setcookie($cookie_name, json_encode($cookie_data), $current_time + $l_time, '/');
    } else {
        $timestamp = $cookie_data['timestamp'];
        $count     = $cookie_data['count'];
        // 如果当前时间戳与上次搜索的时间戳之差大于 $l_time，则重置搜索请求次数为1，并更新时间戳
        if (($current_time - $timestamp) > $l_time) {
            $count     = 1;
            $timestamp = $current_time;
        } else {
            $count++;
        }

        $cookie_data = array(
            'timestamp' => $timestamp,
            'count'     => $count
        );
        setcookie($cookie_name, json_encode($cookie_data), $current_time + $l_time, '/');
    }

    if ($count > $limit) {
        wp_die($l_msg);
    }
}
//add_action('pre_get_posts', 'io_limit_search_frequency');
