<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2024-01-25 12:23:00
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-24 17:27:19
 * @FilePath: /ioswallow/inc/functions/io-post.php
 * @Description: 
 */

function io_get_topics_box($cat_id){
    $count = get_all_cat_postcount($cat_id);//$cat->count;
    $cat_posts_query = new WP_Query(array(
        'posts_per_page'		=> 3,
        'ignore_sticky_posts'	=> true,
        'cat'					=> $cat_id
    ));
    if($cat_posts_query->have_posts()){ 
        $p_list = array();
        while($cat_posts_query->have_posts()){ 
            $cat_posts_query->the_post();
            $p_list[] = array(
                'title' => get_the_title(),
                'img'   => io_get_thumbnail('medium', ''),
            );
        }
        while (count($p_list) < 3) {
            $p_list[] = array(
                'title' => '',
                'img'   => '<img class="lazy" ' . io_get_random_thumbnail('thumbnail') . '>',
            );
        }
    ?>
    <div class="category-box">
        <div class="category-thumbnails">
            <div class="big thumbnail">';
            <?php echo $p_list[0]['img'] ?>
            </div>
            <div class="small">
                <div class="thumbnail">
                <?php echo $p_list[1]['img'] ?>
                </div>
                <div class="thumbnail">
                <?php echo $p_list[2]['img'] ?>
                </div>                        
            </div>
        </div>
        <div class="post-count text-xs position-absolute"><i class="iconfont icon-column mr-2"></i><?php printf(__('%s 篇文章','i_theme'), $count) ?></div>
        <div class="category-content">
            <div class="left">
                <h3 class="category-title"><?php echo get_cat_name($cat_id); ?></h3>
            </div>
            <div class="right">
                <a class="arrow" href="<?php echo get_category_link($cat_id);?>"><i class="iconfont icon-arrow-right"></i></a>
            </div>
        </div>
        <a class="u-permalink" href="<?php echo get_category_link($cat_id);?>"></a>
    </div>
    <?php 
    }
    wp_reset_postdata();
}
/**
 * Summary of io_entry_meta
 * @param mixed $show_name
 * @param mixed $type
 * @param mixed $mobile full or min
 * @return void
 */
function io_entry_meta($show_name = false, $type = 'full', $mobile = 'full'){
    global $post;
    $class = '';
    if ('min' == $mobile) {
        $class = ' d-none d-md-inline';
    }
    if ($show_name) {
        echo '<span class="author' . $class . '">';
        echo get_avatar(get_the_author_meta('email'), 20);
        echo '<a class="ml-1" href="' . get_author_posts_url(get_the_author_meta('ID')) . '" title="' . __('作者：', 'i_theme') . get_the_author() . '" rel="author">' . get_the_author() . '</a></span>';
    }
    echo '<span class="' . $class . '"><i class="iconfont icon-menu"></i> ';
    $category = get_the_category();
    if ($category[0]) {
        echo '<a href="' . get_category_link($category[0]->term_id) . '">' . $category[0]->cat_name . '</a>';
    }
    echo '</span>';
    if ($type == 'full') {
        echo '<span class="date"><i class="iconfont icon-time"></i> ' . timeago(get_the_time('Y-m-d G:i:s')) . '</span>';
    }
    if (io_get_option('post_views')) {
        echo '<span class=""><i class="iconfont icon-eye"></i> ' . the_views(false) . '</span>';
    }
    if (io_get_option('comment_switcher', true)) {
        echo '<span class=""><i class="iconfont icon-messages"></i> ' . get_post($post->ID)->comment_count . '</span>';
    }
}

function io_related_meta() {
    echo '<div class="meta-zone">';
    echo get_avatar(get_the_author_meta('email'), 20); 
    echo '<span class="author">';
    echo '<a href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .' " title="'.__('作者：','i_theme') . get_the_author() .'" rel="author">' .  get_the_author() .'</a></span>';
    echo '<span class="date"><i class="iconfont icon-time"></i> '. timeago( get_the_time('Y-m-d G:i:s') ) .'</span>';
    if(io_get_option('post_views')) : 
        echo '<span><i class="iconfont icon-eye"></i> ' . the_views(false) . '</span>';
    endif;
    echo '</div>';
}

function io_get_hot_posts(){
    $args = array(
        'post_type'      => 'post',
        'posts_per_page' => io_get_option('search_hot_count', 10),     
        'meta_key'       => 'views',
        'orderby'        => 'meta_value_num',
        'order'          => 'DESC',
    );
    
    $query = new WP_Query( $args );
    $html  = '';
    $index = 1;
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $view = the_views(false);
            $html .= '<div class="my-2 d-flex align-items-center">
            <span class="index-box index-'.$index.' mr-2">'.$index.'</span>
            <a href="'.get_the_permalink().'" class="overflowClip_1 mr-2">'.get_the_title().'</a>
            <span class="ml-auto text-muted text-sm">'.$view .'</span>
            </div>';
            $index++;
        }
    }
    wp_reset_postdata(); // 重置文章查询
    return $html;
}

function io_post_archive_nav($max = 0) {
    if($max == 0){
        global $wp_query;
        $max = $wp_query->max_num_pages;
    }
         
    $paged = ( get_query_var('paged') > 1 ) ? get_query_var('paged') : 1;
    echo '<div class="post-archive-nav-data d-none" data-start="' . $paged . '" data-max="' . $max . '" data-next="' . next_posts($max, false) . '"></div>';
}
