<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2024-03-07 09:47:30
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-07 10:49:24
 * @FilePath: /ioswallow/inc/functions/io-footer.php
 * @Description: 
 */

/**
 * 页脚版权信息
 */
function io_footer_copyright_box(){
    echo '<p class="copyright">';
    $aff = io_get_option('io_aff', true) ? sprintf(__('由%s强力驱动', 'i_theme'), '<a href="https://www.iotheme.cn/?aff=' . io_get_option('io_id', '') . '" title="一为主题-精品wordpress主题" target="_blank" rel="noopener"><strong> Swallow </strong></a>') . '&nbsp' : '';
    if (io_get_option('footer_copyright')) {
        echo io_get_option('footer_copyright') . $aff;
    } else {
        $copy  = 'Copyright © ' . io_copyright_year() . ' <a href="' . esc_url(home_url()) . '" title="' . get_bloginfo('name') . '" rel="home">' . get_bloginfo('name') . '</a>&nbsp;';
        $icp   = io_get_option('footer_icp', false) ? '<a href="https://beian.miit.gov.cn/" target="_blank" rel="link noopener">' . io_get_option('footer_icp') . '</a>&nbsp;' : '';
        $p_icp = '';
        if ($police_icp = io_get_option('police_icp')) {
            if (preg_match('/\d+/', $police_icp, $arr)) {
                $p_icp = ' <a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=' . $arr[0] . '" target="_blank" rel="noopener"><img style="margin-bottom: 3px;" src="' . get_theme_file_uri('/images/gaba.png') . '"> ' . $police_icp . '</a>&nbsp;';
            }
        }
        echo $copy . $icp . $p_icp . $aff;
        unset($copy, $icp, $p_icp, $aff);
    }
    if (io_get_option('show_inquire')) {
        echo '<br />' . sprintf(__('%s 次查询, 消耗 %s s', 'i_theme'), get_num_queries(), timer_stop(0, 6));
    }
    echo '</p>';
}

/**
 * 页脚说说小工具
 */
function io_shuo_tool_html(){
    $args      = array(
        'post_type'      => 'shuoshuo',
        'orderby'        => 'date',
        'posts_per_page' => 1,
    );
    $the_query = new WP_Query($args);
    if ($the_query->have_posts()):
        while ($the_query->have_posts()):
            $the_query->the_post();
            ?>
        <div id="whisper" class="<?php echo new_shuo(get_the_time("Y-m-d H:i:s")) ?> unavailable">
            <div class="shuo_time">
                <?php the_time('Y/n/j G:i'); ?>
            </div>
            <div class="shuo_more" data-balloon="更多" data-balloon-pos="up">
                <div class="circle"></div>
                <a href="<?php echo get_permalink(io_get_option('shuoshuo_pages')) ?>" target="_blank"><i class="iconfont icon-chatroom"></i></a>
            </div>
            <div id="chatTemplate" style="">
                <div class="chatList clearfix server">
                    <?php the_title(); ?> <a class="whisper_details" href="<?php the_permalink(); ?>"><i class="iconfont icon-arrow-right" aria-hidden="true"></i> <?php _e('详情', 'i_theme') ?></a>
                </div>
            </div>
        </div>
        <?php endwhile; endif;
    wp_reset_postdata();
}

/**
 * 页脚工具栏
 */
function io_footer_tools_html(){
    $is_shuo = io_get_option('shuoshuo', false) && io_get_option('shuoshuo_tool', false);
    $html = '<div id="top-tools" class="footer-tools scrolling-hide">';
    $html .= '<a href="javascript:" class="buttontop-top blur-btn"><i class="iconfont icon-to-up"></i></a>';
    if (!is_home() || !is_front_page()) {
        $html .= '<a href="' . home_url() . '" class="tools-btn blur-btn"><i class="iconfont icon-home"></i></a>';
    }
    $html .= io_get_menu_ico('tools', 'blur-btn');
    if (io_get_option('tools_rand_switcher')) {
        $html .= '<a href="' . get_permalink(io_get_option('tools_rand_pages')) . '" class="tools-rand blur-btn" data-balloon="' . __('随便看看', 'i_theme') . '" data-balloon-pos="left"><i class="iconfont icon-flickr"></i></a>';
    }
    if (io_get_option('theme_switcher')) {
        $html .= '<a href="javascript:" class="switch-dark-mode theme-mode blur-btn" data-balloon="' . __('夜间模式', 'i_theme') . '" data-balloon-pos="left"><i class="mode-ico iconfont icon-moon"></i></a>';
    }
    if ($is_shuo) {
        $html .= '<a href="javascript:" class="shuoshuo_box blur-btn" data-balloon="' . __('微语', 'i_theme') . '" data-balloon-pos="left"><i class="iconfont icon-chatroom"></i></a>';
    }
    $html .= '</div>';

    echo $html;
    if ($is_shuo) {
        io_shuo_tool_html();
    }
}

/**
 * 点击效果
 */
function io_click_fx_div(){
    if(io_get_option('click_fx', false) && !wp_is_mobile()) {
        echo '<div id="clickCanvas" style="position:fixed;left:0;top:0;z-index:999999999;pointer-events:none;"></div>';
    }
}
add_action('wp_footer', 'io_click_fx_div');
