<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2022-02-09 21:11:15
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-07 09:47:55
 * @FilePath: /ioswallow/inc/functions/functions.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$functions = array(
    'io-login',
    'io-post',
    'io-card',
    'io-search',
    'io-page',
    'io-comment',
    'io-footer'
);

foreach ($functions as $function) {
    $path = 'inc/functions/' . $function . '.php';
    require get_theme_file_path($path);
}

function get_share_data(){
    global $post, $post_summary;
    $url        = get_permalink();
    $title      = get_the_title();
    $blog_name  = get_bloginfo('name');
    $pic        = io_theme_get_thumb();
    
    $data = array(
        'weibo' => array(
            'id'    => 'weibo',
            'title' => __('分享到微博','i_theme'),
            'class' => 'weibo',
            'href'  => esc_url('https://service.weibo.com/share/share.php?url=' . $url . '&amp;type=button&amp;language=zh_cn&amp;title=' . $title . ' | ' . $blog_name . '&amp;pic=' . $pic . '&amp;searchPic=true'),
            'ico'   => 'iconfont icon-weibo',
            'data'  => ''
        ),
        'qq'    => array(
            'id'    => 'qq',
            'title' => __('分享到QQ','i_theme'),
            'class' => 'qq',
            'href'  => esc_url('https://connect.qq.com/widget/shareqq/index.html?url=' . $url . '&amp;title=' . $title . ' | ' . $blog_name . '&amp;pics=' . $pic . '&amp;summary=' . $post_summary),
            'ico'   => 'iconfont icon-qq',
            'data'  => ''
        ),
        'qzone' => array(
            'id'    => 'qzone',
            'title' => __('分享到QQ空间','i_theme'),
            'class' => '',
            'href'  => esc_url('http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=' . $url . '&summary=' . $post_summary . '&title=' . $title . ' | ' . $blog_name . '&site=' . $blog_name . '&pics=' . $pic),
            'ico'   => 'iconfont icon-qzone',
            'data'  => ''
        ),
        'weixin' => array(
            'id'    => 'weixin',
            'title' => __('分享到微信','i_theme'),
            'class' => 'single-popup weixin',
            'href'  => 'javascript:',
            'ico'   => 'iconfont icon-wechat',
            'data'  => 'data-img="'. get_template_directory_uri() .'/inc/qr/qrcode.php?data=' . $url . '" data-title="'.__('微信扫一扫 分享朋友圈','i_theme').'" data-desc="'.__('在微信中请长按二维码','i_theme').'"'
        ),
        'douban' => array(
            'id'    => 'douban',
            'title' => __('分享到豆瓣','i_theme'),
            'class' => 'douban',
            'href'  => esc_url('https://www.douban.com/share/service?href=' . $url . '&name=' . $title . ' | ' . $blog_name . '&text=' . $post_summary . '&image=' . $pic),
            'ico'   => 'iconfont icon-douban',
            'data'  => ''
        ),
        'facebook' => array(
            'id'    => 'facebook',
            'title' => __('分享到Facebook','i_theme'),
            'class' => '',
            'href'  => esc_url('https://www.facebook.com/sharer/sharer.php?u=' . $url),
            'ico'   => 'iconfont icon-facebook',
            'data'  => ''
        ),
        'twitter' => array(
            'id'    => 'twitter',
            'title' => __('分享到Twitter','i_theme'),
            'class' => '',
            'href'  => esc_url('https://twitter.com/intent/tweet?url=' . $url . '&text=' . $title . ' | ' . $blog_name),
            'ico'   => 'iconfont icon-twitter',
            'data'  => ''
        ),
        'google' => array(
            'id'    => 'google',
            'title' => __('分享到Google','i_theme'),
            'class' => '',
            'href'  => esc_url('https://plus.google.com/share?url=' . $url),
            'ico'   => 'iconfont icon-google',
            'data'  => ''
        ),
        'email' => array(
            'id'    => 'email',
            'title' => __('分享到Email','i_theme'),
            'class' => '',
            'href'  => esc_url('mailto:?subject=' . $title . ' | ' . $blog_name . '&body=' . $url),
            'ico'   => 'iconfont icon-email',
            'data'  => ''
        ),
        'cover' => array(
            'id'    => 'cover',
            'title' => __('分享海报','i_theme'),
            'class' => 'image btn-bigger-cover',
            'href'  => 'javascript:;',
            'ico'   => 'iconfont icon-photo',
            'data'  => 'data-nonce="'.wp_create_nonce('mi-create-bigger-image-'.$post->ID ).'" data-id="'. $post->ID .'" data-action="create-bigger-image"'
        ),
        'clip' => array(
            'id'    => 'clip',
            'title' => __('复制链接','i_theme'),
            'class' => 'copy_url',
            'href'  => 'javascript:;',
            'ico'   => 'iconfont icon-link',
            'data'  => 'data-clipboard-text="' . $url . '"'
        ),
    );
    return apply_filters('io_share_data_list_filters', $data);
}

/**
 * 获取链接根域名
 * @param string $url 
 * @return string 
 */
function get_url_root($url){
	if (!$url) {
		return $url;
	}
	if (!preg_match("/^http/is", $url)) {
		$url = "http://" . $url;
	}
	$url = parse_url($url)["host"];
	$url_arr   = explode(".", $url);
	if (count($url_arr) <= 2) {
		$host = $url;
	} else {
		$last   = array_pop($url_arr);
		$last_1 = array_pop($url_arr);
		$last_2 = array_pop($url_arr);
		$host   = $last_1 . '.' . $last;
		if (in_array($host, DUALHOST))
			$host = $last_2 . '.' . $last_1 . '.' . $last;
	}
	return $host;
}

/**
 * 中文文字计数
 * @param mixed $str
 * @param mixed $charset
 * @return int
 */
function io_strlen($str, $charset = 'utf-8'){
    //中文算一个，英文算半个
    return (int) ((strlen($str) + mb_strlen($str, $charset)) / 4);
}

/**
 * Summary of io_fetch_data
 * @param mixed $url
 * @param mixed $options
 * @param mixed $timeout
 * @return array|bool|string
 */
function io_fetch_data($url, $options = [], $timeout = 10) {
    // 如果是 GET 请求且有参数，将参数附加到 URL
    if (isset($options['method']) && strtoupper($options['method']) === 'GET' && isset($options['data'])) {
        $url .= '?' . http_build_query($options['data']);
    }

    $ch = curl_init($url);

    // 设置 cURL 选项
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 忽略 SSL 验证，慎用
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // 忽略 SSL 主机验证，慎用
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout); // 设置超时时间，单位：秒

    // 处理 POST 请求
    if (isset($options['method']) && strtoupper($options['method']) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $options['data']);
    }

    // 执行 cURL 请求并获取响应
    $response = curl_exec($ch);

    // 检查是否有错误发生
    if (curl_errno($ch)) {
        // 处理错误
        return ['error' => 'cURL错误: ' . curl_error($ch)];
    } else {
        // 关闭 CURL 会话
        curl_close($ch);

        // 返回数据
        return $response;
    }
}

/**
 * 修改事件下次执行时间
 * @param mixed $event_name
 * @param mixed $new_time
 * @param mixed $recurrence
 * @return bool
 */
function io_reschedule_cron_event($event_name, $new_time, $recurrence) {
    $timestamp = wp_next_scheduled($event_name);

    // 如果事件已计划，取消计划现有事件
    if ($timestamp) {
        wp_unschedule_event($timestamp, $event_name);

        // 重新调度新的事件
        wp_schedule_event($new_time, $recurrence, $event_name);
        
        return true;
    } else {
        return false;
    }
}
/**
 * Summary of io_custom_color
 * @return void
 */
function io_custom_color(){
    $css = '';
    if (io_get_option('theme_color_s', false)) {
        $color    = io_get_option('theme_color', '#f1404b');
        $color2   = io_get_option('theme_color2', '#ff49cd');
        $color_s  = io_get_option('theme_color_shadow', 'rgba(249, 100, 90, .6)');
        $color_bg = io_get_option('theme_bg_color', 'rgba(249, 100, 90, .1)');
        $css .= ":root{--theme-color:$color;--theme-color2:$color2;--theme-bg-color:$color_bg;--shadow-color:$color_s;}";
    }
    $css .= '.container.custom-width{max-width: ' . io_get_option('sites_width', '950') . 'px}';
    echo "<style>$css</style>";
}

/**
 * 截取简介
 * @param mixed $post
 * @param mixed $length
 * @param mixed $trim_marker
 * @return string
 */
function io_strimwidth($post = null, $length = 200, $trim_marker = '……'){
    if (!$post) {
        global $post;
    }
    if(wp_is_mobile()){
        $length = max(floor($length / 2), 75);
    }
    
    if (!empty($post->post_excerpt)) {
        $excerpt = $post->post_excerpt;
    } else {
        $excerpt = apply_filters('the_content', strip_shortcodes($post->post_content));
    }

    return mb_strimwidth(strip_tags($excerpt), 0, $length, $trim_marker);
}

/**
 * 获取简介 
 * @param int $count
 * @param string $meta_key
 * @param string $trimmarker
 * @return string
 */
function io_get_excerpt($count = 90, $meta_key = '_description', $trimmarker = '...'){
    global $post;
    $excerpt = '';
    if (!($excerpt = get_post_meta($post->ID, $meta_key, true))) { 
        if (!empty($post->post_excerpt)) {
            $excerpt = $post->post_excerpt;
        } else {
            $excerpt = $post->post_content;
        }
    }
    $excerpt = trim(str_replace(array("\r\n", "\r", "\n", "　", " "), " ", str_replace("\"", "'", strip_tags(strip_shortcodes($excerpt)))));
    $excerpt = mb_strimwidth(strip_tags($excerpt), 0, $count, $trimmarker);
    return $excerpt;
}

function is_http($url){
    $preg = "/^http(s)?:\\/\\/.+/";
    if(preg_match($preg,$url)){
        return true;
    }else{
        return false;
    }
}
/**
 * 获取社交图标
 * @param mixed $location 
 * @param mixed $class
 * @return string
 */
function io_get_menu_ico($location, $class='social-icons'){
    $socials = io_get_option('social_lists', '');
    $html    = '';
    if (is_array($socials) && count($socials) > 0) {
        foreach ($socials as $social) {
            $tip  = 'title="' . $social['name'] . '"';
            if('tools'===$location){
                $tip =' data-balloon="' . $social['name'] . '" data-balloon-pos="left"';
            }
            if (in_array($location, $social['loc'])) {
                if ($social['type'] == 'img') {
                    $html .= '<a class="' . $class . ' wechat" href="javascript:;">';
                    $html .= '<i class="' . $social['ico'] . '"></i><div class="wechatimg ' . $location . '"><img src="' . $social['url'] . '"></div>';
                    $html .= '</a>';
                } else {
                    $url = $social['url'];
                    if (preg_match('|wpa.qq.com(.*)uin=([0-9]+)\&|', $url, $matches)) {
                        $url = IOTOOLS::qq_url($matches[2]);
                    }
                    $html .= '<a class="' . $class . '" href="' . $url . '" target="_blank" ' . $tip . ' rel="external noopener nofollow">';
                    $html .= '<i class="' . $social['ico'] . '"></i>';
                    $html .= '</a>';
                }
            }
        }
    }
    if (in_array($location, ['menu', 'tools'])) {
        $tip = 'title="' . __('搜索', 'i_theme') . '"';
        if('tools'===$location){
            $tip =' data-balloon="' . __('搜索', 'i_theme') . '" data-balloon-pos="left"';
        }
        $html .= '<a class="main-search-btn ' . $class . '" href="javascript:;" data-toggle="nav" data-target=".nav-search" ' . $tip . '>';
        $html .= '<i class="iconfont icon-search"></i>';
        $html .= '</a>';
    }
    return $html;
}


function io_body_class(){
    $type = io_get_option('head_region');
    $class = 'nav-type-'.$type;  // normal centered 中 tradition 传统
    return apply_filters('io_add_body_class', trim($class));
}


/**
 * 自定义菜单内容
 * @param mixed $output
 * @param mixed $item
 * @param mixed $depth
 * @param mixed $args
 * @return mixed
 */
function io_mobile_menu_item_title($output, $item, $depth, $args){
    // 检查菜单项是否有子菜单
    $has_children = !empty($item->classes) && in_array('menu-item-has-children', $item->classes);

    // 如果菜单项有子菜单，添加下拉箭头
    if ($has_children && $args->container_class === 'mobile-nav-arrow') {
        $output .= '<span class="mobile-dropdown-arrow"><i class="iconfont icon-arrow-down"></i></span>';
    }

    return $output;
}
add_filter('walker_nav_menu_start_el', 'io_mobile_menu_item_title', 10, 4);
