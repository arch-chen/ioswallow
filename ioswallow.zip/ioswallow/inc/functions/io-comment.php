<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2024-03-04 11:45:35
 * @LastEditors: iowen
 * @LastEditTime: 2024-04-18 22:18:02
 * @FilePath: /ioswallow/inc/functions/io-comment.php
 * @Description: 
 */

function io_get_update_img_box($is_add, $is_up){
    $accept_exts     = 'image/gif,image/jpeg,image/jpg,image/png';
    $modal_id        = 'io-img-modal';
    $url_id          = 'io-img-url';
    $url_btn_id      = 'io-img-url-btn';
    $upload_input_id = 'io-img-up-input';
    $size_max        = io_get_option('upload_img_size', 1024);

    $add_html = '';
    $update_html = '';
    $input_html = '';
    $dl_text = '';
    if ($is_add) {
        $add_html .= '<div class="box-body">
            <div class="mb-2 text-sm text-muted">'.__('请填写图片地址：','i_theme').'</div>
            <textarea id="' . $url_id . '" rows="2" tabindex="1" class=" comment-text w-100 input-textarea" style="height:60px;" placeholder="http://..."></textarea>
        </div>
        <a id="' . $url_btn_id . '" class="btn vc-theme btn-shadow btn-hover-dark btn-block mt-3" href="javascript:;">'.__('确认插入','i_theme').'</a>';
    }
    if ($is_up) {
        $update_html .= '<div class="box-body">
            <div class="mb-2 text-sm text-muted">'. sprintf(__('上传图片支持jpg、png、gif格式，最大 %s kb','i_theme'), $size_max).'</div>
            <label class="upload-box w-100 border-radius-md bg-light">
                <input id="' . $upload_input_id . '" style="display: none;" class="" type="file" accept="' . $accept_exts . '">
                <div style="padding: 40px 10px;background: inherit;border-radius: inherit;" class="text-center"><i aria-hidden="true" class="iconfont icon-upload mr-2"></i>'.__('上传图片','i_theme').'</div>
            </label>
        </div>';
    }
    if($is_add && $is_up){
        $dl_text = '<div class="dl-text">OR</div>';
    }
    $input_html = $add_html.$dl_text.$update_html;

    $modal_html = '<div class="modal fade" id="' . $modal_id . '" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-mini modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content dlb no-border border-radius">
                    <div class="modal-header no-border"><p class="text-lg text-center">'.__('插入图片','i_theme').'</p>
                        <button type="button" id="close-sites-modal" class="close io-close" data-dismiss="modal" aria-label="Close"><i aria-hidden="true" class="iconfont icon-close text-xl"></i></button>
                    </div>
                    <div class="dl"></div>
                    <div class="modal-body">' . $input_html . '</div>
                </div>
            </div>
        </div>';

    echo $modal_html;

}

function io_get_code_box(){
    $modal_id        = 'io-code-modal';
    $url_id          = 'io-code-text';
    $url_btn_id      = 'io-add-code-btn';

    $input_html = '<div class="box-body">
            <div class="mb-2 text-sm text-muted">'.__('请填写代码：','i_theme').'</div>
            <textarea id="' . $url_id . '" rows="2" tabindex="1" class=" comment-text w-100 input-textarea" style="height:160px;"></textarea>
        </div>
        <a id="' . $url_btn_id . '" class="btn vc-theme btn-shadow btn-hover-dark btn-block mt-3" href="javascript:;">'.__('确认插入','i_theme').'</a>';

    $modal_html = '<div class="modal fade" id="' . $modal_id . '" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-mini modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content dlb no-border border-radius">
                    <div class="modal-header no-border"><p class="text-lg text-center">'.__('插入代码','i_theme').'</p>
                        <button type="button" id="close-sites-modal" class="close io-close" data-dismiss="modal" aria-label="Close"><i aria-hidden="true" class="iconfont icon-close text-xl"></i></button>
                    </div>
                    <div class="dl"></div>
                    <div class="modal-body">' . $input_html . '</div>
                </div>
            </div>
        </div>';

    echo $modal_html;

}
function io_add_comment_btn(){
    $is_add  = io_get_option('comm-img', false);
    $is_up   = io_get_option('comm-up-img', false);
    $is_code = io_get_option('comm-code', false);

    if ($is_add || $is_up) {
        io_get_update_img_box($is_add, $is_up);
    }

    if ($is_code) {
        io_get_code_box();
    }
}
add_action('wp_footer', 'io_add_comment_btn');



function io_comment_widget_code($comment_text, $comment){
    //转换 “<”, “>”, 
    //$comment_text = htmlspecialchars($comment_text);

    $load_img = get_template_directory_uri() . '/images/t.png';
    if (io_get_option('lazyload')) {
        $img_replacement = 'data-src="$1" src="' . $load_img . '"';
    } else {
        $img_replacement = 'src="$1"';
    }
    $comment_text = preg_replace('/\[img\]((http|https):\/\/\S*)\[\/img\]/', '<a href="$1" rel="external nofollow" data-fancybox="comment-img" data-caption=""><img class="box-img loaded" ' . $img_replacement . ' alt="' . __('评论图片', 'i_theme') . '" style="width:auto; height:auto" /></a>', $comment_text);
    
    $comment_text = preg_replace('/\[code]([\s\S]*)\[\/code]/', '<pre>$1</pre>', $comment_text);

    //评论添加 @回复
    if (@$comment->comment_parent > 0) {
        $comment_text = '<span class="at">@<a href="#comment-' . $comment->comment_parent . '">' . get_comment_author($comment->comment_parent) . '</a></span> ' . $comment_text;
    }
    return wp_kses_post($comment_text);
}
add_filter('comment_text', 'io_comment_widget_code', 20, 2);

/**
 * 禁止评论自动超链接
 */
remove_filter('comment_text', 'make_clickable', 9);

/**
 * 评论实时头像
 */
function ajax_avatar_url() {
    if( isset($_GET['action']) == 'ajax_avatar_get' && 'GET' == $_SERVER['REQUEST_METHOD'] && isset($_GET['email'])) {
        $email =  $_GET['email'];
        $args = array(
            'size' => 96,
        );
        echo get_avatar_url($email, $args);
        die();
    }else { return; }
}
add_action( 'init', 'ajax_avatar_url' );


/**
 * 过滤纯英文、日文和一些其他内容
 */
function refused_spam_comments($comment_data) {
    $pattern = '/[一-龥]/u';
    $jpattern = '/[ぁ-ん]+|[ァ-ヴ]+/u';
    $links = '/http:\/\/|https:\/\/|www\./u';
    if (preg_match($links, $comment_data['comment_author'])) {
        err(__('别啊，昵称和评论里面添加链接会怀孕的哟！！' , 'i_theme'));
    }
    if (preg_match($links, $comment_data['comment_content']) && !io_get_option('comm-img', false) && !io_get_option('comm-up-img', false) && !io_get_option('comm-code', false)) {
        err(__('别啊，昵称和评论里面添加链接会怀孕的哟！！', 'i_theme'));
    }
    if (!preg_match($pattern, $comment_data['comment_content'])) {
        err(__('评论必须含中文！' , 'i_theme' ));
    }
    if (preg_match($jpattern, $comment_data['comment_content'])) {
        err(__('评论必须含中文！' , 'i_theme' ));
    }
    if (wp_check_comment_disallowed_list($comment_data['comment_author'], $comment_data['comment_author_email'], $comment_data['comment_author_url'], $comment_data['comment_content'], isset($comment_data['comment_author_IP']), isset($comment_data['comment_agent']))) {
        header("Content-type: text/html; charset=utf-8");
        err(sprintf(__('不好意思，您的评论违反了%s博客评论规则' , 'i_theme'), get_option('blogname')));
    }
    return ($comment_data);
}
if (!is_user_logged_in()) add_filter('preprocess_comment', 'refused_spam_comments');
    


/**
 * 评论加nofollow
 */
function nofollow_comments_popup_link(){
    return ' rel="external nofollow"';
}


/**
 * 评论 Cookie
 */
function coffin_set_cookies( $comment, $user, $cookies_consent){
    $cookies_consent = true;
    wp_set_comment_cookies($comment, $user, $cookies_consent);
}
add_action('set_comment_cookies','coffin_set_cookies',10,3);

// 评论显示自定义表情
function ioo_smilies_src( $old, $img ) {
    return get_theme_file_uri( '/images/smilies/'.$img);
}
add_filter( 'smilies_src' , 'ioo_smilies_src' , 10 , 2 );
function ioo_smilies($wpsmiliestrans){
    $wpsmiliestrans = array(
        ':mrgreen:'    => 'icon_mrgreen.gif',
        ':neutral:'    => 'icon_neutral.gif',
        ':twisted:'    => 'icon_twisted.gif',
        ':arrow:'      => 'icon_arrow.gif',
        ':shock:'      => 'icon_eek.gif',
        ':smile:'      => 'icon_smile.gif',
        ':???:'        => 'icon_confused.gif',
        ':cool:'       => 'icon_cool.gif',
        ':evil:'       => 'icon_evil.gif',
        ':grin:'       => 'icon_biggrin.gif',
        ':idea:'       => 'icon_idea.gif',
        ':oops:'       => 'icon_redface.gif',
        ':razz:'       => 'icon_razz.gif',
        ':roll:'       => 'icon_rolleyes.gif',
        ':wink:'       => 'icon_wink.gif',
        ':cry:'        => 'icon_cry.gif',
        ':eek:'        => 'icon_surprised.gif',
        ':lol:'        => 'icon_lol.gif',
        ':mad:'        => 'icon_mad.gif',
        ':sad:'        => 'icon_sad.gif',
        ':!:'          => 'icon_exclaim.gif',
        ':?:'          => 'icon_question.gif',
        ':aini:'       => 'icon_aini.gif',
        ':aixin:'      => 'icon_aixin.gif',
        ':baoquan:'    => 'icon_baoquan.gif',
        ':daku:'       => 'icon_daku.gif',
        ':deyi:'       => 'icon_deyi.gif',
        ':fendou:'     => 'icon_fendou.gif',
        ':gouyin:'     => 'icon_gouyin.gif',
        ':kulou:'      => 'icon_kulou.gif',
        ':liuhan:'     => 'icon_liuhan.gif',
        ':penxue:'     => 'icon_penxue.gif',
        ':qiang:'      => 'icon_qiang.gif',
        ':qiaoda:'     => 'icon_qiaoda.gif',
        ':qinqin:'     => 'icon_qinqin.gif',
        ':saorao:'     => 'icon_saorao.gif',
        ':haixiu:'     => 'icon_haixiu.gif',
        ':hanxiao:'    => 'icon_hanxiao.gif',
        ':haqian:'     => 'icon_haqian.gif',
        ':kelian:'     => 'icon_kelian.gif',
        ':kuaikule:'   => 'icon_kuaikule.gif',
        ':shengli:'    => 'icon_shengli.gif',
        ':shuai:'      => 'icon_shuai.gif',
        ':woshou:'     => 'icon_woshou.gif',
        ':wozuimei:'   => 'icon_wozuimei.gif',
        ':wunai:'      => 'icon_wunai.gif',
        ':xiaojiujie:' => 'icon_xiaojiujie.gif',
        ':xiaoku:'     => 'icon_xiaoku.gif',
        ':xu:'         => 'icon_xu.gif',
        ':yinxian:'    => 'icon_yinxian.gif',
        ':zhemo:'      => 'icon_zhemo.gif',
        ':zhuakuang:'  => 'icon_zhuakuang.gif',
    );
    return $wpsmiliestrans;
}
add_action('smilies','ioo_smilies',5);

//输出WordPress表情  
function fa_get_wpsmiliestrans(){
    global $wpsmiliestrans;
    if(empty( $wpsmiliestrans ) || !is_array( $wpsmiliestrans )){
        $wpsmiliestrans = ioo_smilies('');
    }

    $src = 'src';
    if (!is_admin() && io_get_option('lazyload')) {
        $src = 'data-src';
    }
    $output = '';
    foreach($wpsmiliestrans as $alt => $src_path){
        $output .= '<a class="add-smily" data-smilies="' . $alt . '"><img class="lazy no-bg m-1" ' . $src . '="' . get_theme_file_uri('/images/smilies/' . $src_path) . '" /></a>';
    }
    return $output;
}

function fa_smilies_custom_button() {
    $context = '<style>.smilies-wrap{background:#fff;border: 1px solid #ccc;box-shadow: 2px 2px 3px rgba(0, 0, 0, 0.24);padding: 10px;position: absolute;top: 60px;width: 380px;display:none}.smilies-wrap .add-smily img{height:24px!important;width:24px!important;cursor:pointer;margin-bottom:5px} .is-active.smilies-wrap{display:block}</style>
    <a id="insert-media-button" style="position:relative" class="button insert-smilies add_smilies" title="'.__('添加表情','i_theme').'" data-editor="content" href="javascript:;">
    <span class="wp-media-buttons-icon dashicons dashicons-art"></span>'.__('添加表情','i_theme').'
    </a>
    <div class="smilies-wrap">'. fa_get_wpsmiliestrans() .'</div>
    <script>jQuery(document).ready(function(){jQuery(document).on("click", ".insert-smilies",function() { if(jQuery(".smilies-wrap").hasClass("is-active")){jQuery(".smilies-wrap").removeClass("is-active");}else{jQuery(".smilies-wrap").addClass("is-active");}});jQuery(document).on("click", ".add-smily",function() { send_to_editor(" " + jQuery(this).data("smilies") + " ");jQuery(".smilies-wrap").removeClass("is-active");return false;});});</script>';
    echo $context;
}
add_action('media_buttons', 'fa_smilies_custom_button');
