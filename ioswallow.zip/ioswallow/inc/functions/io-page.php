<?php 
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:26
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-24 16:54:29
 * @FilePath: /ioswallow/inc/functions/io-page.php
 * @Description: 页面的页眉
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
/**
 * 页面头部
 * 包含 main
 * @param mixed $title
 * @param mixed $second
 * @return void
 */
function io_page_head_html($title = '', $second = ''){
    $isShow  = get_post_meta(get_the_ID(), '_head_show', true);
    $headImg = get_post_meta(get_the_ID(), '_head_img', true);
    $isFull  = get_post_meta(get_the_ID(), '_head_full', true);
    if ($second != '')
        $second = '<div class="text-sm">' . $second . '</div>';
    if ($title == '')
        $title = get_the_title();
    if ($isShow) {
        if ($isFull) {
            echo '<div id="thumbnail_canvas" class="page-head-img mb-5 wow fadeIn" data-wow-duration="1s"  data-wow-delay="0.5s" style="background-image: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(' . $headImg . ');">
            <canvas id="header_canvas"style="position:absolute;bottom:0"></canvas>
            <div class="container custom-width">
                <div class="page-head-img-title row align-items-center">
                    <div class="site-title-center mx-auto ws-sr col text-center">
                        <h1><span class="archive-m-line">' . $title . '</span></h1>
                        ' . $second . '
                    </div>
                </div>
            </div>
        </div>
        <main class="site-content container custom-width pb-lg-5">';
        } else {
            echo '<main class="site-content container custom-width pb-lg-5"> 
                    <div id="thumbnail_canvas" class="page-head-img small mb-5 wow fadeIn" data-wow-duration="1s"  data-wow-delay="0.3s" style="background-image: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url(' . $headImg . ');">
                        <canvas id="header_canvas"style="position:absolute;bottom:0"></canvas>
                        <div class="container">
                            <div class="page-head-img-title row align-items-center">
                                <div class="site-title-center ws-sr col text-center">
                                    <h1><span class="archive-m-line">' . $title . '</span></h1>
                                    ' . $second . '
                                </div>
                            </div>
                        </div>
                    </div>';
        }
    } else {
        echo '<main class="site-content container custom-width pb-lg-5">';
        if ($second == '') {
            echo '<h1 class="text-xxl slice-title mb-4 wow fadeIn" data-wow-duration="0.6s" data-wow-delay="0.3s">' . $title . '</h1>';
        } else {
            echo '<div class="site-title wow fadeIn" data-wow-duration="0.6s" data-wow-delay="0.3s">
                        <h1 class="text-xxl slice-title"><span  class="archive-m-line">' . $title . '</span></h1> 
                        ' . $second . '
                    </div>';
        }
    }
}