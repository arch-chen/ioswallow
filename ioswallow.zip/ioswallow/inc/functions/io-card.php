<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2024-01-26 16:35:18
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-24 16:30:51
 * @FilePath: /ioswallow/inc/functions/io-card.php
 * @Description: 
 */

/**
 * 首页列表标题
 * @return void
 */
function io_post_list_title(){
    ?>
	<div class="posts_name wow fadeIn" data-wow-duration="0.6s" data-wow-delay="0.3s">
		<?php if(io_get_option('index_cat_s')) : ?>  
		<div class="list-ajax-nav author-list-ajax-nav list-ajax-index pb-2 mb-2 mb-md-3">
			<ul class="home-tab-menu">
				<li><button id="cat-1" class="btn btn-link active" data-cat="-1"><?php echo io_get_option('index_new_title', '最新文章') ?></button></li>
			<?php $cat = io_get_option('index_cat');
			foreach($cat as $value)
			{
				echo '<li><button id="cat'.$value.'" class="btn btn-link " data-cat="'.$value.'">'.get_cat_name($value).'</button></li> ';
			}
			?>      
			</ul>
		</div>
		<?php else: ?>
		<h2 class="slice-title text-xxl mb-3 mb-md-4"><?php echo io_get_option('index_new_title', '最新文章') ?></h2>
		<?php endif; ?>
	</div>
    <?php
}
/**
 * 横向卡片
 * @return void
 */
function io_post_card_horizontal(){
    global $post;
    $sign = new_post(get_the_time('Y-m-d H:i:s'));
    if($sign == '') $sign = get_post_meta(get_the_ID(),'_cms_top',true) ? '<span class="slice-sign">'._x('推荐','card','i_theme').'</span>' : '';
    ?>
    <article id="post-<?php echo get_the_ID() ?>" class="post-card-horizontal d-flex mb-4 mb-md-5 load-posts wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.1s">
		<div class="post-card-thumbnail mr-2 mr-md-3 shadow-on-hover">
			<a href="<?php the_permalink(); ?>">
				<?php  echo io_get_thumbnail('large', 'blog-post-thumbnail') ?>
			</a>
		</div>
		<div class="post-card-body d-flex flex-column">
			<h3 class="text-xl mb-1 mb-md-3"><?php echo $sign ?><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
			<div class="explain text-sm text-muted mb-1">
			<?php echo io_strimwidth($post, 200) ?>
			</div>
			<div class="meta text-sm mt-auto">
				<?php io_entry_meta(true,'full','min') ?>
			</div>
		</div>
	</article>
    <?php
}
/**
 * 纵向卡片
 * @b
 * @return void
 */
function io_post_card_vertical($exp = 80){
    global $post;
    $sign = new_post(get_the_time('Y-m-d H:i:s'));
    if($sign == '') $sign = get_post_meta(get_the_ID(),'_cms_top',true) ? '<span class="slice-sign">'._x('推荐','card','i_theme').'</span>' : '';
    ?>
    <article id="post-<?php echo get_the_ID() ?>" class="card post-card-vertical mb-2 mb-md-3 wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.1s">
		
        <div class="post-card-thumbnail shadow-on-hover">
					<a href="<?php the_permalink(); ?>">
						<?php  echo io_get_thumbnail('large','card-img-top') ?>
					</a>
		</div>
        <div class="card-body d-flex flex-column">
            <h3 class="text-xl mb-3"><?php echo $sign ?><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
            <div class="explain text-sm text-muted mb-2">
            <?php echo io_strimwidth($post, $exp) ?>
            </div>
            <div class="meta text-sm mt-auto">
                <?php io_entry_meta() ?>
            </div>
        </div>
    </article>
    <?php
}

/**
 * 默认文章卡片
 * @return void
 */
function io_post_archive(){
    global $post;
    $sign = new_post(get_the_time('Y-m-d H:i:s'));
    if($sign == '') $sign = get_post_meta(get_the_ID(),'_cms_top',true) ? '<span class="slice-sign">'._x('推荐','card','i_theme').'</span>' : '';
    ?>
    <article id="post-<?php echo get_the_ID() ?>" class="blog-post row load-posts wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.3s">
        <div class="blog-post-thumbnail-zone col-12 col-md-4">
            <a href="<?php the_permalink(); ?>">
                <?php  echo io_get_thumbnail('medium','blog-post-thumbnail') ?>
            </a>
        </div>
        <div class="blog-post-text-zone col-12 col-md-8">
            <h2 class="text-xl mb-2"><?php echo $sign ?><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <div class="meta">
                <?php io_entry_meta(true) ?>
            </div>
            <div class=" text-muted">
            <?php echo io_strimwidth($post, 180) ?>
            </div>
        </div>
    </article>
    <?php
}

function io_get_archive_list(){
    switch (io_get_option('archive_list_type','h')) {
        case 'h':
            io_post_card_horizontal();
            break;
        case 'card':
            io_post_archive();
            break;

        default:
            io_post_card_horizontal();
            break;
    }
}
function io_post_card($class="mb-4 mb-md-5"){
    global $post;
    $sign = new_post(get_the_time('Y-m-d H:i:s'));
    if($sign == '') $sign = get_post_meta(get_the_ID(),'_cms_top',true) ? '<span class="slice-sign">'._x('推荐','card','i_theme').'</span>' : '';
    ?>		
    <article id="post-<?php echo get_the_ID() ?>" class="card post-card <?php echo $class ?> wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.1s">
        <div class="card-box shadow-on-hover post-list-history" data-id="post-<?php echo get_the_ID() ?>">
            <a class="post-card-img" href="<?php the_permalink(); ?>">
                <?php  echo io_get_thumbnail('large', 'card-img') ?>
            </a>
            <div class="card-img-overlay">
                <h3 class="text-xl mb-2"><?php echo $sign ?>
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h3>
                <div class="meta text-sm">
                    <?php io_entry_meta() ?>
                </div>
            </div>
        </div>
    </article>
    <?php
}

function io_post_list_html($type){
    $card_deck = $type == 5 ? '' : 'card-deck';

    echo '<div class="slice-list type'.$type.'">';
    io_post_list_title();
    echo '<div class="'.$card_deck.' home_post_list">';

    if (have_posts()):
        while (have_posts()):
            the_post();
            io_get_post_list($type);
        endwhile;
    endif;
    echo '</div>';

    $none = 'd-none';
    if ($GLOBALS["wp_query"]->max_num_pages > 1) {
        $none = '';
    }
    echo '<div class="load-more-posts-container wow flipInX ' . $none . '" data-wow-duration="1s" data-wow-delay="0.2s">';
    echo '<a href="javascript:;" class="ajax_load_home btn-load-more-posts button-fx" data-action="home_post_list" data-type="'.$type.'" data-page="2" ontouchstart="">' . __('加载更多', 'i_theme') . '</a>';
    echo '</div>';
    echo '</div>';
}

function io_get_post_list($type){
    switch ($type) {
        case '1':
            io_post_card_vertical();
            break;
        case '2':
            io_post_card_vertical(120);
            break;
        case '3':
        case '4':
            io_post_card('mb-4');
            break;
        case '5':
            io_post_card_horizontal();
            break;
        case '6':
            io_post_card();
            break;
        default:
            io_post_card();
            break;
    }
}
