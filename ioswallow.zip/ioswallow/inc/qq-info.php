<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:26
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-05 10:14:52
 * @FilePath: /ioswallow/inc/qq-info.php
 * @Description: 
 */
header('content-type:application/json;charset=utf8');

include "../../../../wp-load.php"; 
if($_SERVER['REQUEST_METHOD']!='POST' || !isset($_POST['type']) || !isset($_POST['qq'])){
	$rec = array(
		'message' => __('请求方式错误','i_theme'),
		'status'  => 1,
	);
	exit(json_encode($rec));

}
$qq = $_POST['qq'];
if (empty($qq)) {
    $rec = array(
        'status'  => 1,
        'message' => __('请输入QQ','i_theme'),
    );
    exit(json_encode($rec));
}elseif(preg_match("/^[1-9]\d{4,10}$/",$qq) !== 1){
    $rec = array(
        'status'  => 1,
        'message' => __('QQ格式不正确','i_theme'),
    );
    exit(json_encode($rec));
}

//输入你获取cookie的QQ
$uin = '2227098556';
//输入你获取到的skey
$skey = '@kQdNuOhAE';
//输入你获取到的pskey
$pskey = 'iK-SUruMXSaY933SfE4cGsKXU9G*GC-QxeDSwz-rxkw_';
//结合cookie
$cookie = 'uin=o'.$uin.';skey='.$skey.';p_skey='.$pskey.';';

//$nameurl = "https://users.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?uins=".$qq;
//$nameurl = 'https://r.qzone.qq.com/fcg-bin/cgi_get_portrait.fcg?g_tk='.getbkn($skey).'&uins='.$qq;


$nameurl = 'https://fxinz.cn/api/qq-query.php?qq='.$qq;//https://api.oioweb.cn/api/qq/info?qq=

$ch = curl_init(); 
$timeout = 5; 
curl_setopt($ch, CURLOPT_URL, $nameurl); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout); 
#关闭SSL
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('COOKIE:'.$cookie));
$contents = curl_exec($ch); 
curl_close($ch); 

//转换编码
//$info = mb_convert_encoding($contents, "UTF-8", "GBK");
//$array = explode('"', $info);
//$nickname = $array[5];

$array = json_decode($contents, true);
if($array['code'] == '200'){
    $nickname = $array['data']['name'];
}else{
    $nickname = '';
}

$server     = rand(1, 4);
$logourl    = 'https://q' . $server . '.qlogo.cn/headimg_dl?dst_uin=' . $qq . '&spec=100';

$rec        = array(
	"status"     => 0,
	"name"       => $nickname,
	"avatar"     => $logourl,
	"email"      => $qq . '@qq.com'
);
exit(json_encode($rec));


//计算gtk/bkn
function getbkn($skey) {
    $len = strlen($skey);
    $hash = 5381;
    for ($i = 0; $i < $len; $i++) {
        $hash += ($hash << 5 & 2147483647) + ord($skey[$i]) & 2147483647;
        $hash &= 2147483647;
    }
    return $hash & 2147483647;
}
