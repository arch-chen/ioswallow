<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * 文章缩略图或图片处理操作相关
 */

/**
 * 添加特色缩略图支持
 * 如果需要，取消下面注释
 */
//if ( function_exists('add_theme_support') )add_theme_support('post-thumbnails');

/**
 * 获取特色图地址
 */
function io_theme_get_thumb($post = null){
	if( $post === null ){
    	global $post;
    }
    if(get_post_meta($post->ID,'_random_cover',true)){
        $random_img = explode(PHP_EOL , io_get_option('random_head_img'));
        $random_img_array = array_rand($random_img);
        $post_thumbnail_src = trim($random_img[$random_img_array]);
    }else{
	    if(get_post_meta($post->ID,'_single_cover',true)) {	//输出自定义图片地址
	    	$post_thumbnail_src = get_post_meta($post->ID,'_single_cover',true);
	    } elseif( has_post_thumbnail() ){    //如果有特色缩略图，则输出缩略图地址
	    	$thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
	    	$post_thumbnail_src = $thumbnail_src [0];
	    } else {
	    	$post_thumbnail_src = '';
	    	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $strResult);
	    	if(!empty($strResult[1][0])){
	    		$post_thumbnail_src = $strResult[1][0];   //获取该图片 src
	    	}else{	
                //如果日志中没有图片，则显示随机图片
                $random_img = explode(PHP_EOL , io_get_option('random_head_img'));
                $random_img_array = array_rand($random_img);
                $post_thumbnail_src = trim($random_img[$random_img_array]);
	    	}
        }
    }
    return  $post_thumbnail_src;
}
function io_get_thumbnail_src($size = 'thumbnail'){
    return io_get_thumbnail($size,'',true);
}
/**
 * 获取/输出缩略图地址 
 * @param string $size  thumbnail medium large full
 * @param string $class
 * @param bool $isUrl
 * @return string
 */
function io_get_thumbnail($size = 'thumbnail', $class="", $isUrl = false){
    
	global $post; 

    $post_thumbnail_src = '';
	//查询缓存
	$img_url = wp_cache_get($post->ID, 'post_thumbnail_url_' . $size, true);
	if ($img_url === false) {
        $post_thumbnail_src = io_theme_get_thumb(); 
		if ($post_thumbnail_src) {
			//设置缓存
			wp_cache_set($post->ID, $post_thumbnail_src, 'post_thumbnail_url_' . $size);
		} else {
			wp_cache_set($post->ID, 'no', 'post_thumbnail_url_' . $size);
		}
	} else {
		$post_thumbnail_src = $img_url == 'no' ? false : $img_url;
	}

	if ($isUrl) {
		return getOptimizedImageUrl($post_thumbnail_src, $size);
	}

	$alt = $post->post_title . io_get_delimiter() . get_bloginfo('name'); 

	if (io_get_option('lazyload')) {
        $loadimg_url=get_template_directory_uri().'/images/t.png';
        return sprintf('<img src="%s" data-src="%s" class="%s" alt="%s" >',$loadimg_url, getOptimizedImageUrl($post_thumbnail_src, $size), $class.' lazy', $alt);
	} else { 
        return sprintf('<img src="%s" class="%s" alt="%s" >', getOptimizedImageUrl($post_thumbnail_src, $size), $class, $alt);
	}



}

/**
 * 输出随机缩略图地址
 */
function io_get_random_thumbnail($size = 'thumbnail'){
    $random_img = explode(PHP_EOL , io_get_option('random_head_img'));
    $random_img_array = array_rand($random_img);
    $post_thumbnail_src = trim($random_img[$random_img_array]);
    if(io_get_option('lazyload')){
        $loadimg_url=get_template_directory_uri().'/images/t.png';
        return 'src="'.$loadimg_url.'" data-src="'.getOptimizedImageUrl($post_thumbnail_src, $size).'"';
    } else {
        return 'src="'.getOptimizedImageUrl($post_thumbnail_src, $size).'"';
    }
}
 
/**
 * WordPress 获取“上下篇”文章缩略图的图片地址
 */
function io_theme_near_image($post){
    $first_img = io_theme_get_thumb($post);
    if(io_get_option('lazyload')){
        $loadimg_url=get_template_directory_uri().'/images/t.png';
        echo '<img class="home-thumb" src="'.$loadimg_url.'" data-src="'.getOptimizedImageUrl($first_img, array('width'=>400,'height'=>120)).'" alt="'.get_the_title().'" />';
    } else {
        echo '<img class="home-thumb" src="'.getOptimizedImageUrl($first_img, array('width'=>400,'height'=>120)).'" alt="'.get_the_title().'" />';
    }
}

/**
 * 获取Timthumb裁剪的图片链接
 */
function getTimthumbImage($url, $size = 'thumbnail', $q='70', $nohttp = false){
    return $url;
    /*     
    if($nohttp)
        $timthumb =  get_template_directory_uri()  . '/timthumb.php';
    else
        $timthumb = str_replace(array('https:','http:'),array('',''), get_template_directory_uri()) . '/timthumb.php';
    // 不裁剪Gif，因为生成黑色无效图片
    $imgtype = strtolower(substr($url, strrpos($url, '.')));
    if($imgtype === 'gif') return $url;

    $size = getFormatedSize($size);
    return $timthumb . stripslashes('?src=' . $url . '&q=' . $q . '&w=' . $size['width'] . '&h=' . $size['height'] . '&zc=1'); 
    */
}
  
/**
 * 获取用于腾讯云&七牛CDN平台处理的图片链接
 */
function getQiniuCDNImage($url, $size = 'thumbnail'){
    $size = getFormatedSize($size);
    $url = Rewrite_URI($url);
    if(!in_sites( $url,get_img_url() )){
        return getTimthumbImage($url, $size);
    }
    return $url . '?imageView2/1/w/' . $size['width'] .'/h/' . $size['height'] . '/q/100';
    
}

/**
 * 获取又拍云处理的裁剪图片链接
 */
function getUpyunCdnImage($url, $size = 'thumbnail'){
    $size = getFormatedSize($size);
    $url = Rewrite_URI($url);
    if(!in_sites( $url,get_img_url() )){
        return getTimthumbImage($url, $size);
    }
    return $url .'!'.'/both/'.$size['width'] . 'x' . $size['height']; 
}

/**
 * 获取阿里云处理的裁剪图片链接
 */
function getOssCDNImage($url, $size = 'thumbnail'){
    $size = getFormatedSize($size);
    $url = Rewrite_URI($url);
    if(!in_sites( $url,get_img_url() )){
        return getTimthumbImage($url, $size);
    }
    return $url . '?x-oss-process=image/resize,m_fill,w_' . $size['width'] . ',h_' . $size['height'] . ',limit_0';
}
/**
 * 根据用户设置选择合适的图片链接处理方式(timthumb|cdn)
 */
function getOptimizedImageUrl($url, $size, $q='70', $nohttp = false){
    if($size == 'full')
        return $url ;
    //if (!preg_match('/'. str_replace('/', '\/', get_host(home_url())) .'/i',$url)) {//如果是外链
        //error_log("非法地址".$url.PHP_EOL, 3, "./php_3.log");
    //    return getTimthumbImage($url, $size, $q, $nohttp);
    //}
    //else{
        switch (io_get_option('thumbnail_modus', 'null')) {
            case 'null':
                return $url ;
                break;
            case 'normal':
                return getTimthumbImage($url, $size, $q, $nohttp);
                break;
            case 'qiniu':
                return getQiniuCDNImage($url, $size);
                break;
            case 'upyun':
                return getUpyunCdnImage($url, $size);
                break;
            case 'cos':
                return getQiniuCDNImage($url, $size);
                break;
            case 'oss':
                return getOssCDNImage($url, $size);
                break;
            default:
                return $url ;
                break;
        } 
    //}
}
function get_img_url(){
    if(io_get_option('is_cdn_url')){
        return io_get_option('img_cdn_url');
    }elseif(io_get_option('io_cdn_on')){
        return get_host(io_get_option('cdn_url'));
    }else{
        return '';
    }
}
function in_sites($url,$sites){
    if (preg_match('/'. str_replace('/', '\/', $sites) .'/i',$url)) {//如果是外链
        return true;
    }
    return false;
}


/**
 * 转换CDN链接地址
 */
function Rewrite_URI($url){
    if(io_get_option('is_cdn_url')){
        return $url;
    }
    $pattern ='/'. str_replace('/', '\/', home_url()) .'\/wp-([^"\']*?)\.(jpg|gif|png|jpeg)/i';
    $replacement = io_get_option('cdn_url').'/wp-$1.$2';
	$url = preg_replace($pattern, $replacement,$url);
	return $url;
}

/**
 * 转换尺寸
 * @param string $size thumbnail medium large
 */
function getFormatedSize($size){
    if(is_array($size)){
        $width = array_key_exists('width', $size) ? $size['width'] : 225;
        $height = array_key_exists('height', $size) ? $size['height'] : 150;
        $str = array_key_exists('str', $size) ? $size['str'] : 'thumbnail';
    }else{
        switch ($size){
            case 'large':
                $width = 1024;
                $height = 460;
                $str = 'large';
                break;
            case 'medium':
                $width = 500;
                $height = 350;
                $str = 'medium';
                break;
            default:
                $width = 225;
                $height = 150;
                $str = 'thumbnail';
        }
    }
    return array(
        'width'   =>  $width,
        'height'  =>  $height,
        'str'     =>  $str
    );
}

/**
 * 获取顶级域名
 * @return [type] 
 * 比如www.iowen.cn返回iowen.cn
 */
function get_host($to_virify_url = ''){
    
    $url   = $to_virify_url ? $to_virify_url : $_SERVER['HTTP_HOST'];
    $data = explode('.', $url);
    $co_ta = count($data);
 
    //判断是否是双后缀
    $zi_tow = true;
    $host_cn = 'com.cn,net.cn,org.cn,gov.cn';
    $host_cn = explode(',', $host_cn);
    foreach($host_cn as $host){
        if(strpos($url,$host)){
            $zi_tow = false;
        }
    }
 
    //如果是返回FALSE ，如果不是返回true
    if($zi_tow == true){
 
        // 是否为当前域名
        if($url == 'localhost'){
            $host = $data[$co_ta-1];
        }
        else{
            $host = $data[$co_ta-2].'.'.$data[$co_ta-1];
        }
        
    }
    else{
        $host = $data[$co_ta-3].'.'.$data[$co_ta-2].'.'.$data[$co_ta-1];
    }
    
    return $host;
}