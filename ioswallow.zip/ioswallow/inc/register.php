<?php
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:27
 * @LastEditors: iowen
 * @LastEditTime: 2024-03-04 14:48:20
 * @FilePath: /ioswallow/inc/register.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'THEME_URL', get_bloginfo('template_directory') );
function theme_load_scripts() {
	if( is_admin() )
		return;
		
	if (io_get_option('disable_gutenberg')) {
		wp_dequeue_style('wp-block-library');
		wp_dequeue_style('wp-block-library-theme');
		wp_dequeue_style('wc-block-style'); // 移除WOO插件区块样式
		wp_dequeue_style('global-styles'); // 移除 THEME.JSON
	}
	$_min = WP_DEBUG === true?'':'.min';
	wp_deregister_script( 'jquery' );
	
    wp_register_style( 'bootstrap',			get_theme_file_uri('/css/bootstrap.min.css'), array(), VERSION, 'all'  );
	wp_register_style( 'iconfont', 			get_theme_file_uri('/css/iconfont.css'), array(), VERSION, 'all'  );
	wp_register_style( 'balloon', 			get_theme_file_uri('/css/balloon.min.css'), array(), VERSION );
	wp_register_style( 'animate', 			get_theme_file_uri('/css/animate.min.css'), array(), VERSION );
	wp_register_style( 'down', 				get_theme_file_uri('/css/down.css'), array(), VERSION );
	wp_register_style( 'fancybox', 			get_theme_file_uri('/css/fancybox.css'), array(), VERSION );
	wp_register_style( 'swiper', 			get_theme_file_uri('/css/swiper-bundle.min.css'), array(), VERSION );
	wp_register_style( 'style', 			get_theme_file_uri('/css/style.css'), array(),   VERSION , 'all'  );
	
	wp_register_script( 'jquery',  			get_theme_file_uri('/js/jquery.min.js'), array(), VERSION );
	wp_register_script( 'bootstrap', 		get_theme_file_uri('/js/bootstrap.min.js'), array('jquery'), VERSION, true );
	wp_register_script( 'plugins', 			get_theme_file_uri('/js/plugins.js'), array('jquery'), VERSION, true );
	wp_register_script( 'wow', 				get_theme_file_uri('/js/wow.min.js'), array('jquery'), VERSION, true );
	wp_register_script( 'comments-ajax', 	get_theme_file_uri('/js/comments-ajax.js'), array('jquery'), VERSION, true );
	wp_register_script( 'fancybox', 		get_theme_file_uri('/js/fancybox.umd.js'), array(), VERSION, true );
	wp_register_script( 'swiper', 			get_theme_file_uri('/js/swiper-bundle.min.js'), array(), VERSION, true );
	wp_register_script( 'lazyload', 		get_theme_file_uri('/js/lazyload.min.js'), array('jquery'), VERSION, true );
	wp_register_script( 'app', 				get_theme_file_uri('/js/app'.$_min.'.js'), array('jquery'), VERSION, true );

	wp_enqueue_style('bootstrap');
	wp_enqueue_style('iconfont');
	wp_enqueue_style('balloon');

	wp_enqueue_script('jquery');

	wp_enqueue_script('bootstrap');
	wp_enqueue_script( 'plugins' );
	
	if (io_get_option('wow_no')) {
		wp_enqueue_style('animate'); 
		wp_enqueue_script( 'wow');
	}
	if(is_home() || is_front_page()){
		wp_enqueue_style('swiper');
		wp_enqueue_script('swiper');
	}
	if(is_single()){
		if(io_get_option('img_box',true)){
			wp_enqueue_style('fancybox');
			wp_enqueue_script('fancybox'); 
		}
		wp_enqueue_style('swiper');
		wp_enqueue_script('swiper');
	}
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
		wp_enqueue_script( 'comments-ajax');
	} 
	if(io_get_option('lazyload')) wp_enqueue_script('lazyload'); 
	wp_enqueue_style('style');
	wp_enqueue_script('app');

	wp_localize_script('app', 'Theme', array(
		'ajaxurl'      => admin_url('admin-ajax.php'),
		'comment'      => get_theme_file_uri('/inc/comments-ajax.php'),
		'qqinfourl'    => get_theme_file_uri('/inc/qq-info.php'),
		'version'      => VERSION,
		'lazyload'     => io_get_option('lazyload'),
		'url'          => get_template_directory_uri(),
		'pre_c'        => '© ' . get_bloginfo('name'),
		'is_code'      => io_get_option('code_highlight', true),
		'is_box'       => io_get_option('img_box', true),
		'up_img_max'   => io_get_option('upload_img_size', 256),
		'upload_nonce' => wp_create_nonce('file_upload_img'),
	));
    wp_localize_script('app', 'localize' , array(
        'liked'             => __('您已经赞过了!','i_theme'),
        'like'              => __('谢谢点赞!','i_theme'),
        'networkerror'      => __('网络错误 --.','i_theme'),
        'copied'    		=> __('成功复制链接到剪贴板！','i_theme'),
        'uncopied'			=> __('你的浏览器不能正常复制\n请您手动进行！','i_theme'),
        'lightMode'         => __('日间模式','i_theme'),
        'nightMode'         => __('夜间模式','i_theme'),
        'loading'           => __('加载中...','i_theme'),
        'more'              => __('加载更多','i_theme'),
        'none'              => __('我也是有底线的！','i_theme'),
        'none2'      		=> __('暂无更多内容','i_theme'),
        'clickMore'         => __('点击加载更多','i_theme'),
    ));
	if($custom_page = get_query_var('io_custom_page')){ 
		switch ($custom_page) {
			case 'down':
				wp_enqueue_style('down');
				break;
		}
	}
}
add_action('wp_enqueue_scripts', 'theme_load_scripts');

function add_swiper_script(){
	wp_register_style( 'swiper', 			get_theme_file_uri('/css/swiper-bundle.min.css'), array(), VERSION );
	wp_register_script( 'swiper', 			get_theme_file_uri('/js/swiper-bundle.min.js'), array(), VERSION, true );
	wp_enqueue_style('swiper');
	wp_enqueue_script('swiper');
}

function io_add_custom_admin_css() {
	//编辑器图标
	echo '<link rel="stylesheet" type="text/css" href="//at.alicdn.com/t/font_2978079_19i7qguv0fhh.css">';
	echo '<style type="text/css">
    .mce-ico {font-size:20px!important}
    </style>';
	
    if (io_get_option('favicon','')) {
        echo "<link rel='shortcut icon' href='" . io_get_option('favicon','') . "'>";
    } else {
        echo "<link rel='shortcut icon' href='" . home_url('/favicon.ico') . "'>";
    }
    if (io_get_option('apple_icon','')) {
        echo "<link rel='apple-touch-icon' href='" . io_get_option('apple_icon','') . "'>";
    }
}
add_action('admin_head', 'io_add_custom_admin_css');


function io_csf_enqueue(){ 
    $urls = io_get_option('iconfont_url','');
    $urls = explode(PHP_EOL , $urls);
    $index = 1;
    if(!empty($urls)&&is_array($urls)){
        foreach($urls as $url){
            wp_enqueue_style( 'iconfont-io-'.$index,  $url, array(), VERSION );
            $index++;
        }
    }else{
        wp_enqueue_style( 'iconfont-io',  $urls, array(), VERSION );
    } 
    wp_enqueue_style( 'iconfont', get_theme_file_uri('/css/iconfont.css') , array(), VERSION );
}
add_action('csf_enqueue', 'io_csf_enqueue');
add_action('wp_enqueue_scripts', 'io_csf_enqueue');