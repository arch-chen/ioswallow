<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<?php
/**
 * 提示框
 */
function shortCodeTips($atts, $content = null)
{
    extract(shortcode_atts(array("type" => 'info', "display" => ''), $atts));
    if ($content) {
        return '<div class="tip ' . $type . ' ' . $display . '">' . do_shortcode(wpautop($content)) . '</div>';
    }
}
add_shortcode("tip", "shortCodeTips");

if ((current_user_can('edit_posts') && current_user_can('edit_pages'))) {
    add_action('media_buttons','io_select',11);
    add_action('admin_head','io_button');
}
// 添加按钮
function io_select(){
    echo '<select id="sc_select">
        <option value="您需要选择一个短代码">插入短代码</option>
        <option value="[need_reply]隐藏的内容[/need_reply]">回复可见</option>
        <option value="[login_reply]隐藏的内容[/login_reply]">登录可见</option>
        <option value="[password_reply key=密码]加密的内容[/password_reply]">密码保护</option>
        <option value="<fieldset><legend>我是标题</legend>这里是内容</fieldset>"><p>fieldset标签</p></option>
        <option value="[ad]">插入广告</option>
        <option value="[embed_post ids=文章ID_1,文章ID_2]">插入卡片文章内链</option>
    </select>';
}
function io_button() {
    echo '<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery("#sc_select").change(function() {
        send_to_editor(jQuery("#sc_select :selected").val());
        return false;
        });
    });
    </script>';
}

// 可视化按钮
add_action('admin_init','tinymce_button');
function tinymce_button() {
    if ( current_user_can( 'edit_posts' ) && current_user_can( 'edit_pages' ) ) {
        add_filter( 'mce_css', 'io_plugin_mce_css' );
        add_filter( 'mce_external_plugins', 'io_add_tinymce_button' );
        add_filter( 'mce_buttons', 'io_register_tinymce_button' );
        add_filter( 'mce_buttons_2', 'io_register_tinymce_button2' );
    }
}

function io_register_tinymce_buttons( $buttons ) {
    array_push( $buttons, "ioch_code", "reply", "login", "password", "field", "ad" ,"promptbox",'buttons',"tabs","embedpost","aplayerbox","videobox");
    return $buttons;
}
function io_register_tinymce_button( $buttons ) {
    $buttons = ['formatselect', 'bold', 'italic', 'bullist', 'numlist', 'blockquote', 'alignleft', 'aligncenter', 'alignright', 'link', 'spellchecker','wp_page'];
    array_push( $buttons, "ioch_code", "reply", "login", "password", "field", "ad" ,"promptbox",'buttons',"tabs","embedpost","aplayerbox","videobox");
    $buttons[] = 'wp_adv';
    $buttons[] = 'dfw';
    return $buttons;
}
function io_register_tinymce_button2($buttons) { 
    $io_btn = array('styleselect','fontselect','fontsizeselect'); 
    return array_merge($io_btn, $buttons);
}
function io_plugin_mce_css( $mce_css ) {
    if ( ! empty( $mce_css ) )
        $mce_css .= ',';
    $mce_css .= get_theme_file_uri('css/editor-style.css?v=' . VERSION);
    return $mce_css;
}
function io_add_tinymce_button( $plugin_array ) {
    $plugin_array['io_button_script'] = get_theme_file_uri('/js/buttons.js?v='.VERSION);
	$plugin_array['ioch_code_button'] = get_theme_file_uri('/js/editor-code.js?v='.VERSION);
    return $plugin_array;
}

// 登录可见
add_shortcode("login_reply", "login_to_read");
function login_to_read($atts, $content = null) {
    extract(shortcode_atts(array("notice" =>'
    <div class="content-hide-tips">
        <i class="iconfont icon-user"></i>
        <div class="text-center">
            <div class="read-sm">' . sprintf(__( '此处为隐藏的内容！', 'i_theme' )) . '</div>
            <p class="gray mb-2">' . sprintf(__( '登录后才能查看！', 'i_theme' )) . '</p>
            <a href="/wp-login.php" class="btn" id="login-see" ><i class="iconfont icon-user1"></i>' . sprintf(__( '登录', 'i_theme' )) . '</a>
        </div>
    </div>'), $atts));
    if (is_user_logged_in()) {
        return '<div class="content-hide-tips"><i class="iconfont icon-unlock"></i><span class="gray content-hide-text">'.__('以下为隐藏内容：', 'i_theme' ).'</span>'.do_shortcode( $content ).'</div>';
    } else {
        return $notice;
    }
}
// 加密内容
add_shortcode("password_reply", "secret_reply");
function secret_reply($atts, $content=null){
    extract(shortcode_atts(array('key'=>null), $atts));
    if ( current_user_can('level_10') ) {
        return '<div class="content-hide-tips"><i class="iconfont icon-unlock"></i><span class="gray content-hide-text">'.__('以下为加密的内容：', 'i_theme' ).'</span>'.do_shortcode( $content ).'</div>';
    }
    if(isset($_POST['secret_key']) && $_POST['secret_key']==$key){
        return '<div class="content-hide-tips"><i class="iconfont icon-unlock"></i><span class="gray content-hide-text">'.__('以下为加密的内容：', 'i_theme' ).'</span>'.do_shortcode( $content ).'</div>';
    } else {
        return '
        <form class="content-hide-tips" action="'.get_permalink().'" method="post">
            <i class="iconfont icon-key"></i>
            <div class="text-center">
                <div class="mb-2">' . sprintf(__( '输入密码查看加密内容', 'i_theme' )) . '</div>
                <input id="pwbox" type="password" size="20" name="secret_key">
                <p></p>
                <input class="btn" type="submit" value="' . sprintf(__( '提交', 'i_theme' )) . '" name="Submit">
            </div> 
        </form>    ';
    }
}
// 评论可见
add_shortcode("reply", "reply_read");
add_shortcode("need_reply", "reply_read");
function reply_read($atts, $content=null) {
    extract(shortcode_atts(array("notice" => '
    <div class="content-hide-tips">
        <i class="iconfont icon-lock"></i>
        <div class="text-center">
            <div class="mb-0">' . sprintf(__( '此处为隐藏的内容！', 'i_theme' )) . '</div>
            <p class="gray mb-2">' . sprintf(__( '发表评论并刷新，才能查看', 'i_theme' )) . '</p>
            <a class="btn" href="#respond">' . sprintf(__( '发表评论', 'i_theme' )) . '</a>
        </div> 
    </div>'), $atts));
    $email = null;
    $user_ID = (int) wp_get_current_user()->ID;
    if ($user_ID > 0) {
        $email = get_userdata($user_ID)->user_email;
        if ( current_user_can('level_10') ) {
            return '<div class="content-hide-tips"><i class="iconfont icon-unlock"></i><span class="gray content-hide-text">'.__('以下为隐藏内容：', 'i_theme' ).'</span>'.do_shortcode( $content ).'</div>';
        }
    } else if (isset($_COOKIE['comment_author_email_' . COOKIEHASH])) {
        $email = str_replace('%40', '@', $_COOKIE['comment_author_email_' . COOKIEHASH]);
    } else {
        return $notice;
    }
    if (empty($email)) {
        return $notice;
    }
    global $wpdb;
    $post_id = get_the_ID();
    $query = "SELECT `comment_ID` FROM {$wpdb->comments} WHERE `comment_post_ID`={$post_id} and `comment_approved`='1' and `comment_author_email`='{$email}' LIMIT 1";
    if ($wpdb->get_results($query)) {
        return do_shortcode('<div class="content-hide-tips"><i class="iconfont icon-unlock"></i><span class="gray content-hide-text">'.__('以下为隐藏内容：', 'i_theme' ).'</span>'.do_shortcode( $content ).'</div>');
    } else {
        return $notice;
    }
}
 
// 下载解压密码
add_shortcode('pass','reply_password');
function reply_password($atts, $content=null) {
    extract(shortcode_atts(array("notice" => '<div class="reply_pass">' . sprintf(__( '%s下载密码：%s发表评论并刷新可见！', 'i_theme' ),'<strong>','</strong>') . '</div>'), $atts));
    $email = null;
    $user_ID = (int) wp_get_current_user()->ID;
    if ($user_ID > 0) {
        $email = get_userdata($user_ID)->user_email;
        if ( current_user_can('level_10') ) {return ''.do_shortcode( $content ).'';}
    } else if (isset($_COOKIE['comment_author_email_' . COOKIEHASH])) {
        $email = str_replace('%40', '@', $_COOKIE['comment_author_email_' . COOKIEHASH]);
    } else {
        return $notice;
    }
    if (empty($email)) {
        return $notice;
    }
    global $wpdb;
    $post_id = get_the_ID();
    $query = "SELECT `comment_ID` FROM {$wpdb->comments} WHERE `comment_post_ID`={$post_id} and `comment_approved`='1' and `comment_author_email`='{$email}' LIMIT 1";
    if ($wpdb->get_results($query)) {
        return do_shortcode(''.do_shortcode( $content ).'');
    } else {
        return $notice;
    }
}

add_shortcode("wptab", "shortCodeTab");
function shortCodeTab($atts, $content = null)
{
    extract(shortcode_atts(array("number" => '', "title" => ''), $atts));
    if ($content) {
        return '<section id="tab' . $number . '" title="' . $title . '">' . do_shortcode(wpautop($content)) . '</section>';
    }
}
add_shortcode("start_tab", "shortCodeStartTab");
function shortCodeStartTab($atts, $content = null)
{
    return '<div class="tab-group">';
}
add_shortcode("end_tab", "shortCodeEndTab");
function shortCodeEndTab($atts, $content = null)
{
    return '</div>';
}
 
/**
* 短代码广告
*/
add_shortcode("ad", "post_ad");
function post_ad(){
    return '<div class="post-ad">'.stripslashes( io_get_option('ad_s_z') ).'</div>';
}
/**
* 卡片式文章内链功能
*/
function embed_posts( $atts, $content = null ){
    if(is_home() || is_front_page()){
        return '';
    }
    extract( shortcode_atts( array(
    'ids' => ''
    ),
    $atts ) );
    global $post;
    $content = '';
    $postids = explode(',', $ids);
    $inset_posts = get_posts(array('post__in'=>$postids,'posts_per_page' => -1));
    $intx=0;
    foreach ($inset_posts as $post) {
        setup_postdata( $post );
        $category = get_the_category();
        $content .= '
        <div class="embed-body intx_' . $intx . ' postid_' . get_the_ID() .'">
            <div class="embed-blur">
            <a target="_blank" href="' . get_permalink() . '" title="'.get_the_title().'">
                <div class="blur-img" style="background-image: url('.io_get_thumbnail('thumbnail','',true) .')"></div>
            </a>
            </div>
            <div class="embed-card">
                <a target="_blank" href="'.get_category_link($category[0]->term_id ).'" title="' . sprintf(__( '查看“%s”分类下的文章', 'i_theme' ),$category[0]->cat_name).'"><span class="embed-card-category">'. $category[0]->cat_name .'</span></a>
                <span class="embed-card-img">
                    '. io_get_thumbnail('thumbnail','unfancybox').'
                </span>
                <span class="embed-card-info">
                    <span class="card-name">'. get_the_title() . '</span>
                    <span class="card-abstract">'. io_strimwidth($post, 80) .'</span>
                    <span class="card-controls">
                        <span class="group-data"><i class="iconfont icon-time"></i>'. timeago(get_the_time('Y-m-d G:i:s')) .'</span>
                        <span class="group-data"><i class="iconfont icon-eye"></i>'. the_views(false, '', '', false) .'</span>'.
                        (io_get_option('comment_switcher',true) ? '<span class="group-data"><i class="iconfont icon-news"></i>'. get_comments_number() .'</span>' : '')
                    .'</span>
                </span>
            </div>
        </div>
        ';
        $intx++;
    }
    wp_reset_postdata(); 
    return $content;

}
add_shortcode('embed_post_old', 'embed_posts');

/**
* 卡片式文章内链功能 v2
*/
function embed_posts_v2($atts, $content = null)
{
    if(is_home() || is_front_page()){
        return '';
    }
    extract( shortcode_atts( array(
    'ids' => ''
    ),
    $atts ) );
    global $post;
    $content = '';
    $postids = explode(',', $ids);
    $inset_posts = get_posts(array('post__in'=>$postids,'posts_per_page' => -1));
    $intx=0;
    foreach ($inset_posts as $key => $post) {
        setup_postdata( $post );
        $category = get_the_category(); 
        $img = io_get_thumbnail('thumbnail','rounded unfancybox fit-cover m-0');
        $content .= '<div class="embed-box position-relative rounded intx_' . $intx . ' postid_' . get_the_ID() .'">
                        <div class="embed-background position-absolute">' . $img . '</div>
                        <div class="embed-mini-body d-flex p-2 position-relative">
                            <div class="mr-3"><div class="embed-thumbnail rounded"><a href="' . get_permalink() . '">' . $img . '</a></div></div>
                            <div class="embed-mini-content d-flex flex-column justify-content-between">
                                <div class="item-heading text-ellipsis-2 main-color">
                                    <a class="main-color" href="' . get_permalink() . '">' . get_the_title() . '</a>
                                </div>
                                <div class="embed-meta d-flex justify-content-between text-muted text-xs">
                                    <span class="group-data"><i class="iconfont icon-menu mr-1"></i><a target="_blank" href="'.get_category_link($category[0]->term_id ).'" title="' . sprintf(__( '查看“%s”分类下的文章', 'i_theme' ),$category[0]->cat_name).'">'. $category[0]->cat_name .'</a></span>
                                    <div>
                                        <span class="group-data mr-2"><i class="iconfont icon-time mr-1"></i>'. timeago(get_the_time('Y-m-d G:i:s')) .'</span>
                                        <span class="group-data mr-2"><i class="iconfont icon-eye mr-1"></i>'. the_views(false, '', '', false) .'</span>'.
                                        (io_get_option('comment_switcher',true) ? '<span class="group-data"><i class="iconfont icon-news mr-1"></i>'. get_comments_number() .'</span>' : '')
                                    .'</div>
                                </div>
                            </div>
                        </div>
                    </div>';

        $intx++;
    }
    wp_reset_postdata(); 
    return $content;
}
add_shortcode('embed_post', 'embed_posts_v2');

add_shortcode('aplayer', 'io_aplayer');
function io_aplayer($atts) {  
    if(is_home() || is_front_page()){
        return '';
    }
    extract( shortcode_atts( array(
        'id' => '',
        'server' => '',
        'type' => '',
        'auto' => '',
        'name' => '',
        'artist' => '',
        'url' => '',
        'cover' => '',
        'lyric' => '',
        'autoplay' => '',
        ),
        $atts ) );
    wp_enqueue_style('aplayercss','https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.css',array(), '1.10');
     
    if($server !=''){
        $server = ' server="'.$server.'"';
    }
    if($type !=''){
        $type = ' type="'.$type.'"';
    }
    if($id !=''){
        $id = ' id="'.$id.'"';
    }
    if($auto !=''){
        $auto = ' auto="'.$auto.'"';
    }
    if($lyric !=''){
        $lyric =  str_replace(array("《","》"),array("[","]"), $lyric)  ;
    }

    if(($server !='' || $auto !='') && $lyric ==''){
        wp_enqueue_script('aplayer','https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.js',array(),'1.10',true);
        wp_enqueue_script('meting','https://cdn.jsdelivr.net/npm/meting@2/dist/Meting.min.js',array(),'2.0',true);
        return '<meting-js'.$server.$type.$id.$auto.$name.$artist.$url.$cover.' autoplay="'.$autoplay.'"></meting-js>';
    }else{
        return '<div id="aplayer"></div>
        <script src="https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.js"></script>
        <script>
        var ap = new APlayer({
            container: document.getElementById("aplayer"),
            autoplay: '.$autoplay.',
            lrcType: 1,
            audio: {
                name: "'.$name.'",
                artist: "'.$artist.'",
                url: "'.$url.'",
                cover: "'.$cover.'",
                lrc: "'.htmlspecialchars_decode($lyric).'"
            }
        });
        </script>';
    }
}

add_shortcode('button', 'button_url');
function button_url($atts,$content=null){
    extract(shortcode_atts(array(
        "href"=>'http://',
        "full"=>'',
        "center"=>'',
    ),$atts));
    if($full=='1')
        $full='btn-lg btn-block';
    if($center=='1')
        $center='text-center';
    return '<div class="button '.$center.'"><a class="btn vc-theme btn-shadow btn-hover-dark '.$full.'" href="'.$href.'" rel="external nofollow" target="_blank">'.$content.'</a></div>';
}

add_shortcode('down', 'down_url');
function down_url($atts,$content=null){
    extract(shortcode_atts(array(
        "href"=>'http://',
        "full"=>'',
        "center"=>'',
    ),$atts));
    if($full=='1')
        $full='btn-lg btn-block';
    if($center=='1')
        $center='text-center';
    return '<div class="button '.$center.'"><a class="btn vc-theme btn-shadow btn-hover-dark '.$full.'" href="'.$href.'" rel="external nofollow" target="_blank"><i class="iconfont icon-download"></i>'.$content.'</a></div>';
}

add_shortcode('preview', 'preview_url');
function preview_url($atts,$content=null){
    extract(shortcode_atts(array(
        "href"=>'http://',
        "full"=>'',
        "center"=>'',
    ),$atts));
    if($full=='1')
        $full='btn-lg btn-block';
    if($center=='1')
        $center='text-center';
    return '<div class="button '.$center.'"><a class="btn vc-theme btn-shadow btn-hover-dark '.$full.'" href="'.home_url().'/preview/?id='.get_the_ID().'&url='.$href.'" rel="external nofollow" target="_blank"><i class="iconfont icon-eye"></i>'.$content.'</a></div>';
}


function io_post_gallery( $output, $attr, $instance){
    global $post;
    $is_box = io_get_option('img_box',true);
    $output ='<div class="swiper post-img-swiper mb-3">
        <div class="swiper-wrapper">';
    foreach ( explode(',',$attr['ids']) as $v ) { 
        $img    = wp_get_attachment_image_src( $v,'full' ); 
        $box_b  = $is_box?'<a href="'.$img[0].'" class="swiper-img" data-fancybox="fancybox" data-caption="'.$post->post_title.'">':'';
        $box_a  = $is_box?'</a>':'';
        
        $output .= '<div class="swiper-slide">';
        $output .= $box_b.'<img src="'.$img[0].'" class="attachment-full unfancybox size-full" width="'.$img[1].'" height="'.$img[2].'" alt="'.$post->post_title.'">'.$box_a;
        $output .= '</div>';
    }
        $output .='</div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
    </div>';
    return $output;
}
add_filter( 'post_gallery', 'io_post_gallery', 10, 3 );
