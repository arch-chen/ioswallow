<?php
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-08 02:07:17
 * @LastEditors: iowen
 * @LastEditTime: 2022-02-15 22:06:46
 * @FilePath: \ioswallow\inc\meta-boxs.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' )  ) { die; } 
//
$io_post_opts = '_io_post_options';

CSF::createMetabox( $io_post_opts, array(
    'title'        => '文章选项',
    'post_type'    => 'post',
    'data_type'    => 'unserialize',
    'theme'        => 'light',
    'nav'          => 'inline',
    'show_restore' => true,
) );
$poster = 'csf-depend-hidden csf-depend-on';
if(io_get_option('ioc_share')&&io_get_option('ioc_poster_cover')) $poster = '';
CSF::createSection( $io_post_opts, array(
    'title'  => '封面/置顶',
    'icon'   => 'fa fa-picture-o',
    'fields' => array( 
        array(
            'id'    => '_slide_banner',
            'type'  => 'switcher',
            'title' => '推送幻灯片',
            'label' => __('把文章推送至首页“幻灯片”，可以在下面设置的“封面”里显示图片','i_theme'),
        ),
        array(
            'id'    => '_slide_order',
            'type'  => 'text',
            'title' => '幻灯片排序',
            'after' => __('输入数值，实现幻灯排序，数值越大越靠前','i_theme'),
            'help'  => 'The help text of the field.',
            'default'=> '0',
			'dependency' => array( '_slide_banner', '==', true )
        ),
        array(
            'id'    => '_cms_top',
            'type'  => 'switcher',
            'label' => __('把文章推送至“推荐”模块','i_theme'),
            'title' => '推荐',
        ),
        array(
            'id'    => '_random_cover',
            'type'  => 'switcher',
            'title' => '随机封面',
            'label' => __('启用随机封面，在“主题设置->其他设置->其他杂项->随机头部图片”里可以设置图片源','i_theme'), 
        ),
        array(
            'id'      => '_single_cover',
            'type'    => 'upload',
            'title'   => '特色封面',
            'after'   => __('单独设置文章封面，显示在首页幻灯片、文章列表和文章页头部。注意：不设置则默认调用特色图、文章的第一张图片或者随机图片。','i_theme'),
			'preview'   => true,
        ),
        array(
            'id'      => '_top_video',
            'type'    => 'upload',
            'title'   => '特色视频',
            'after'   => '为该文章显示视频封面。注意：视频封面默认封面为“特色封面”>“特色图”>“文章的第一张图”>“随机图片”',
			'preview'   => true,
        ),
        array(
            'id'      => '_bigger_cover',
            'type'    => 'upload',
            'title'   => '分享海报',
            'after'   => '注意：该图为系统自动生成，无效手动添加，如需要更新，请点“移除”删除图片',
			'preview'   => true,
            'class'   => $poster
        ),

    )
));

CSF::createSection( $io_post_opts, array(
    'title'  => '转载选项',
    'icon'   => 'fa fa-share-square',
    'fields' => array(
        array(
            'type'    => 'notice',
            'class'   => 'warning',
            'content' => __('默认为原创内容，填写下面选项后文章下的版权信息将显示为转载信息。','io_setting'),
        ),
        array(
            'id'    => '_from',
            'type'  => 'text',
            'title' => __('文章来源','i_theme'),
            'after' => __('自定义该文章作者的名称','i_theme'),
        ),
        array(
            'id'    => '_copyright',
            'type'  => 'text',
            'title' => __('原文链接','i_theme'),
            'after' => __('请填写转载文章的原文链接','i_theme'),
        )
    )
));

CSF::createSection( $io_post_opts, array(
    'title'  => '下载信息',
    'icon'   => 'fa fa-download',
    'fields' => array(
        array(
            'id'    => "_down_start",
            "type"  => "switcher",
            'title' => __('启用下载','i_theme'),
            'label' => __('必须启用才能显示资源下载框','i_theme'),
        ),
        array(
            'id'    => "_password_start",
            "type"  => "switcher",
            'title' => __('启用密码回复可见','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_name",
            "type"  =>"text",
            'title' => __('资源名称','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_file_os",
            "type"  =>"text",
            'title' => __('应用平台','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_file_inf",
            "type"  =>"text",
            'title' => __('资源版本','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_size",
            "type"  =>"text",
            'title' => __('资源大小','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_demo",
            "type"  =>"text",
            'title' => __('演示链接','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_official_website",
            "type"  =>"text",
            'title' => __('官网地址','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => '_instructions',
            'type'  => 'textarea',
            'title' => __('使用说明','i_theme'),
            'size'  => array( 65 , 3),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_baidu_pan",
            "type"  =>"text",
            'title' => __('网盘下载链接','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_baidu_pan_btn",
            "type"  =>"text",
            'title' => __('网盘下载按钮名称','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_baidu_password",
            "type"  =>"text",
            'title' => __('网盘密码','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_local",
            "type"  =>"text",
            'title' => __('本站下载链接','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_local_btn",
            "type"  =>"text",
            'title' => __('本站下载按钮名称','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_rar_password",
            "type"  =>"text",
            'title' => __('解压密码','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_official",
            "type"  =>"text",
            'title' => __('官网下载链接','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_official_btn",
            "type"  =>"text",
            'title' => __('官网下载按钮名称','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        ),
        array(
            'id'    => "_down_img",
            "type"  =>"text",
            'title' => __('输入演示图地址','i_theme'),
            'dependency' => array( '_down_start', '==', true),
        )
    )
));

CSF::createSection( $io_post_opts, array(
    'title'  => 'SEO设置',
    'icon'   => 'fa fa-paw',
    'description' => __('<b>注：此功能不影响其他SEO插件的功能</b>','io_setting'),
    'fields' => array(
        array(
            'id'    => '_title',
            'type'  => 'text',
            'title' => __('自定义标题','i_theme'),
            'attributes' => array(
                'style' => 'width: 100%'
            ),
        ),
        array(
            'id'    => '_keywords',
            'type'  => 'text',
            'title' => __('设置关键词','i_theme'),
            'attributes' => array(
                'style' => 'width: 100%'
            ),
        ),
        array(
            'id'    => '_description',
            'type'  => 'textarea',
            'title' => __('自定义描述','i_theme'),
        ) 
    )
));




$io_page_opts = '_io_page_options';

CSF::createMetabox( $io_page_opts, array(
    'title'        => '页面选项',
    'post_type'    => 'page',
    'data_type'    => 'unserialize',
    'theme'        => 'light',
    'nav'          => 'inline',
    'show_restore' => true,
) );

CSF::createSection( $io_page_opts, array(
    'title'  => '封面/置顶',
    'icon'   => 'fa fa-picture-o',
    'fields' => array( 
        array(
            'id'    => '_head_show',
            'type'  => 'switcher',
            'title' => __('头部图片','i_theme'),
            'label' => __('页面头部显示图片','i_theme'), 
        ),
        array(
            'id'    => '_head_img',
            'type'  => 'upload',
            'title' => __('上传头图','i_theme'),
            'after' => __('设置封面，注意：不能为空。','i_theme'), 
			'preview'   => true,
			'dependency' => array( '_head_show', '==', true )
        ),
        array(
            'id'    => '_head_full',
            'type'  => 'switcher',
            'title' => __('全宽','i_theme'),
            'label' => __('头部图片显示全宽大图','i_theme'), 
			'dependency' => array( '_head_show', '==', true )
        ),
    )
));

CSF::createSection( $io_page_opts, array(
    'title'  => 'SEO设置',
    'icon'   => 'fa fa-paw',
    'description' => __('<b>注：此功能不影响其他SEO插件的功能</b>','io_setting'),
    'fields' => array(
        array(
            'id'    => '_title',
            'type'  => 'text',
            'title' => __('自定义标题','i_theme'),
            'attributes' => array(
                'style' => 'width: 100%'
            ),
        ),
        array(
            'id'    => '_keywords',
            'type'  => 'text',
            'title' => __('设置关键词','i_theme'),
            'attributes' => array(
                'style' => 'width: 100%'
            ),
        ),
        array(
            'id'    => '_description',
            'type'  => 'textarea',
            'title' => __('自定义描述','i_theme'),
        ) 
    )
));


$io_shuoshuo_opts = '_io_shuoshuo_options';
CSF::createMetabox($io_shuoshuo_opts, array(
    'title'     => 'SEO',
    'post_type' => 'shuoshuo',
    'data_type' => 'unserialize',
    'theme'     => 'light',
    'context'   => 'side',
    'priority'  => 'default',
));
CSF::createSection( $io_shuoshuo_opts, array(
    'description' => __('<b>注：此功能不影响其他SEO插件的功能</b>','io_setting'),
    'fields' => array(
        array(
            'id'    => '_title',
            'type'  => 'text',
            'title' => __('自定义标题','i_theme'),
            'attributes' => array(
                'style' => 'width: 100%'
            ),
        ),
        array(
            'id'    => '_keywords',
            'type'  => 'text',
            'title' => __('设置关键词','i_theme'),
            'attributes' => array(
                'style' => 'width: 100%'
            ),
        ),
        array(
            'id'    => '_description',
            'type'  => 'textarea',
            'title' => __('自定义描述','i_theme'),
        ) 
    )
));

if( class_exists( 'CSF' ) ) {
    $prefix = 'links_post_options';
    CSF::createMetabox( $prefix, array(
        'title'           => '友情链接选项',
        'post_type'       => 'page',
        'page_templates'  => 'template-links.php',
        'context'         => 'side',
        'data_type'       => 'unserialize'
    ) );
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'id'      => '_disable_links_content',
                'type'    => 'switcher', 
                'title'   => '默认内容',
                'text_on' => '启用',
                'text_off'=> '禁用',
                'default' => true,
            ),
            array(
                'id'      => '_links_form',
                'type'    => 'switcher', 
                'title'   => '投稿表单',
                'text_on' => '启用',
                'text_off'=> '禁用',
                'default' => true,
            ),
        )
    ));
}