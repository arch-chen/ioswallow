<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

$prefix = 'io_swallow_option';

$rewrite_rules_btn = '<a href="'.add_query_arg(array('page'=>'theme_settings','action'=>'rewrite_rules'),admin_url('admin.php')).'" class="but c-yellow ml-3" style="padding:4px 8px">刷新固定连接</a>';
CSF::createOptions( $prefix, array(
	'framework_title'	=> 'Swallow <small>V'.wp_get_theme()->get('Version').' <a class="ml-3 text-help" href="https://www.iotheme.cn/help" target="_blank"><i class="fab fa-hire-a-helper"></i> 使用手册</a>'.$rewrite_rules_btn.'</small>',
	'menu_title'	 	=> __('主题设置','csf'),
	'menu_slug'			=> 'theme_settings',
	'menu_position' 	=> 59,
	'save_defaults' 	=> true,
	'ajax_save'	   		=> true,
	'show_bar_menu'		=> false,
	'theme'		   		=> 'dark',
    'class'             => 'io-option',
	'show_search'		=> true,
	'footer_text'		=> esc_html__('运行在', 'io_setting' ).'： WordPress '. get_bloginfo('version') .' / PHP '. PHP_VERSION,
	'footer_credit'		=> '感谢您使用 <a href="https://www.iotheme.cn/" target="_blank">一为的WordPress主题</a>',
));


// 所有分类ID
$cats_id = '';
$categories = get_categories(array('hide_empty' => 0)); 
foreach ($categories as $cat) {
$cats_id .= '<span style="margin-right: 15px;">'.$cat->cat_name.' [ '.$cat->cat_ID.' ]</span>';
}
$blog_name = trim(get_bloginfo('name'));


$views_use_ajax = ( defined( 'WP_CACHE' ) && WP_CACHE )?'':'csf-depend-visible csf-depend-on';
$tip_ico = '<i class="fa fa-fw fa-info-circle"></i> ';
//
// 开始使用
//
CSF::createSection( $prefix, array(
	'title'		=> __('开始使用','io_setting'),
	'icon'		 => 'fa fa-shopping-cart',
	'fields'	   => array(
        array(
            'type'    => 'submessage',
            'style'   => 'success',
            'content' => '<h3 style="color:#568519"><i class="fa fa-heart fa-fw"></i> 感谢您使用 ioTheme 一为主题</h3><p style="font-size:18px">'.$tip_ico.'注意 & 必看</p>
            <p><b>必须配置</b> 服务器 <b>伪静态规则</b> 和 <b>wp固定链接</b> 格式，否则会造成<b>404</b>，<a href="https://www.iotheme.cn/wordpressweijingtaihewordpressgudinglianjieshezhi.html" target="_blank">伪静态设置方法</a></p>
            <p>先保存一遍<b>主题设置</b>选项，否则可能会报错（点右上<b>“保存配置”</b>按钮）</p>',
        ),
        array(
            'type'     => 'callback',
            'function' => 'active_html',
        ),
		array(
			'id'	  => 'update_theme',
			'type'	  => 'switcher',
			'title'   => __('检测主题更新','io_setting'),
			'label'   => __('在线更新为替换更新，如果你修改了主题代码，请关闭（如需修改，可以使用子主题）','io_setting'),
			'default' => true,
            'desc'    => $tip_ico.'请勿修改主题文件夹名称，可能会导致检查不到更新。<br />'.$tip_ico.'基于wp更新通道，请勿关闭wp更新检查。',
		),
		array(
			'id'	   => 'update_beta',
			'type'	   => 'switcher',
			'title'    => __('加入Beta版体验','io_setting'),
			'label'    => __('可体验最新功能','io_setting'),
            'before'   => '<a href="'.admin_url('update-core.php').'" class="but c-blue" style="margin:0">检查更新</a>',
            'desc'     => '开启后加入Beta版更新通道，Beta版及测试版，可体验最新功能，同时也可能会有各种bug。',
			'default'  => false,
			'class'    => 'compact min',
			'dependency' => array( 'update_theme', '==', true )
		),
        array(
            'type'    => 'content',
            'title'   => '系统环境',
            'content' => io_get_system_info(),
        ),
        array(
            'type'    => 'content',
            'title'   => '推荐环境',
            'content' => '<ul><li><strong>WordPress</strong>：5.6+，推荐使用最新版</li>
            <li><strong>PHP</strong>：PHP7.2及以上</li>
            <li><strong>服务器配置</strong>：1核2G，不推荐虚拟机</li>
            <li><strong>操作系统</strong>：无要求，不推荐使用Windows系统</li>
            <li><strong>环境</strong>：推荐宝塔或者自建</li></ul>',
        ),
	)
));
/**
 * 基本设置
 */
CSF::createSection( $prefix, array(
	'title' => __('基础设置','io_setting'),
	'icon'  => 'fa fa-th-large',

	'fields' => array(
		array(
			'id'       => 'head_region',
			'type'     => 'image_select',
			'title'    => __('头部样式', 'io_setting'),
			'options'  => array(
				'normal'    => get_theme_file_uri('/images/frame/nav-normal.png'),
				'centered'  => get_theme_file_uri('/images/frame/nav-centered.png'),
				'tradition' => get_theme_file_uri('/images/frame/nav-tradition.png'),
			),
			'default'  => 'normal',
			'subtitle' => __('选择头部样式', 'io_setting'),
			'attributes'=> array(
				'data-depend-id' => 'head_region',
			),
		),
		array(
			'id'		  => 'topics_list',
			'type'		=> 'select',
			'title'	   => '专题页显示内容',
			'chosen'	  => true,
			'multiple'	=> true,
			'placeholder' => '选择分类',
			'options'	 => 'categories',
			'after'	  =>__('注意：如果你删除了文章分类，请重新保存主题设置','io_setting')
		),
        array(
            'id'      => 'sites_width',
            'type'    => 'slider',
            'title'   => '自定义内容宽度',
            'min'     => 800,
            'max'     => 1100,
            'step'    => 10,
            'unit'    => 'px',
            'default' => 950,
            'class'   => 'new',
            'after'   => '默认 950px',
        ),
		array(
			'id' 		=> 'code_highlight',
			'title' 	=> __('代码高亮','io_setting'),
			'type' 		=> 'switcher',
			'label'    	=> __('启用或者关闭主题自带代码高亮功能。','io_setting'),
			'default' 	=> true,
		),
		array(
			'id' 		=> 'img_box',
			'title' 	=> __('图片灯箱','io_setting'),
			'type' 		=> 'switcher',
			'label'    	=> __('启用或者关闭主题自带图片灯箱功能。','io_setting'),
			'default' 	=> true,
		),
		array(
			'id' 		=> 'archive_list_type',
			'title' 	=> __('手机归档页列表样式','io_setting'),
			'type'		=> 'radio',
			'after'    	=> $tip_ico.__('主要区别在手机端','io_setting'),
			'inline'    => true,
			'options'   => array(
				'h'     => __( '横行卡片', 'io_setting' ),
				'card'  => __( '纵向卡片', 'io_setting' ),
			),
			'default' 	=> 'card',
			'class'     => 'new'
		),
		array(
			'id' 		=> 'post_views',
			'title' 	=> __('文章浏览统计','io_setting'),
			'type' 		=> 'switcher',
			'default' 	=> true,
			'label'    	=> __('启用前先禁用WP-PostViews插件，因为主题已经集成WP-PostViews插件','io_setting'),
		),
		array(
			'id'		=> 'views_options',
			'type'	  => 'fieldset',
			'title'	 => __('浏览计数设置','io_setting'),
			'fields'	=> array(
				array(
					'id'		  => 'count',
					'type'		=> 'select',
					'title'	   => __( '计数来源', 'io_setting' ),
					'options'	 => array(
						'0'  => __( '所有人', 'io_setting' ),
						'1'  => __( '只有访客', 'io_setting' ),
						'2'  => __( '只有注册用户', 'io_setting' ),
					),
				),
				array(
					'id'	  => 'exclude_bots',
					'type'	=> 'switcher',
					'title'   => __('排除机器人(爬虫等)','io_setting'),
				),
				array(
					'id'		  => 'template',
					'type'		=> 'select',
					'title'	   => __( '显示模板', 'io_setting' ),
					'options'	 => array(
						'0'  => __( '正常显示计数', 'io_setting' ),
						'1'  => __( '以千单位显示', 'io_setting' ),
					),
				),
				array(
					'id'	  => 'use_ajax',
					'type'	=> 'switcher',
					'title'   => __('使用Ajax更新浏览次数','io_setting'),
					'class'   => $views_use_ajax,
					'label'	  => '如果启用了静态缓存，将使用AJAX更新浏览计数，且“随机计数”失效。',
				),
			),
			'default'		=> array(
				'count'		 => '0',
				'exclude_bots'  => true,
				'template'	  => '0',
				'use_ajax'	  => true,
			),
			'class' => 'compact',
			'dependency' => array( 'post_views', '==', true )
		),
		array(
			'id'	  => 'night_theme',
			'type'	=> 'radio',
			'title'   => __('主题模式','io_setting'), 
			'options' => array(
				'light' => '亮色',
				'dark'  => '暗色',
                'auto-system'  => '根据系统自动切换',
                'time-auto'    => '自定义时间段',
			),
			'default' => 'light',
            'after'   => '主题最高<b>优先级</b>来自<b>用户选择</b>，也就是<b>浏览器缓存</b>，只有当用户未手动切换主题时<b>自动切换</b>才有效。<br>'.$tip_ico.'<b>根据系统自动切换</b>支持win10、win11、最新Mac OS和最新的移动端操作系统。',
		),
		array(
			'id'        => 'time_auto',
			'type'      => 'datetime',
			'title'     => '时间段设置',
			'from_to'   => true,
			'text_from' => '浅色',
			'text_to'   => '深色',
			'settings' => array(
				'noCalendar' => true,
				'enableTime' => false,
				'dateFormat' => 'H',
				'time_24hr'  => true,
				'allowInput' => true,
				'allFormat'  => 'H',
			),
			'default' => array(
				'from'  => "7",
				'to'    => '18'
			),
			'dependency' => array( 'night_theme', '==', 'time-auto' ),
            'after'   => $tip_ico.'填24小时时间，如浅色：7，深色：18',
			'class'   => 'compact'
		),
		array(
			'type'	=> 'subheading',
			'content' => __('搜索相关设置','io_setting'),
		),
		array(
			'id'       => 'search_placeholder',
			'type'     => 'text',
			'title'    => __('搜索框占位文案','io_setting'),
			'default'  => '你想了解些什么',
			'class'    => 'new'
		),
		array(
			'id'       => 'search_history_title',
			'type'     => 'text',
			'title'    => __('历史搜索文案','io_setting'),
			'default'  => '历史搜索',
			'class'    => 'compact min'
		),
		array(
			'id'       => 'search_hot_title',
			'type'     => 'text',
			'title'    => __('热门文章文案','io_setting'),
			'default'  => '热门文章',
			'class'    => 'compact min'
		),
		array(
			'id'       => 'search_hot_count',
			'type'     => 'number',
			'title'    => __('热门文章数量','io_setting'),
			'default'  => '10',
			'class'    => 'compact min'
		),
		array(
			'type'	=> 'subheading',
			'content' => __('右下小工具','io_setting'),
		),
		array(
			'id'	  => 'theme_switcher',
			'type'	=> 'switcher',
			'title'   => __('主题模式切换开关','io_setting'),
			'subtitle'	=> __('显示/隐藏右下角主题模式切换开关','io_setting'),
			'label'    	=> '亮色 & 暗色',
			'default' => true
		),
		array(
			'id'	  => 'tools_rand_switcher',
			'type'	=> 'switcher',
			'title'   => __('随便看看','io_setting'),
			'subtitle'	=> __('显示/隐藏右下角随便看看小工具','io_setting'),
			'default' => false
		),
		array(
			'id'			 => 'tools_rand_pages',
			'type'		   => 'select',
			'title'		  => __('选择随便看看文章页','io_setting'),
			'after'		   => __('如果没有，请新建页面，选择“试试手气”模板并保存','io_setting'),
			'options'		=> 'pages',
			'query_args'  => array(
				'posts_per_page'  => -1,
			),
			'class' => 'compact',
			'default_option' => __('选择一个页面','io_setting'),
			'dependency'	 => array( 'tools_rand_switcher', '==', true )
		),
		array(
			'id'	  => 'shuoshuo',
			'type'	=> 'switcher',
			'title'   => __('微语','io_setting'),
			'subtitle'	=> __('启用微语','io_setting'), 
		),
		array(
			'id'			 => 'shuoshuo_pages',
			'type'		   => 'select',
			'title'		  => __('选择微语文章页','io_setting'),
			'after'		   => __('如果没有，请新建页面，选择“微语”模板并保存','io_setting'),
			'options'		=> 'pages',
			'query_args'  => array(
				'posts_per_page'  => -1,
			),
			'class' => 'compact',
			'default_option' => __('选择一个页面','io_setting'),
			'dependency'	 => array( 'shuoshuo', '==', true )
		),
		array(
			'id'			=> 'shuoshuo_tool',
			'type'		   	=> 'switcher',
			'title'		  	=> __('微语小工具','io_setting'),
			'class' 		=> 'compact',
			'subtitle'		=> __('显示/隐藏右下角微语小工具按钮','io_setting'),
			'dependency'	=> array( 'shuoshuo', '==', true )
		),
        array(
            'id'      => 'save_image',
            'type'    => 'switcher',
            'title'   => __('本地化外链图片','io_setting'),
            'label'   => __('自动存储外链图片到本地服务器','io_setting'),
            'desc'    => __('<p>只支持经典编辑器</p><strong>注：</strong>使用古腾堡(区块)编辑器的请不要开启，否则无法保存文章','io_setting'),
            'default' => false,
        ),
        array(
            'id'      => 'exclude_image', 
            'type'    => 'textarea',
            'title'   => __('本地化外链图片白名单','io_setting'),
            'after'   => __('一行一个地址，注意不要有空格。<br>不需要包含http(s)://<br>如：iowen.cn','io_setting'),
            'class'   => 'compact',
            'default' => 'alicdn.com'.PHP_EOL.'baidu.com',
            'dependency' => array( 'save_image', '==', true )
        ),
	),
));

/**
 * 网站LOGO
 */
CSF::createSection( $prefix, array(
	'title' => __('LOGO/颜色','io_setting'),
	'icon'  => 'fa fa-flag',

	'fields' => array(
		array(
			'id'		=> 'logo',
			'type'	  => 'upload',
			'title'	 => __('网站 LOGO','io_setting'),
			'add_title' => __('上传 LOGO','io_setting'),
			'preview'   => true,
			'default'   => get_theme_file_uri( '/images/logo.png'),
		),
		array(
			'id'		=> 'logo_dark',
			'type'	  => 'upload',
			'title'	 => __('网站 LOGO(暗色主题)','io_setting'),
			'add_title' => __('上传 LOGO','io_setting'),
			'preview'   => true,
			'default'   => get_theme_file_uri( '/images/logo_dark.png'),
		),
		array(
			'id'		=> 'favicon',
			'type'	  => 'upload',
			'title'	 => __('网站 Favicon图标','io_setting'),
			'subtitle'  => __('上传网站 Favicon图标','io_setting'),
			'add_title' => __('上传 Favicon','io_setting'),
			'preview'   => true,
			'default'   => get_theme_file_uri( '/images/favicon.ico'),
		),
		array(
			'id'		=> 'apple_icon',
			'type'	  => 'upload',
			'title'	 => __('自定义IOS屏幕图标','io_setting'),
			'subtitle'	  => __('上传苹果移动设备添加到主屏幕图标 180x180','io_setting'),
			'after'		=> '180x180',
			'default'   => get_theme_file_uri( '/images/gravatar.jpg'),
			'preview'   => true,
		),
        array(
            'id'        => 'login_ico',
            'type'      => 'upload',
            'title'     => '登录页样式设置',
			'subtitle'  => '图片',
            'add_title' => '上传',
            'default'   => get_theme_file_uri('/images/login.jpg'),
			'preview'   => true,
        ),
        array(
            'id'        => 'login_color',
            'type'      => 'color_group',
            'title'     => ' ',
			'subtitle'  => '背景色',
            'options'   => array(
                'color-l'   => '左边',
                'color-r'   => '右边',
            ),
            'default'   => array(
                'color-l'   => '#7d00a0',
                'color-r'   => '#c11b8d',
            ),
			'class'     => 'compact min',
        ),
		array(
				'id'		 => 'login_logo_size',
				'type'       => 'spinner',
				'title'      => ' ',
				'subtitle'	 => 'logo 宽度',
				'after'      => '如果登录页Logo显示不正确，调整此值',
				'unit'       => 'px',
				'default'    => 160,
				'class'      => 'compact min',
		),
		array(
			'id'       => 'theme_color_s',
			'type'     => 'switcher',
			'title'    => __('自定义主题基础色', 'io_setting'),
			'default'  => false,
			'label'    => '设置好后测试一下亮色和暗色环境下的效果',
			'class'    => 'new'
		),
        array(
            'id'         => 'theme_color',
            'type'       => 'color',
            'title'      => '基础色',
            'default'    => '#f1404b', 
			'class'      => 'compact',
			'dependency' => array('theme_color_s', '==', true)
        ),
        array(
            'id'         => 'theme_color2',
            'type'       => 'color',
            'title'      => '基础色2',
			'after'	     => '和 基础色 组渐变色',
            'default'    => '#ff49cd', 
			'class'      => 'compact',
			'dependency' => array('theme_color_s', '==', true)
        ),
        array(
            'id'         => 'theme_bg_color',
            'type'       => 'color',
            'title'      => '基础色背景',
			'after'	     => '默认透明度 0.1',
            'default'    => 'rgba(249, 100, 90, .1)', 
			'class'      => 'compact',
			'dependency' => array('theme_color_s', '==', true)
        ),
        array(
            'id'         => 'theme_color_shadow',
            'type'       => 'color',
            'title'      => '基础色投影',
			'after'	     => '默认透明度 0.6',
            'default'    => 'rgba(249, 100, 90, .6)', 
			'class'      => 'compact',
			'dependency' => array('theme_color_s', '==', true)
        ),
	),
));

/**
 * 首页设置
 */
CSF::createSection($prefix, array(
	'title'  => __('首页设置', 'io_setting'),
	'icon'   => 'fa fa-home',

	'fields' => array(
		array(
			'id'       => 'index_banner',
			'type'     => 'switcher',
			'title'    => __('幻灯片', 'io_setting'),
			'subtitle' => __('是否显示幻灯片', 'io_setting'),
			'default'  => true
		),
		array(
			'id'         => 'banner_n',
			'type'       => 'number',
			'title'      => __('幻灯片数量', 'io_setting'),
			'default'    => '5',
			'class'      => 'compact',
			'dependency' => array('index_banner', '==', true)
		),
		array(
			'id'       => 'home_list_region',
			'type'     => 'image_select',
			'title'    => __('首页列表区域样式', 'io_setting'),
			'options'  => array(
				'1' => get_theme_file_uri('/images/frame/archive001.png'),
				'2' => get_theme_file_uri('/images/frame/archive002.png'),
				'3' => get_theme_file_uri('/images/frame/archive003.png'),
				'4' => get_theme_file_uri('/images/frame/archive004.png'),
				'5' => get_theme_file_uri('/images/frame/archive005.png'),
				'6' => get_theme_file_uri('/images/frame/archive006.png'),
			),
			'class'    => 'new',
			'default'  => '6',
			'subtitle' => __('选择首页列表区域样式', 'io_setting'),
		),
		array(
			'id'       => 'home_top',
			'type'     => 'switcher',
			'title'    => __('推荐阅读', 'io_setting'),
			'subtitle' => __('主页显示推荐阅读文章', 'io_setting'),
			'default'  => false
		),
		array(
			'id'         => 'home_top_title',
			'type'       => 'text',
			'title'      => __('推荐阅读文案', 'io_setting'),
			'default'    => '推荐阅读',
			'class'      => 'compact new',
			'dependency' => array('home_top', '==', true)
		),
		array(
			'id'             => 'home_top_pages',
			'type'           => 'select',
			'title'          => __('推荐阅读页面', 'io_setting'),
			'subtitle'       => __('所有推荐的文件页', 'io_setting'),
			'after'          => __('如果没有，请新建页面，选择“推荐文章”模板并保存', 'io_setting'),
			'options'        => 'pages',
			'query_args'     => array(
				'posts_per_page' => -1,
			),
			'class'          => 'compact',
			'default_option' => __('选择一个页面', 'io_setting'),
			'dependency'     => array('home_top', '==', true)
		),
		array(
			'id'       => 'index_topics',
			'type'     => 'switcher',
			'title'    => __('主页专题', 'io_setting'),
			'subtitle' => __('主页是否显示专题', 'io_setting'),
			'class'    => 'csf-depend-hidden csf-depend-on',
			'default'  => false
		),
		array(
			'id'          => 'index_topics_list',
			'type'        => 'select',
			'title'       => '主页专题显示内容',
			'chosen'      => true,
			'multiple'    => true,
			'placeholder' => '选择分类',
			'options'     => 'categories',
			'class'       => 'compact min csf-depend-hidden csf-depend-on',
			'after'       => __('选择分类，作为专题显示。(留空则使用[基础设置/专题页显示内容])', 'io_setting'),
			//'dependency'  => array( 'index_topics', '==', true )
		),
		array(
			'id'       => 'index_new_title',
			'type'     => 'text',
			'title'    => __('最新文章文案', 'io_setting'),
			'default'  => '最新文章',
			'class'    => 'new',
		),
		array(
			'id'      => 'index_cat_s',
			'type'    => 'switcher',
			'title'   => __('启用筛选', 'io_setting'),
			'default' => false
		),
		array(
			'id'         => 'index_cat',
			'type'       => 'checkbox',
			'title'      => __('启用分类', 'io_setting'),
			'subtitle'   => __('勾选主页筛选显示的分类', 'io_setting'),
			'options'    => 'categories',
			'inline'     => true,
			'class'      => 'compact',
			'dependency' => array('index_cat_s', '==', true)
		),
		array(
			'id'       => 'links',
			'type'     => 'switcher',
			'title'    => __('友情链接', 'io_setting'),
			'subtitle' => __('主页底部显示友情链接', 'io_setting'),
			'default'  => true
		),
		array(
			'id'             => 'links_pages',
			'type'           => 'select',
			'title'          => __('选择友情链接页面', 'io_setting'),
			'after'          => __('如果没有，请新建页面，选择“友情链接”模板并保存', 'io_setting'),
			'options'        => 'pages',
			'query_args'     => array(
				'posts_per_page' => -1,
			),
			'class'          => 'compact',
			'default_option' => __('选择一个页面', 'io_setting'),
			'dependency'     => array('links', '==', true)
		),
	),
));

/**
 * 页面设置
 */
CSF::createSection($prefix, array(
	'title'  => __('文章设置', 'io_setting'),
	'icon'   => 'fa fa-leanpub',

	'fields' => array(
		array(
			'id'       => 'single_region',
			'type'     => 'radio',
			'title'    => __('文章头图样式', 'io_setting'),
			'subtitle' => __('文章页顶部图片样式', 'io_setting'),
			'default'  => 'list1',
			'inline'   => true,
			'options'  => array(
				'list1'  => __('默认', 'io_setting'),
				'list2'  => __('全屏大图', 'io_setting'),
				'list3'  => __('全屏高斯模糊', 'io_setting'),
				'no_img' => __('无图', 'io_setting'),
			),
		),
		array(
			'id'       => 'post_menu',
			'title'    => __('文章目录', 'io_setting'),
			'subtitle' => __('自动生成、显示文章目录', 'io_setting'),
			'type'     => 'switcher',
			'default'  => true,
		),
		array(
			'id'       => 'copyright_show',
			'type'     => 'switcher',
			'title'    => __('显示版权', 'io_setting'),
			'subtitle' => __('文章底部显示版权', 'io_setting'),
			'default'  => true
		),
		array(
			'id'       => 'you_like',
			'type'     => 'switcher',
			'title'    => __('推荐阅读', 'io_setting'),
			'subtitle' => __('显示推荐阅读文章列表', 'io_setting'),
			'default'  => true
		),
		array(
			'type'    => 'subheading',
			'content' => __('打赏相关设置', 'io_setting'),
		),
		array(
			'id'       => 'reward_switcher',
			'type'     => 'switcher',
			'title'    => __('开启打赏', 'io_setting'),
			'subtitle' => __('在文章结尾出显示打赏按钮', 'io_setting'),
			'default'  => true
		),
		array(
			'id'         => 'reward_wechat_qrcode',
			'type'       => 'upload',
			'title'      => __('微信', 'io_setting'),
			'default'    => get_theme_file_uri('/images/wechat_qrcode.png'),
			'preview'    => true,
			'class'      => 'compact',
			'dependency' => array('reward_switcher', '==', true)
		),
		array(
			'id'         => 'reward_alipay_qrcode',
			'type'       => 'upload',
			'title'      => __('支付宝', 'io_setting'),
			'default'    => get_theme_file_uri('/images/alipay_qrcode.png'),
			'preview'    => true,
			'class'      => 'compact',
			'dependency' => array('reward_switcher', '==', true)
		),
		array(
			'id'         => 'reward_hongbao_qrcode',
			'type'       => 'upload',
			'title'      => __('支付宝红包码', 'io_setting'),
			'default'    => get_theme_file_uri('/images/hongbao_qrcode.png'),
			'preview'    => true,
			'class'      => 'compact',
			'dependency' => array('reward_switcher', '==', true)
		),
	),
));

/**
 * 添加代码
 */
CSF::createSection( $prefix, array(
	'title' => __('添加代码','io_setting'),
	'icon'  => 'fa fa-code',

	'fields' => array(
		array(
			'id'	   => 'head_code',
			'type'	 => 'code_editor',
			'title'	=> __('添加代码到头部','io_setting'),
			'after'	=> '<p class="cs-text-muted">'.__('出现在网站 head 中，主要用于验证网站...</p>','io_setting'),
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
		),
		array(
			'id'	   => 'foot_code',
			'type'	 => 'code_editor',
			'title'	=> __('添加代码到页脚','io_setting'),
			'after'	=> '<p class="cs-text-muted">'.__('出现在网站底部 body 前，主要用于站长统计代码...</p>','io_setting'),
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
		),
		array(
			'id'	   => 'custom_css',
			'type'	 => 'code_editor',
			'title'	=> __('自定义 CSS','io_setting'),
			'after'	=> '<p class="cs-text-muted">'.__('自定义 CSS,自定义美化...<br>如：','io_setting').'body .test{color:#ff0000;}</p>',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
		),
	),
));

/**
 * SEO 推广
 */
CSF::createSection( $prefix, array(
	'id'	=> 'seo_settings',
	'title' => __('SEO 推广','io_setting'),
	'icon'  => 'fa fa-paw',
));

/**
* SEO 推广-SEO 设置
*/
CSF::createSection( $prefix, array(
	'parent'   => 'seo_settings',
	'title'	 => __('SEO 设置','io_setting'),
	'icon'	  => 'fa fa-yoast',
	'fields' => array( 
        array(
            'type'    => 'submessage',
            'style'   => 'info',
            'content' => '主题seo获取规则：<br>标题：页面、文章的标题<br>关键词：默认获取文章的标签，如果没有，则为标题加网址名称<br>描叙：默认获取文章简介<br><br><b>注：此功能不影响其他SEO插件的功能</b>',
        ),
		array(
			'id'	  => 'io_home_title',
			'type'	=> 'text',
			'title'   => __('首页的标题','io_setting'),
			'placeholder' => $blog_name,
		),  
		array(
			'id'	  => 'io_home_keywords',
			'type'	=> 'text',
			'title'   => __('首页关键词','io_setting'),
			'after'   => __('<p class="cs-text-muted">添加关键词，用英文“,”分隔...</p>','io_setting'),
		), 
		array(
			'id'	  => 'io_home_description',
			'type'	=> 'textarea',
			'title'   => __('首页的描述','io_setting'),
		),  
		array(
			'id'		=> 'og_home_img',
			'type'	  	=> 'upload',
			'preview'   => true,
			'title'	 	=> __('默认 OG 图片','io_setting'),
			'default'   => get_theme_file_uri( '/screenshot.png'),
		),
		array(
			'type'		=> 'subheading',
			'content' 	=> __('全局SEO功能设定','io_setting'),
		), 
		array(
			'id'	  => 'io_auto_description_num',
			'type'	  => 'text',
			'title'   => __('Description 标签字数:','io_setting'),
			'after'   => __('截取文章字数数量','io_setting'),
			'default' => '150',
		),  
		array(
			'id'	  => 'io_seo_title_sep',
			'type'	=> 'text',
			'title'   => __('title后缀分隔符','io_setting'),
			'default' => ' | ',
			'after'   =>  __('一般用“-”“|”，如果需要左右留空，请自己左右留空格。','io_setting'),
			'subtitle'	=> __('留空则显示“ | ”','io_setting'),
		), 
		array(
			'type'	=> 'subheading',
			'content' => __('关键词链接','io_setting'),
		), 
        array(
            'id'        => 'tag_c',
            'type'      => 'fieldset',
            'title'     => __('关键词链接','io_setting'),
            'subtitle'  => '自动为文章中的关键词添加链接',
            'fields'    => array(
                array(
                    'id'        => 'switcher',
                    'type'      => 'switcher',
                    'title'     => __('开启','io_setting'),
                    'default'   => true,
                ),
                array(
                    'id'        => 'tags',
                    'type'      => 'group',
                    'title'     => '自定义关键词',
                    'fields'    => array(
                        array(
                            'id'        => 'tag',
                            'type'      => 'text',
                            'title'     => '关键词',
                        ),
                        array(
                            'id'        => 'url',
                            'type'      => 'text',
                            'title'     => '链接地址'
                        ),
                        array(
                            'id'        => 'describe',
                            'type'      => 'text',
                            'title'     => '描述',
                            'after'     => '为链接title属性',
                        ),
                    ),
                    'dependency' => array( 'switcher', '==', 'true', '', 'visible' ),
                ),
                array(
                    'id'         => 'auto',
                    'type'       => 'switcher',
                    'title'      => __('自动关键词','io_setting'),
                    'label'      => '自动将文章的标签当作关键词',
                    'default'    => true,
                    'dependency' => array( 'switcher', '==', 'true', '', 'visible' ),
                ),
                array(
                    'id'         => 'chain_n',
                    'title'      => __('链接数量','io_setting'),
                    'default'    => '1',
                    'type'       => 'number',
                    'desc'       => __('一篇文章中同一个标签最多自动链接几次，建议不大于2','io_setting'),
                    'dependency' => array( 'switcher', '==', 'true', '', 'visible' ),
                ),
            )
        ),
	),
));

//
// SEO-链接规则
//
CSF::createSection( $prefix, array(
    'parent'   => 'seo_settings',
    'title'       => __('链接规则','io_setting'),
    'icon'        => 'fas fa-link',
    'fields'      => array(
        array(
            'type'    => 'submessage',
            'style'   => 'info',
            'content' => '<p style="font-size:18px"><i class="fa fa-fw fa-info-circle fa-fw"></i> 本页内容修改后必须重新保存一次固定链接，且所有选项不能为<b>空</b>。前往<a href="'.admin_url('/options-permalink.php').'">wp设置</a>保存</p>',
        ),
        array(
            'id'         => 'rewrites_types',
            'type'       => 'button_set',
            'title'      => __('微语固定链接模式','io_setting'),
            'subtitle'   => '<span style="color:#f00">'.__('设置后需重新保存一次固定链接','io_setting').'</span>',
            'desc'       => '<span style="color:#000"><i class="fa fa-fw fa-info-circle fa-fw"></i> “微语”的固定链接模式<br>
                            默认文章的固定链接设置请前往<a href="'.admin_url('/options-permalink.php').'">wp设置</a>中设置，推荐 <code>/%post_id%.html</code></span>',
            'options'    =>  array(
                'post_id'  => '/%post_id%/',
                'postname' => '/%postname%/',
            ),
            'default'    => 'postname',
        ),
        array(
            'id'         => 'rewrites_end',
            'type'       => 'switcher',
            'title'      => __('html 结尾','io_setting'),
            'subtitle'   => '<span style="color:#f00">'.__('设置后需重新保存一次固定链接','io_setting').'</span>',
            'label'      => __('如：http://w.w.w/123.html','io_setting'),
        ),
        array(
            'id'        => 'shuo_rewrite',
            'type'      => 'fieldset',
            'title'     => '微语文章固定链接前缀',
            'subtitle'   => '<span style="color:#f00">'.__('设置后需重新保存一次固定链接','io_setting').'</span>',
            'fields'    => array(
                array(
                    'id'    => 'post',
                    'type'  => 'text',
                    'title' => '微语',
                ),
            ),
            'default'        => array(
                'post'        => 'shuo',
            ),
            'after'     => '<i class="fa fa-fw fa-info-circle fa-fw"></i> '.__('设置后需重新保存一次固定链接，且所有选项不能为空','io_setting'),
        ),
    )
));

/**
* SEO 推广-GO跳转
*/
CSF::createSection( $prefix, array(
	'parent'   => 'seo_settings',
	'title'	 => __('GO跳转','io_setting'),
	'icon'	  => 'fas fa-user-secret',
	'fields' => array( 
		array(
			'type'	=> 'subheading',
			'content' => __('外链跳转，效果：http://您的域名/go/?url=外链','io_setting'),
		),  
		array(
			'id' => 'link_to',
			'title' => __('文章外链跳转','io_setting'),
			'default' => true,
			'type' => 'switcher'
		),
        array(
            'id'      => 'is_must_on_site',
            'type'    => 'switcher',
            'title'   => '必须从站内点击才跳转',
            'label'   => '通过 referer 判断域名，如果不是在站内点击则跳转到网站首页。',
            'desc'    => $tip_ico.'如果开启选项导致所有链接都跳转到首页，请关闭！',
            'default' => true,
            'class'   => 'compact',
        ),
        array(
            'id'        => 'ref_id',
            'type'      => 'group',
            'title'     => '自定义来源id',
            'before'    => '在收藏网址的URL后面添加参数，如：https://www.iotheme.cn?key1=value1',
            'fields'    => array(
                array(
                    'id'    => 'key',
                    'type'  => 'text',
                    'title' => '键名(key)',
                ),
                array(
                    'id'    => 'value',
                    'type'  => 'text',
                    'title' => '值(value)',
                ),
            ),
            'default'   => array(
                array(
                    'key'   => 'ref',
                    'value' => parse_url(home_url())['host'], 
                ),
            ),
            'class' => 'compact',
            'dependency' => array( 'link_to', '==', 'true'),
        ),
        array(
            'id'        => 'go_tip',
            'type'      => 'fieldset',
            'title'     => __('跳转提示','io_setting'),
            'fields'    => array(
                array(
                    'id'    => 'switch',
                    'type'  => 'switcher',
                    'title' => __('启用','io_setting'), 
                    'label' => __('提示用户即将离开本站，注意账号和财产安全。','io_setting'),
                    'subtitle' => '颜色效果中的“全屏加载效果”选项无效',
                ),
                array(
                    'id'    => 'time',
                    'type'  => 'spinner',
                    'title' => __('等待跳转','io_setting'),
                    'after' => '等待多少秒自动跳转<br>注意：填0为手动点击按钮跳转',
                    'unit'  => '秒',
                    'step'  => 1,
                ),
            ),
            'default'        => array( 
                'switch'  => false,
                'time'    => 0, 
            ),
            'class'      => 'compact',
            'dependency' => array( 'link_to', '==', 'true'),
        ),
        array(
            'id'      => 'exclude_links', 
            'type'    => 'textarea',
            'title'   => __('go跳转白名单','io_setting'),
            'subtitle'=> __('go跳转和正文nofollow白名单','io_setting'),
            'after'   => __('一行一个地址，注意不要有空格。<br>需要包含http(s)://<br>iowen.cn和www.iowen.cn为不同的网址<br>此设置同时用于 nofollow 的排除。','io_setting'),
        ),
		array(
			'id' => 'comment_to',
			'title' => __('评论者链接跳转','io_setting'),
			'default' => true,
			'type' => 'switcher'
		), 
	),
));
// ------------------------------
// SEO 推广-推送设置					   -
// ------------------------------
CSF::createSection( $prefix, array(
	'parent'   => 'seo_settings',
	'name'		=> 'pushoptions',
	'title'	   => __('sitemap&推送','io_setting'),
	'icon'		=> 'fa fa-line-chart',
	'fields'	  => array(
		array(
			'id'	  => 'baidu_submit',
			'type'	=> 'switcher',
			'default' => false,
			'title'   => __('百度主动推送','io_setting'),
		),	
		array(
			'id'	   => 'token_p',
			'type'	 => 'text',
			'title'	=> __('推送token值','io_setting'),
			'after'	=> __('输入百度主动推送token值','io_setting'),
			'class' => 'compact',
			'dependency'   => array( 'baidu_submit', '==', 'true' )
		), 
		array(
			'id'	   => 'baidu_xzh',
			'title'	=> __('百度熊掌号','io_setting'),
			'type'	 => 'switcher',
			'default'  => false,
		),
		array(
			'id'	   => 'xzh_id',
			'title'	=> __('熊掌号ID','io_setting'),
			'type'	 => 'text',
			'class' => 'compact',
			'dependency'   => array( 'baidu_xzh', '==', 'true' )
		),
		array(
			'id'	   => 'xzh_token',
			'title'	=> __('准入密钥','io_setting'),
			'type'	 => 'text',
			'class' => 'compact',
			'dependency'   => array( 'baidu_xzh', '==', 'true' )
		),
		array(
			'id'	   => 'xzh_gz',
			'title'	=> __('显示关注按钮','io_setting'),
			'type'	 => 'switcher',
			'class' => 'compact',
			'dependency'   => array( 'baidu_xzh|xzh_id|xzh_token', '==|!=|!=', 'true||' )
		),
		array(
			'id'	  => 'site_map',
			'title'   => __('SiteMAP','io_setting'),
			'type'	=> 'switcher',
			'label'	=> __('启用主题 sitemap，生成 sitemap.xml 文件','io_setting'),
			'default' => false,
		),
		array(
			'id'		=> 'site_options',
			'type'	  => 'fieldset',
			'title'	 => __('SiteMAP选项','io_setting'),
			'fields'	=> array(
				array(
					'type'	=> 'content',
					'content' => '<span>自动生成xml文件，遵循Sitemap协议，用于指引搜索引擎快速、全面的抓取或更新网站上内容及处理错误信息。兼容百度、google、360等主流搜索引擎。</span><span style="display:block; margin-top: 10px;">注意：参数需要保存后才生效，请设置完参数保存后再点击&quot;生成sitemap&quot;按钮。</span>',
				),
				array(
					'id'	  => 'baidu-post-types',
					'type'	=> 'checkbox',
					'title'   => __('生成链接文章类型','io_setting'),
					'options' => 'post_types',
					'inline'  => true,
					'after'	  => '例：如果仅希望生成文章的sitemap，则只勾选文章即可。'
				),
				array(
					'id'	  => 'baidu-taxonomies',
					'type'	=> 'checkbox',
					'title'   => __( '生成链接分类', 'io_setting' ),
					'options' => 'setting_get_taxes',
					'inline'  => true,
				),
				array(
					'id'	  => 'baidu-num',
					'type'	=> 'text',
					'title'   => __('生成链接数量','io_setting'),
					'after'   => '链接数越大所占用的资源也越大，根据自己的服务器配置情况设置数量。最新发布的文章首先排在最前。 -1 表示所有。<br />此数量仅指post type的数量总和，不包括分类，勾选的分类是全部生成链接。',
				),
				array(
					'id'	  => 'baidu-auto-update',
					'type'	=> 'switcher',
					'title'   => __('自动更新','io_setting'),
					'label'   => '勾选则发布新文章或者删除文章时自动更新sitemap。',
				),
				array(
					'type'	 => 'callback',
					'function' => 'io_site_map_but',
				),
			),
			'default' => array(
				'sitemap-file'		=> 'sitemap', 
				'baidu-post-types'	=> array( 'post', 'page' ),
				'baidu-taxonomies'	=> array( 'category' ),
				'baidu-num'			=> '500',
				'baidu-auto-update'	=> true,
			),
			'class' => 'compact',
			'dependency' => array( 'site_map', '==', true )
		),
	),
));

/**
 * 社交分享
 */
CSF::createSection( $prefix, array(
	'title' => __('社交分享','io_setting'),
	'icon'  => 'fa fa-share',

	'fields' => array(
		array(
			'id'	  => 'ioc_share',
			'type'	=> 'switcher',
			'title'   => __('分享','io_setting'),
			'subtitle'	=> __('启用文章页分享按钮（默认开启）','io_setting'),
			'default' => true
		),
		array(
			'id'		   => 'i_share_item',
			'type'		 => 'checkbox',
			'title'		=> __('分享渠道','io_setting'),
			'inline'  => true,
			'options'	  => array(
				'weibo'	 => __('微博','io_setting'),
				'qq'		=> 'QQ',
				'qzone'	 => __('QQ空间','io_setting'),
				'weixin'	=> __('微信','io_setting'),
				'douban'	=> __('豆瓣','io_setting'),
				'facebook'  => 'Facebook',
				'twitter'   => 'Twitter',
				'google'	=> 'Google+',
				'email'	 => 'Email',
			),
			'class' => 'compact',
			'default'	  => array( 'weibo', 'qq', 'weixin','douban' ),
			'after'		=> __('选择您需要的分享渠道','io_setting'),
			'dependency'   => array( 'ioc_share', '==', true )
		),
		array(
			'id'	  => 'ioc_poster_cover',
			'type'	=> 'switcher',
			'title'   => __('生成海报','io_setting'),
			'subtitle'	=> __('生成封面海报并分享，需开启“分享”（默认开启）','io_setting'),
			'default' => true,
			'class' => 'compact',
			'dependency'   => array( 'ioc_share', '==', true )
		), 
		array(
			'id'		=> 'poster_default_img',
			'type'	  => 'upload',
			'title'	 => '┗━━━'.__('默认头部大图','io_setting'),
			'subtitle'  => __('上传一张显示在封面顶部的大图，用于没有图片的文章','io_setting'),
			'preview'   => true,
			'default' 	=> get_theme_file_uri('/screenshot.png'),
			'class' => 'compact',
			'dependency'=> array( 'ioc_share|ioc_poster_cover', '==|==', 'true|true' )
		), 
		array(
			'id'		=> 'poster_logo',
			'type'		=> 'upload',
			'title' 	=> '┗━━━'.__('左下角LOGO','io_setting'),
			'subtitle'  => __('上传一张显示在封面底部的LOGO','io_setting'),
			'preview'   => true,
			'default' 	=> get_theme_file_uri('/images/logo.png'),
			'after' 	=> __('建议 240x50','io_setting'),
			'class' => 'compact',
			'dependency'=> array( 'ioc_share|ioc_poster_cover', '==|==', 'true|true')
		), 
		array(
			'id'		 => 'poster_desc',
			'type'	   => 'text',
			'title'	  => '┗━━━'.__('网站宣传语','io_setting'),
			'subtitle'   => __('显示在LOGO下方的一句宣传语','io_setting'),
			'default' 	 => get_bloginfo( 'description'),
			'class' => 'compact',
			'dependency' => array( 'ioc_share|ioc_poster_cover', '==|==', 'true|true' )
		), 
		array(
			'id'	  => 'share_poster_img_qrcode',
			'type'	=> 'switcher',
			'title'   => '┗━━━'.__('右下角二维码','io_setting'),
			'subtitle'	=> __('开启后将再封面图的右下角现在当前文章的二维码','io_setting'),
			'default' => true,
			'class' => 'compact',
			'dependency'   => array( 'ioc_share|ioc_poster_cover', '==|==', 'true|true' )
		), 
		array(
			'type'	=> 'subheading',
			'content' => __('社交信息','io_setting'),
		),
        array(
            'id'        => 'social_lists',
            'type'      => 'group',
            'title'     => ' ', 
            'subtitle'  => '社交信息',
            'class'     => 'new',
            'before'    => '<i class="fa fa-fw fa-info-circle fa-fw"></i> 菜单、页脚、悬浮小工具都在此处设置',
            'fields'    => array(
                array(
                    'id'    => 'name',
                    'type'  => 'text',
                    'title' => '名称',
                ),
                array(
                    'id'      => 'loc',
                    'type'    => 'checkbox',
                    'title'   => __('显示位置','io_setting'), 
                    'options' =>  array(
                        'menu'      => '菜单',
                        'footer'    => 'footer',
                        'tools'     => '悬浮小工具',
                    ),
					'inline'  => true,
                    'class'   => 'compact min',
                    'default' => 'footer',
                ),
                array(
                    'id'        => 'ico',
                    'type'      => 'icon',
                    'title'     => '图标', 
                    'default'   => 'iconfont icon-related',
                    'class'     => 'compact min'
                ),
                array(
                    'id'        => 'type',
                    'type'      => 'button_set',
                    'title'     => __('类型','io_setting'),
                    'options'   => array(
                        'url'       => 'URL连接',
                        'img'       => '图片弹窗（如微信二维码）',
                    ),
                    'default'   => 'url',
                    'class'      => 'compact min'
                ),
                array(
                    'id'    => 'url',
                    'type'  => 'text',
                    'title' => '地址：',
                    'after' => '<p class="cs-text-muted">【图片弹窗】请填图片地址<br><i class="fa fa-fw fa-info-circle fa-fw"></i> 如果要填QQ，请转换为URL地址，格式为：<br><code>http://wpa.qq.com/msgrd?V=3&uin=xxxxxxxx&Site=QQ&Menu=yes</code><br>将xxxxxx改为您自己的QQ号</p>',
                    'class'      => 'compact min'
                ),
            ), 
            'default'   => array(
                array(
                    'name'  => '微信',
                    'loc'   => ['menu','footer'],
                    'ico'   => 'iconfont icon-wechat',
                    'type'  => 'img',
                    'url'   => get_theme_file_uri('/images/wechat_qrcode.png'),
                ),
                array(
                    'name'  => 'QQ',
                    'loc'   => ['menu','footer'],
                    'ico'   => 'iconfont icon-qq',
                    'type'  => 'url',
                    'url'   => 'http://wpa.qq.com/msgrd?V=3&uin=xxxxxxxx&Site=QQ&Menu=yes',
                ),
                array(
                    'name'  => '微博',
                    'loc'   => 'footer',
                    'ico'   => 'iconfont icon-weibo',
                    'type'  => 'url',
                    'url'   => 'https://www.iotheme.cn',
                ),
                array(
                    'name'  => 'GitHub',
                    'loc'   => 'footer',
                    'ico'   => 'iconfont icon-github',
                    'type'  => 'url',
                    'url'   => 'https://www.iotheme.cn',
                ),
                array(
                    'name'  => 'Email',
                    'loc'   => 'footer',
                    'ico'   => 'iconfont icon-email',
                    'type'  => 'url',
                    'url'   => 'mailto:1234567788@QQ.COM',
                )
            ), 
        ),

		array(
			'id'	  => 'footer_search',
			'type'	=> 'switcher',
			'title'   => __('搜索','io_setting'),
			'subtitle'	=> __('是否显示搜索按钮','io_setting'),
			'default' => true
		),
	),
));

//
// 优化设置
//
CSF::createSection( $prefix, array(
	'id'	=> 'optimize',
	'title' => __('优化设置','io_setting'),
	'icon'  => 'fa fa-rocket',
));

//
// 优化设置-禁用功能
//
CSF::createSection( $prefix, array(
	'parent'	  => 'optimize',
	'title'	   => __('禁用功能','io_setting'),
	'icon'		=> 'fa fa-wordpress',
	'fields'	  => array(
        array(
            'type'    => 'submessage',
            'style'   => 'danger',
            'content' => '<p style="font-size:18px">'.$tip_ico.'注意</p>
            <p>如果不了解下面选项的作用，请保持原样！</p>',
        ),
		array(
			'id'	  => 'disable_rest_api',
			'type'	=> 'switcher',
			'title'   => __('禁用REST API','io_setting'),
			'label'   => __('禁用REST API、移除wp-json链接（默认关闭，如果你的网站没有做小程序或是APP，建议禁用REST API）','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => false
		),
 
		
		array(
			'id'	  => 'disable_revision',
			'type'	=> 'switcher',
			'title'   => __('禁用文章修订功能','io_setting'),
			'label'   => __('禁用文章修订功能，精简 Posts 表数据。(如果古滕堡报错，请关闭该选项)','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),
 
		
		array(
			'id'	  => 'disable_texturize',
			'type'	=> 'switcher',
			'title'   => __('禁用字符转码','io_setting'),
			'label'   => __('禁用字符换成格式化的 HTML 实体功能。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),

		array(
			'id'	  => 'disable_feed',
			'type'	=> 'switcher',
			'title'   => __('禁用站点Feed','io_setting'),
			'label'   => __('禁用站点Feed，防止文章快速被采集。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),

		array(
			'id'	  => 'disable_trackbacks',
			'type'	=> 'switcher',
			'title'   => __('禁用Trackbacks','io_setting'),
			'label'   => __('Trackbacks协议被滥用，会给博客产生大量垃圾留言，建议彻底关闭Trackbacks。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),

		array(
			'id'	  => 'disable_gutenberg',
			'type'	=> 'switcher',
			'title'   => __('禁用古腾堡编辑器','io_setting'),
			'label'   => __('禁用Gutenberg编辑器，换回经典编辑器。推荐禁用','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),

		array(
			'id'	  => 'disable_xml_rpc',
			'type'	=> 'switcher',
			'title'   => ' ┗━━ '.__('禁用XML-RPC','io_setting'),
			'label'   => __('XML-RPC协议用于客户端发布文章，如果你只是在后台发布，可以关闭XML-RPC功能。Gutenberg编辑器需要XML-RPC功能。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => false,
			'class' => 'compact',
			'dependency' => array( 'disable_gutenberg', '==', true )
		),

		array(
			'id'	  => 'disable_privacy',
			'type'	=> 'switcher',
			'title'   => __('禁用后台隐私（GDPR）','io_setting'),
			'label'   => __('GDPR（General Data Protection Regulation）是欧洲的通用数据保护条例，WordPress为了适应该法律，在后台设置很多隐私功能，如果只是在国内运营博客，可以移除后台隐私相关的页面。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => false
		),
		array(
			'id'	  => 'emoji_switcher',
			'type'	=> 'switcher',
			'title'   => __('禁用emoji代码','io_setting'),
			'label'   => __('WordPress 为了兼容在一些比较老旧的浏览器能够显示 Emoji 表情图标，而准备的功能。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),
		array(
			'id'	  => 'disable_autoembed',
			'type'	=> 'switcher',
			'title'   => __('禁用Auto Embeds','io_setting'),
			'label'   => __('禁用 Auto Embeds 功能，加快页面解析速度。 Auto Embeds 支持的网站大部分都是国外的网站，建议禁用。','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => true
		),
		array(
			'id'	  => 'disable_post_embed',
			'type'	=> 'switcher',
			'title'   => __('禁用文章Embed','io_setting'),
			'label'   => __('禁用可嵌入其他 WordPress 文章的Embed功能','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => false
		),
		array(
			'id'	  => 'remove_dns_prefetch',
			'type'	=> 'switcher',
			'title'   => __('禁用s.w.org','io_setting'),
			'label'   => __('移除 WordPress 头部加载 DNS 预获取（s.w.org 国内根本无法访问）','io_setting'),
			'text_on' => '已禁用',
			'text_off'=> '未禁用',
			'text_width' => 80,
			'default' => false
		),
	)
));

/**
 * 优化设置-优化加速
 */
CSF::createSection( $prefix, array(
	'parent'	  => 'optimize',
	'title' => __('优化加速','io_setting'),
	'icon'  => 'fa fa-wordpress',
	'fields' => array(
        array(
            'type'    => 'submessage',
            'style'   => 'danger',
            'content' => '<p style="font-size:18px">'.$tip_ico.'注意</p>
            <p>如果不了解下面选项的作用，请保持原样！</p>',
        ),
		array(
			'id'	  => 'remove_head_links',
			'type'	=> 'switcher',
			'title'   => __('移除头部代码','io_setting'),
			'label'   => __('WordPress会在页面的头部输出了一些link和meta标签代码，这些代码没什么作用，并且存在安全隐患，建议移除WordPress页面头部中无关紧要的代码。','io_setting'),
			'default' => true
		),

		array(
			'id'	  => 'remove_admin_bar',
			'type'	=> 'switcher',
			'title'   => __('移除admin bar','io_setting'),
			'label'   => __('WordPress用户登陆的情况下会出现Admin Bar，此选项可以帮助你全局移除工具栏，所有人包括管理员都看不到。','io_setting'),
			'default' => true
		),
		array(
			'id'	  => 'ioc_category',
			'type'	=> 'switcher',
			'title'   => __('去除分类标志','io_setting'),
			'label'   => __('去除链接中的分类category标志，有利于SEO优化，每次开启或关闭此功能，都需要重新保存一下固定链接！','io_setting'),
			'default' => true
		),
		array(
			'id'      => 'gravatar_cdn',
			'type'    => 'radio',
			'title'   => 'Gravatar头像加速',
			'inline'  => true,
			'options' => array(
				'gravatar'    => 'Gravatar 官方服务',
				'cravatar'    => 'Cravatar 国内镜像',
				'iocdn'       => '一为云 加速服务（cdn.iocdn.cc）',
			),
			'default' => 'iocdn',
			'after'   => '自定义修改：inc/wp-optimization.php',
		),
		array(
			'id'	  => 'remove_help_tabs',
			'type'	=> 'switcher',
			'title'   => __('移除帮助按钮','io_setting'),
			'label'   => __('移除后台界面右上角的帮助','io_setting'),
			'default' => false
		),
		array(
			'id'	  => 'remove_screen_options',
			'type'	=> 'switcher',
			'title'   => __('移除选项按钮','io_setting'),
			'label'   => __('移除后台界面右上角的选项','io_setting'),
			'default' => false
		),
		array(
			'id'	  => 'no_admin',
			'type'	=> 'switcher',
			'title'   => __('禁用 admin','io_setting'),
			'label'   => __('禁止使用 admin 用户名尝试登录 WordPress。','io_setting'),
			'default' => false
		),
		array(
			'id'	  => 'compress_html',
			'type'	=> 'switcher',
			'title'   => __('压缩 html 源码','io_setting'),
			'label'   => __('压缩网站源码，提高加载速度。（如果启用发现网站布局错误，请禁用。）','io_setting'),
			'default' => false
		),
	),
));

/**
 * 页脚信息
 */
CSF::createSection( $prefix, array(
	'title' => __('页脚信息','io_setting'),
	'icon'  => 'fa fa-caret-square-o-down',
	'fields' => array(
	array(
			'type'	=> 'subheading',
			'content' => __('页脚信息','io_setting'),
		),
		array(
			'id'		=> 'footer_copyright',
			'type'	  	=> 'wp_editor',
			'title'	 	=> __('自定义页脚版权','io_setting'),
			'after'	 	=> __('<p class="cs-text-muted">版权信息，填写此项后上面的 “备案号” 设置无效...</p>','io_setting'), 
			'height'	=> '100px',
			'sanitize'	=> false,
		),
		array(
			'id'		 	=> 'footer_icp',
			'type'	   		=> 'text',
			'title'	  		=> __('备案号','io_setting'),
            'after'   		=> '<i class="fa fa-fw fa-info-circle fa-fw"></i> 此选项“自定义页脚版权”非空则禁用',
            'dependency'  	=> array( 'footer_copyright', '==', '', '', 'visible' ),
		),
        array(
            'id'     	=> 'police_icp',
            'type'   	=> 'text',
            'title'  	=> '公安备案号', 
            'after'   	=> '<i class="fa fa-fw fa-info-circle fa-fw"></i> 此选项“自定义页脚版权”非空则禁用',
            'dependency'  => array( 'footer_copyright', '==', '', '', 'visible' ),
        ),
		array(
			'id'	  	=> 'io_aff',
			'type'		=> 'switcher',
			'title'   	=> __('显示一为推广按钮','io_setting'),
			'label'		=> __('添加推广链接获取佣金','io_setting'),
            'after'   	=> '<br><p>显示： 由 Swallow 强力驱动</p>',
			'default'	=> true,
		),
        array(
            'id'     	=> 'io_id',
            'type'   	=> 'text',
            'title'  	=> '一为推广ID', 
            'after'   	=> 'iotheme.cn上的用户ID，6位数纯数字ID。<a href="https://www.iotheme.cn/user" target="_blank">获取ID</a>',
            'dependency'  => array( 'io_aff', '==', true),
            'class'    	=> 'compact',
        ),
		array(
			'id'	  => 'show_inquire',
			'type'	=> 'switcher',
			'title'   => __('显示数据库查询','io_setting'),
			'label'	=> __('页脚显示数据查询次数、时间等','io_setting'),
		),
		array(
			'id'		 => 'down_explain',
			'type'	   => 'textarea',
			'title'	  => __('下载页面版权说明','io_setting'),
			'default'	=> __('本站大部分下载资源收集于网络，只做学习和交流使用，版权归原作者所有。若您需要使用非免费的软件或服务，请购买正版授权并合法使用。本站发布的内容若侵犯到您的权益，请联系站长删除，我们将及时处理。','io_setting'),
		),
	),
));

/**
 * 广告
 */
CSF::createSection( $prefix, array(
	'title' => __('广告位','io_setting'),
	'icon'  => 'fa fa-google',
	'fields' => array(
		array(
			'title'	  => __('头部广告代码','io_setting'),
			'subtitle'	   => __('需要在页头&lt;head&gt;&lt;/head&gt;之间加载的广告代码','io_setting'),
			'id'		 => 'ad_t',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
		),
		array(
			'title'	  => __('菜单栏广告位','io_setting'),
			'subtitle'	   => __('显示','io_setting'),
			'id'		 => 'ad_home_top',
			'type'	   => 'switcher'
		),
		array(
			'title'	  => __('只在首页显示','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_home_top_onlyhome',
			'type'	   => 'switcher',
			'class' => 'compact',
			'dependency' => array( 'ad_home_top', '==', true )
		),
		array(
			'title'	  => __('输入头部通栏广告代码','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_home_top_c',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
			'class' => 'compact',
			'dependency' => array( 'ad_home_top', '==', true )
		),
		array(
			'title'	  => __('页脚广告位','io_setting'),
			'subtitle'	   => __('显示','io_setting'),
			'id'		 => 'ad_footer',
			'type'	   => 'switcher'
		),
		array(
			'title'	  => __('输入页脚广告位代码','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_footer_c',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
			'class' => 'compact',
			'dependency' => array( 'ad_footer', '==', true )
		),
		array(
			'title'	  => __('正文标题广告位','io_setting'),
			'subtitle'	   => __('显示','io_setting'),
			'id'		 => 'ad_s_title',
			'type'	   => 'switcher'
		),
		array(
			'title'	  => __('输入正文标题广告代码','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_s_title_c',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
			'class' => 'compact',
			'dependency' => array( 'ad_s_title', '==', true )
		),
		array(
			'title'	  => __('正文底部广告位','io_setting'),
			'subtitle'	   => __('显示','io_setting'),
			'id'		 => 'ad_s_b',
			'default'	=> '0',
			'type'	   => 'switcher'
		),
		array(
			'title'	  => __('输入正文底部广告代码','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_s_b_c',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
			'class' => 'compact',
			'dependency' => array( 'ad_s_b', '==', true )
		),
		array(
			'title'	  => __('正文短代码广告位','io_setting'),
			'subtitle'	   => __('输入正文短代码广告代码','io_setting'),
			'id'		 => 'ad_s_z',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
		),
		array(
			'title'	  => __('评论上方广告位','io_setting'),
			'subtitle'	   => __('显示','io_setting'),
			'id'		 => 'ad_c',
			'type'	   => 'switcher'
		),
		array(
			'title'	  => __('输入评论上方广告代码','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_c_c',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
			'class' => 'compact',
			'dependency' => array( 'ad_c', '==', true )
		),
		array(
			'title'	  => __('文件下载页面广告代码','io_setting'),
			'subtitle'	   => '',
			'id'		 => 'ad_down',
			'default'	=> '<a href="#" target="_blank"><img src="' . get_template_directory_uri() . '/images/ad.jpg" alt="广告也精彩" /></a>',
			'type'	   => 'code_editor',
			'settings' => array(
				'textarea_rows' => 5,
				'tinymce'	   => false,
				'media_buttons' => false,
			),
			'sanitize'   => false,
		),
	),
));

/**
 * 其他设置
 */
CSF::createSection( $prefix, array(
	'id'	=> 'other_settings',
	'title' => __('其他设置','io_setting'),
	'icon'  => 'fa fa-sliders',
));

//邮件发信
CSF::createSection( $prefix, array(
	'parent'   => 'other_settings',
	'name'	  => 'mailSending',
	'title'	 => __('邮件发信','io_setting'),
	'icon'	  => 'fa fa-envelope-open',
	'fields'	=> array(
        array(
            'type'    => 'submessage',
            'style'   => 'danger',
            'content' => '<h4>邮件发信服务设置</h4><p>如果你不需要评论邮件通知等功能，可不设置。<br/>国内一般使用 SMTP 服务</p>
            <p><i class="fa fa-fw fa-info-circle fa-fw"></i> 注：如果要关闭或者使用<b>第三方插件</b>
            请选择“关闭”，不能和其他SMTP插件一起开启！同时请注意开启服务器对应的端口！</p>',
        ),
		array(
			'id'	  => 'i_default_mailer',
			'type'	  => 'radio',
			'title'   => 'SMTP/PHPMailer',
			'subtitle'	=> '',
			'default' => 'php',
			'inline'  => true,
			'options' => array(
				'php'   => '关闭',
				'smtp'  => 'SMTP'
			),
            'after'    => __('使用 “SMTP” 或 “关闭”用第三方插件 作为默认邮件发送方式','io_setting'),
		),
		array(
			'id'		 => 'i_smtp_host',
			'type'	   => 'text',
			'title'	  => __('SMTP 主机','io_setting'),
			'after'	  => __('您的 SMTP 服务主机','io_setting'),
			'class' => 'compact',
			'dependency' => array( 'i_default_mailer', '==', 'smtp' )
		), 
		array(
			'id'		 => 'i_smtp_port',
			'type'	   => 'text',
			'title'	  => __('SMTP 端口','io_setting'),
			'after'	  => __('您的 SMTP 服务端口','io_setting'),
			'default'	=> 465,
			'class' => 'compact',
			'dependency' => array( 'i_default_mailer', '==', 'smtp' )
		), 
		array(
			'id'	   => 'i_smtp_secure',
			'type'	 => 'radio',
			'title'	=> __('SMTP 安全','io_setting'),
			'after'	=> __('您的 SMTP 服务器安全协议','io_setting'),
			'default'  => 'ssl',
			'inline'  => true,
			'options'  => array(
				'auto'   => 'Auto',
				'ssl'	=> 'SSL',
				'tls'	=> 'TLS',
				'none'   => 'None'
			),
			'class' => 'compact',
			'dependency'   => array( 'i_default_mailer', '==', 'smtp' )
		), 
		array(
			'id'	  => 'i_smtp_username',
			'type'	=> 'text',
			'title'   => __('SMTP 用户名','io_setting'),
			'after'   => __('您的 SMTP 用户名','io_setting'),
			'class' => 'compact',
			'dependency'   => array( 'i_default_mailer', '==', 'smtp' )
		),  
		array(
			'id'	  => 'i_smtp_password',
			'type'	=> 'text',
			'title'   => __('SMTP 密码','io_setting'),
			'after'   => __('您的 SMTP 密码','io_setting'),
			'class' => 'compact',
			'dependency'   => array( 'i_default_mailer', '==', 'smtp' )
		),  
		array(
			'id'	  => 'i_smtp_name',
			'type'	=> 'text',
			'title'   => __('你的姓名','io_setting'),
			'default' => $blog_name,
			'after'   => __('你发送的邮件中显示的名称','io_setting'),
			'class' => 'compact',
			'dependency'   => array( 'i_default_mailer', '==', 'smtp' ),
		), 
        array(
            'type'    => 'submessage',
            'style'   => 'warning',
            'content' => '<h4>邮件发送测试</h4>
            <p>输入接收邮件的邮箱号码，发送测试邮件</p>
            <ajaxform class="ajax-form" ajax-url="' . admin_url('admin-ajax.php') . '">
            <p><input type="text" class="not-change" ajax-name="email"></p>
            <div class="ajax-notice"></div>
            <p><a href="javascript:;" class="button button-primary ajax-submit"><i class="fa fa-paper-plane-o"></i> 发送测试邮件</a></p>
            <input type="hidden" ajax-name="action" value="test_mail">
            </ajaxform>',
        ),
		array(
			'type'	=> 'subheading',
			'content' => __('邮件通知','io_setting'),
		),
		array(
			'id'	  => 'i_login_success_notify',
			'type'	=> 'switcher',
			'title'   => __('登录成功邮件提醒','io_setting'),
			'label'   => __('开启登录成功事件的邮件通知','io_setting'),
			'default' => false
		),
		array(
			'id'	  => 'i_login_failure_notify',
			'type'	=> 'switcher',
			'title'   => __('登录错误邮件提醒','io_setting'),
			'label'   => __('开启登录失败事件的邮件通知（建议关掉）','io_setting'),
			'default' => false
		),
		array(
			'id'	  => 'i_comment_events_notify',
			'type'	=> 'switcher',
			'title'   => __('评论相关邮件提醒','io_setting'),
			'label'   => __('启用评论邮件提醒(如果你的邮件发送较慢，将影响评论提交速度)','io_setting'),
			'default' => true
		),
	),
));
// 评论
CSF::createSection( $prefix, array(
	'parent'   => 'other_settings',
	'name'		=> 'comment',
	'title'	   => __('评论设置','io_setting'),
	'icon'		=> 'fa fa-comments',
	'fields'	  => array(
		// 评论总开关
		array(
			'id'	  => 'comment_switcher',
			'type'	  => 'switcher',
			'title'	  => __('评论总开关','io_setting'),
			'default' => true,
            'label'   => '全局开关',
			'class'   => 'new'
		),	

		array(
			'id'		=> 'ma_comment_unlock',
			'type'	  => 'switcher',
			'default'   => true,
			'title'	 => __('启用滑动验证','io_setting'),
		),	
		array(
			'id'       => 'comm-code',
			'type'     => 'switcher',
			'default'  => false,
			'title'    => __('允许插入代码','io_setting'),
			'class'   => 'compact min new'
		),
		array(
			'id'       => 'comm-img',
			'type'     => 'switcher',
			'default'  => false,
			'title'    => __('允许插入图片','io_setting'),
			'class'   => 'compact min new'
		),	
		array(
			'id'       => 'comm-up-img',
			'type'     => 'switcher',
			'default'  => false,
			'title'    => __('允许上传图片','io_setting'),
			'class'   => 'compact min new'
		),
		array(
			'id'      => 'upload_img_size',
			'type'    => 'spinner',
			'title'   => '前端图像上传限制',
			'default' => 256,
			'desc'    => '前端允许上传的最大图像大小',
			'after'   => $tip_ico.'填 0 关闭图标上传。',
			'max'     => 5120,
			'min'     => 0,
			'unit'    => 'kb',
			'class'   => 'compact min new',
			'dependency' => array( 'comm-up-img', '==', true )
		),
        array(
            'id'        => 'ip_location',
            'type'      => 'fieldset',
            'title'     => __('IP归属地','io_setting'),
            'fields'    => array(
                array(
                    'id'      => 'level',
                    'type'    => "select",
                    'title'   => 'IP归属地显示格式',
                    'options' => array(
                        '1' => '仅国家',
                        '2' => '仅省',
                        '3' => '仅市',
                        '4' => '国家+省',
                        '5' => '省+市',
                        '6' => '详细',
                    ),
                    'default' => '2',
                ),
                array(
                    'id'      => 'v4_type',
                    'type'    => 'radio',
                    'title'   => 'IPv4归属地数据库版本',
                    'inline'  => true,
                    'options' => array(
                        'qqwry'     => 'QQwry',
                        'ip2region' => 'Ip2Region',
                    ), 
                    'class'   => 'compact min',
                    'default' => 'qqwry',
                ),
                array(
                    'id'      => 'comment',
                    'type'    => 'switcher',
                    'title'   => '评论显示用户归属地',
                    'default' => false,
                    'class'   => 'compact min',
                ),
                array(
                    'type'    => 'submessage',
                    'style'   => 'info',
                    'content' => ip_db_manage(),
                ),
            ),
			'class'   => 'new'
        ),

	 	// 评论头衔
		array(
				'id'		=> 'comment_rank',
				'title'	 => __('访客头衔','io_setting'),
				'type'	  => 'switcher',
				'label'	 => __('按评论数排行，评论越多，等级越高，可以修改为自己喜欢的头衔','io_setting'),
		),
		array(
				'id'		 => 'comment_rank_1',
				'type'	   => 'text',
				'default'	=> 'VIP 1',
				'title'	  => __('等级 1','io_setting'),
				'class' => 'compact',
				'dependency' => array( 'comment_rank', '==', 'true' ),
		),
		array(
				'id'		 => 'comment_rank_2',
				'type'	   => 'text',
				'default'	=> 'VIP 2',
				'title'	  => __('等级 2','io_setting'),
				'class' => 'compact',
				'dependency' => array( 'comment_rank', '==', 'true' ),
		),
		array(
				'id'		 => 'comment_rank_3',
				'type'	   => 'text',
				'default'	=> 'VIP 3',
				'title'	  => __('等级 3','io_setting'),
				'class' => 'compact',
				'dependency' => array( 'comment_rank', '==', 'true' ),
		),
		array(
				'id'		 => 'comment_rank_4',
				'type'	   => 'text',
				'default'	=> 'VIP 4',
				'title'	  => __('等级 4','io_setting'),
				'class' => 'compact',
				'dependency' => array( 'comment_rank', '==', 'true' ),
		),
		array(
				'id'		 => 'comment_rank_5',
				'type'	   => 'text',
				'default'	=> 'VIP 5',
				'title'	  => __('等级 5','io_setting'),
				'class' => 'compact',
				'dependency' => array( 'comment_rank', '==', 'true' ),
		),
		array(
				'id'		 => 'comment_rank_6',
				'type'	   => 'text',
				'default'	=> 'VIP 6',
				'title'	  => __('等级 6','io_setting'),
				'class' => 'compact',
				'dependency' => array( 'comment_rank', '==', 'true' ),
		),
	),
));
// 缩略图 CDN
CSF::createSection( $prefix, array(
	'parent'   => 'other_settings',
	'name'		=> 'thumbnail',
	'title'	   => __('缩略图/CDN','io_setting'),
	'icon'		=> 'fa fa-soundcloud',
	'fields'	  => array(
		array(
			'content' => '<i class="fa fa-fw fa-info-circle fa-fw"></i> 如需使用第三方缩略图，请先用对应插件托管图库。',
			'style' => 'info',
			'type' => 'submessage',
		),
		array(
			'id'	  => 'thumbnail_modus',
			'type'	=> 'radio',
			'title'   => __('缩图方式','io_setting'),
			'options' => array(
				'null'		=> __('使用原图','io_setting'),
				/* 'normal'	=> __('默认(Timthumb)缩略图','io_setting'), */
				'cos'		=> __('腾讯 COS','io_setting'),
				'oss'		=> __('阿里 OSS','io_setting'),
				'qiniu'		=> __('七牛缩略图','io_setting'),
				'upyun'		=> __('又拍缩略图','io_setting'),
			),
			'default' => 'null',
			'subtitle'	=> __('选择缩略图方式', 'io_setting'),
		),
		array( 
			'id'		 => 'tt_whitelist',
			'type'	   => 'text',
			'title'	  => __('TimThumb白名单','io_setting'),
			'after'	  => __('TimThumb截图白名单，用英语 “,” 分隔。','io_setting'),
			'default'	=> 's2.ax1x.com,iowen.cn',
			'attributes' => array(
				'style'    => 'width: 100%'
			),
			'class' => 'compact',
			'dependency' => array( 'thumbnail_modus', '==', 'normal' ),
		),
		array(
			'id'	  => 'is_cdn_url',
			'type'	=> 'switcher',
			'title'   => __('已经是图床地址','io_setting'),
			'label'   => '比如已经用图床（cdn）插件替换了地址',
			'default'	=> false,
			'class' => 'compact',
			'dependency' => array( 'thumbnail_modus', 'any', 'qiniu,upyun,cos,oss' ), 
		),
		array(
			'id'		 => 'img_cdn_url',
			'type'	   => 'text',
			'title'	  => __('图床地址','io_setting'),
			'placeholder' => 'img.iotheme.cn',
			'after'	  => __('注意：不要填写http(s)://，结尾不能有 “/”，如：img.iotheme.cn','io_setting'),
			'class' => 'compact',
			'dependency' => array( 'thumbnail_modus|is_cdn_url', 'any|==', 'qiniu,upyun,cos,oss|true' ),  
		),
		array(
			'type'		 => 'notice',
			'class'		=> 'info',
			'content'	  => __('必须填写下方 CDN 相关设置','io_setting'), 
			'dependency' => array( 'thumbnail_modus|is_cdn_url', 'any|==', 'qiniu,upyun,cos,oss|false' ), 
		),
		array(
			'type' => 'submessage',
			'content' => '<h4>CDN 设置</h4><i class="fa fa-fw fa-info-circle fa-fw"></i> 用于配置动静分离，设置CDN服务商配置，在这选项中填写好CDN域名，就会自动将站点的静态资源地址设置为CDN地址',
			'style' => 'info',
		),
		array(
			'id'	  => 'io_cdn_on',
			'type'	=> 'switcher',
			'title'   => __('启用 CDN','io_setting'),
		),
		array(
			'id'		 => 'cdn_path',
			'type'		 => 'radio',
			'title'		 => '启用 CDN 的目录',
			'options'	 => array(
				'wp-'         => 'ALL (content 和 includes)',
				'wp-content'  => 'wp-content',
				'wp-includes' => 'wp-includes',
			),
			'inline'	 => true,
			'default'    => 'wp-',
			'class'		 => 'compact',
			'dependency' => array( 'io_cdn_on', '==', 'true' ), 
		),
		//array(
		//		'id'		 => 'local_img_url',
		//		'type'	   => 'text',
		//		'title'	  => '本地图片域名',
		//		'after'	  => '<br>如果本地图片域名为独立的域名，请填写此项，<br>包含 http:// 或者 https:// ,结尾不能有 “/” 。',
		//		'dependency' => array('thumbnail_modus_normal', '!=', 'true' ),
		//),
		array(
			'id'		 => 'cdn_url',
			'type'	   => 'text',
			'title'	  => __('CDN 地址','io_setting'),
			'after'	  => __('CDN 域名，包含 http:// 或者 https:// ,结尾不能有 “/” 。','io_setting'),
			'placeholder' => 'http://',
			'class' => 'compact',
			'dependency' => array( 'io_cdn_on', '==', 'true' ),  
		),
		array(
			'id'		 => 'cdn_res',
			'type'	   => 'text',
			'title'	  => __('CDN 加速资源','io_setting'),
			'after'	  => __('需要CDN加速的资源，用 “|” 分隔。','io_setting'),
			'default'	=> 'jpg|jpeg|png|gif|js|css|ttf|woff|woff2|svg|eot',
			'class' => 'compact',
			'dependency' => array( 'io_cdn_on', '==', 'true' ),  
		),
	),
));
// 安全
CSF::createSection( $prefix, array(
	'parent'   => 'other_settings',
	'name'		=> 'safety',
	'title'	   => __('安全','io_setting'),
	'icon'		=> 'fa fa-shield',
	'fields'	  => array(
		array(
			'type'	=> 'subheading',
			'content' => __('禁止冒充管理员留言','io_setting'),
		),
		array(
				'id'		 => 'admin_name',
				'type'	   => 'text',
				'title'	  => __('管理员名称','io_setting'),
		),
		array(
				'id'		 => 'admin_email',
				'type'	   => 'text',
				'title'	  => __('管理员邮箱','io_setting'),
		),
		array(
			'id'		=> 'login_link',
			'type'	  => 'fieldset',
			'title'	 => __('修改默认登录链接','io_setting'),
			'subtitle'	  => __('启用，提示：要记住修改后的链接','io_setting'),
			'fields'	=> array(
				array(
					'id'	  => 'pass_h',
					'type'	=> 'text',
					'title'  => __('前缀','io_setting'),
					'placeholder' => 'my',
				),
				array(
					'id'	  => 'word_q',
					'type'	=> 'text',
					'title'  => __('后缀','io_setting'),
					'placeholder' => 'the',
				),
				array(
					'id'	=> 'go_link',
					'type'  => 'text',
					'title' => __('跳转网址','io_setting'),
					'default'	=> '/',
				),
				array(
					'type'	=> 'subheading',
					'content' => __('登录地址：http://域名/wp-login.php?my=the','io_setting'),
				),
			),
		),
		array(
			'id'		=> 'tcaptcha_007',
			'type'	  => 'switcher',
			'default'   => false,
			'title'	 => __('启用腾讯防水墙','io_setting'),
			'subtitle'	  => __('在登录页添加验证，提升安全性','io_setting'),
		),	
		array(
			'id'		=> 'appid_007',
			'type'	  => 'text',
			'title'	 => __('腾讯防水墙 App ID','io_setting'),
			'class' => 'compact',
			'dependency'=> array( 'tcaptcha_007', '==', 'true' ),
		),	
		array(
			'id'		=> 'appsecretkey_007',
			'type'	  => 'text',
			'title'	 => __('腾讯防水墙 App Secret Key','io_setting'),
			'class' => 'compact',
			'dependency'=> array( 'tcaptcha_007', '==', 'true' ),
		),	
		array(
			'type'	=> 'subheading',
			'content' => __('App ID 申请地址：<a href="https://007.qq.com/" target="_blank">防水墙</a>','io_setting'),
			'dependency'=> array( 'tcaptcha_007', '==', 'true' ),
		),
		array(
				'id'		 => 'login_limit',
				'type'       => 'spinner',
				'title'      => '登录失败尝试限制',
				'subtitle'	 => '尝试次数',
				'after'      => '默认5次，表示失败5次后要过10分钟才能再次尝试登录。<br>'.$tip_ico.'0为不限制次数',
				'unit'       => '次',
				'default'    => 5,
		),
		array(
				'id'		 => 'login_limit_time',
				'type'       => 'spinner',
				'title'      => ' ',
				'subtitle'	 => '登录失败多少分钟后可再次尝试',
				'after'      => '默认10分钟，表示失败5次后要过10分钟才能再次尝试登录。',
				'unit'       => '分钟',
				'default'    => 10,
				'class'      => 'compact min',
		),
	),
));
//其他
CSF::createSection( $prefix, array(
	'parent'   => 'other_settings',
	'name'		=> 'other',
	'title'	   => __('其他杂项','io_setting'),
	'icon'		=> 'fa fa-pie-chart',
	'fields'	  => array(
		array(
			'id'		 => 'lazyload',
			'title'	  => __('启用图片延迟加载','io_setting'),
			'default'	=> true,
			'type'	   => 'switcher'
		),
		array(
			'id'		 => 'wow_no',
			'title'	  => __('wow 动画特效','io_setting'),
			'type'	   => 'switcher',
			'default'	=> true,
		),
		array(
			'id'		 => 'click_fx',
			'title'	  => __('点击特效','io_setting'),
			'default'	=> false,
			'type'	   => 'switcher'
		),
        array(
            'id'         => 'iconfont_url',  
            'type'       => 'textarea',
            'title'      => __('阿里图标库地址', 'io_setting'),
            'after'       => '<h4>输入阿里图标库在线链接，可多个，一行一个地址，注意不要有空格。</h4>图标库地址：<a href="https://www.iconfont.cn/" target="_blank">--></a><br>教程地址：<a href="https://www.iotheme.cn/one-nav-yidaohangzhutishiyongaliyuntubiaodefangfa.html" target="_blank">--></a>
            <br><p><i class="fa fa-fw fa-info-circle fa-fw"></i> 阿里图标库项目的 FontClass/Symbol前缀 必须为 “<b>io-</b>”，Font Family 必须为 “<b>io</b>”，具体看上面的教程。</p>注意：项目之间的<b>图标名称</b>不能相同，<b>彩色</b>图标不支持变色。',
            'class'      => 'new',
            'attributes' => array(
                'rows' => 4,
            ),
            'default'    => '',
        ),
		array(
			'id'		 => 'io_site_open_date',
			'title'	  => __('建站日期','io_setting'),
			'after'	  => __('格式：20190707','io_setting'),
			'type'	   => 'text',
		),
		array(
			'id'		=> 'author_info_img',
			'type'	  => 'upload',
			'title'	 => __('用户中心头部图片','io_setting'),
			'add_title' => __('上传','io_setting'),
			'default'   => 'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/banner/e9HQMR.jpg',
			'preview'   => true,
		),
		array(
			'id'		 => 'random_head_img',
			'type'	   => 'textarea',
			'title'	  => __('随机头部图片','io_setting'),
			'subtitle'	   => __('缩略图、文章页随机图片','io_setting'),
			'after'	  => __('一行一个图片地址，注意不要有空格','io_setting'),
			'default'	=> 'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/1.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/2.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/3.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/4.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/5.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/6.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/7.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/8.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/9.jpg'.PHP_EOL.'https://cdn.iocdn.cc/gh/owen0o0/ioStaticResources@master/screenshots/0.jpg',
		),
	),
));

/**
 * 备份设置
 */
CSF::createSection( $prefix, array(
	'title'	=> __('备份设置','io_setting'),
	'icon'	 => 'fa fa-shield',
	'fields'   => array(
		array(
			'type'	 => 'callback',
            'class'  => 'csf-field-submessage',
			'function' => 'io_backup',
		),
		array(
			'type'	=> 'backup',
		),
	)
));
