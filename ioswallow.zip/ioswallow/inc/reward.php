<?php
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:40
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-25 19:44:00
 * @FilePath: \ioswallow\inc\reward.php
 * @Description: 
 */ 
if ( ! defined( 'ABSPATH' ) ) { exit; }

function show_reward(){
    $popupClass = $head = $qrcode = $platform = '';
    $i = 0;
    if(io_get_option('reward_wechat_qrcode')){
        $style = $class = '';
        $key= 'wechat';
        $thanks = '<p>'.__('谢谢赞赏','i_theme').'</p><p style=\'font-size: 14px\'>'.__('（微信）','i_theme').'</p>';
        $bgcolor  = '#05af4e';
        if($i > 0){
            $style = 'style="display:none;"';
        }else{
            $class = 'active';
            $popupClass = $key;
            $head = $thanks ;
        }
        $qrcode .= '<div class="qrcode-li ' . $key . '" ' . $style . '><img src="' . io_get_option('reward_wechat_qrcode') . '" /></div>';
        $platform .= '<li class="icon-' . $key . ' ' . $class . '" data-type="'.$key.'" data-bg-color="' . $bgcolor . '" data-thanks="' . $thanks . '" data-balloon="'.__('微信','i_theme').'" data-balloon-pos="up"></li>';
        $i++;
    }
    if(io_get_option('reward_alipay_qrcode')){
        $style = $class = '';
        $key= 'alipay';
        $thanks = '<p>'.__('谢谢赞赏','i_theme').'</p><p style=\'font-size: 14px\'>'.__('（支付宝）','i_theme').'</p>';
        $bgcolor  = '#00a2ea';
        if($i > 0){
            $style = 'style="display:none;"';
        }else{
            $class = 'active';
            $popupClass = $key;
            $head = $thanks ;
        }
        $qrcode .= '<div class="qrcode-li ' . $key . '" ' . $style . '><img src="' . io_get_option('reward_alipay_qrcode') . '" /></div>';
        $platform .= '<li class="icon-' . $key . ' ' . $class . '" data-type="'.$key.'" data-bg-color="' . $bgcolor . '" data-thanks="' . $thanks . '" data-balloon="'.__('支付宝','i_theme').'" data-balloon-pos="up"></li>';
        $i++;
    }
    if(io_get_option('reward_hongbao_qrcode')){
        $style = $class = '';
        $key= 'hongbao';
        $thanks = '<p>'.__('支付宝红包','i_theme').'</p><p style=\'font-size: 14px\'>'.__('（余额宝支付时可抵现）','i_theme').'</p>';
        $bgcolor  = '#dd5746';
        if($i > 0){
            $style = 'style="display:none;"';
        }else{
            $class = 'active';
            $popupClass = $key;
            $head = $thanks ;
        }
        $qrcode .= '<div class="qrcode-li ' . $key . '" ' . $style . '><img src="' . io_get_option('reward_hongbao_qrcode') . '" /></div>';
        $platform .= '<li class="icon-' . $key . ' ' . $class . '" data-type="'.$key.'" data-bg-color="' . $bgcolor . '" data-thanks="' . $thanks . '" data-balloon="'.__('红包','i_theme').'" data-balloon-pos="up"></li>';
        $i++;
    }
    //$html = '<div class="reward wow fadeInUp" data-wow-duration="1s"  data-wow-delay="0.2s"> 
    //    <p style="text-align: center;font-size: 13px;color: #828282;margin-bottom: 1px;margin-top: 14px;">' . io_get_option('reward_prompt') . '</p>
    //    <div id="reward_popup" class="' . $popupClass . ' popup"  >
    //        <div class="head">' . $head . '</div>
    //        <div class="qrcode">' . $qrcode . '</div>
    //        <ul class="platform">' . $platform . '</ul>
    //    </div>
    //    <a href="javascript:void(0);" id="reward_btn">赏</a>
    //</div>';
    $html = '
    <div class="reward">
    <div id="reward_popup" class="' . $popupClass . ' popup"  >
        <div class="head">' . $head . '</div>
        <div class="qrcode">' . $qrcode . '</div>
        <ul class="platform">' . $platform . '</ul>
    </div>
    </div>';
    echo $html;
    exit;
}
add_action('wp_ajax_nopriv_show_reward','show_reward');
add_action('wp_ajax_show_reward','show_reward');