<?php
/**
 * WordPress 接入腾讯防水墙，给网站登录加上验证功能
 * 原文地址：
 * 一为忆
 * Swallow 主题
 */

function add_login_head() {
    echo '<script src="https://ssl.captcha.qq.com/TCaptcha.js"></script>';
    echo '<style type="text/css">.login_button {line-height:38px;border-radius:3px;cursor:pointer;color:#555;background:#eee;border:2px solid #a5a5a5;font-size:14px;margin-bottom:10px;text-align:center;transition:.5s;}.login_button:hover{color:#fff;background:#444;border-color:#444;}</style>'; 
}
function add_captcha_body(){ ?>
    <input type="hidden" id="wp007_tcaptcha" name="tcaptcha_007" value="" />
    <input type="hidden" id="wp007_ticket" name="syz_ticket" value="" />
    <input type="hidden" id="wp007_randstr" name="syz_randstr" value="" />
    <div id="TencentCaptcha" data-appid="<?php echo io_get_option('appid_007') ?>" data-cbfn="callback" class="login_button"><?php _e('验证','i_theme') ?></div>
    <script>
        window.callback = function(res){
            if(res.ret === 0){
                var but = document.getElementById("TencentCaptcha");
                document.getElementById("wp007_ticket").value = res.ticket;
                document.getElementById("wp007_randstr").value = res.randstr;
                document.getElementById("wp007_tcaptcha").value = 1;
                but.style.cssText = "color:#fff;background:#4fb845;border-color:#4fb845;pointer-events:none";
                but.innerHTML =  "<?php _e('验证成功','i_theme') ?>";
            }
        }
    </script>
<?php
}

/**
 * 处理登录二次验证
 */
function validate_tcaptcha_login($user) { 
    $slide=$_POST['tcaptcha_007'];
    if($slide == ''){
        return  new WP_Error('broke', __("请先进行真人验证！！！"));
    }
    else{
        $result = validate_login($_POST['syz_ticket'],$_POST['syz_randstr']);
        if ($result['result']) {
            return $user;
        } else{
            return  new WP_Error('broke', $result['message']);
        }
    }
  
}

/**
 * 请求服务器验证
 */
function validate_login($Ticket,$Randstr){
    $AppSecretKey = io_get_option('appsecretkey_007');  
    $appid = io_get_option('appid_007');  
    $UserIP = $_SERVER["REMOTE_ADDR"]; 

    $url = "https://ssl.captcha.qq.com/ticket/verify";
    $params = array(
        "aid" => $appid,
        "AppSecretKey" => $AppSecretKey,
        "Ticket" => $Ticket,
        "Randstr" => $Randstr,
        "UserIP" => $UserIP
    );
    $paramstring = http_build_query($params);
    $content = txcurl($url,$paramstring);
    $result = json_decode($content,true);
    if($result){
        if($result['response'] == 1){
            return array(
                'result'=>1,
                'message'  => ''
            );
        }else{
            return array(
                'result'=>0,
                'message'  => $result['err_msg']
            );
        }
    }else{
        return array(
            'result'=>0,
            'message'  => __('请求失败,请再试一次！','i_theme')
        );
    }
}



add_action('login_head', 'add_login_head');
add_action('login_form','add_captcha_body');
add_filter('wp_authenticate_user',  'validate_tcaptcha_login',100,1);


/**
 * 请求接口返回内容
 * @param  string $url [请求的URL地址]
 * @param  string $params [请求的参数]
 * @param  int $ipost [是否采用POST形式]
 * @return  string
*/
function txcurl($url,$params=false,$ispost=0){
    $httpInfo = array();
    $ch = curl_init();

    curl_setopt( $ch, CURLOPT_HTTP_VERSION , CURL_HTTP_VERSION_1_1 );
    curl_setopt( $ch, CURLOPT_USERAGENT , 'JuheData' );
    curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT , 60 );
    curl_setopt( $ch, CURLOPT_TIMEOUT , 60);
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER , true );
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if( $ispost )
    {
        curl_setopt( $ch , CURLOPT_POST , true );
        curl_setopt( $ch , CURLOPT_POSTFIELDS , $params );
        curl_setopt( $ch , CURLOPT_URL , $url );
    }
    else
    {
        if($params){
            curl_setopt( $ch , CURLOPT_URL , $url.'?'.$params );
        }else{
            curl_setopt( $ch , CURLOPT_URL , $url);
        }
    }
    $response = curl_exec( $ch );
    if ($response === FALSE) {
        //echo "cURL Error: " . curl_error($ch);
        return false;
    }
    $httpCode = curl_getinfo( $ch , CURLINFO_HTTP_CODE );
    $httpInfo = array_merge( $httpInfo , curl_getinfo( $ch ) );
    curl_close( $ch );
    return $response;
}