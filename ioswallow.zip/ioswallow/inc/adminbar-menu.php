<?php
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:25
 * @LastEditors: iowen
 * @LastEditTime: 2021-08-20 10:01:02
 * @FilePath: \ioswallow\inc\adminbar-menu.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
//精简WordPress后台顶部工具栏
function my_edit_toolbar($wp_toolbar) {
	$wp_toolbar->remove_node('wp-logo'); //去掉Wordpress LOGO
	//$wp_toolbar->remove_node('site-name'); //去掉网站名称
	//$wp_toolbar->remove_node('updates'); //去掉更新提醒
	//$wp_toolbar->remove_node('comments'); //去掉评论提醒
	//$wp_toolbar->remove_node('new-content'); //去掉新建文件
	//$wp_toolbar->remove_node('top-secondary'); //用户信息
}
add_action('admin_bar_menu', 'my_edit_toolbar', 999);

//添加后台顶部工具栏菜单  
function custom_adminbar_menu( $meta = TRUE ) {  
    global $wp_admin_bar;  
        if ( !is_user_logged_in() ) { return; }  
        if ( !is_super_admin() || !is_admin_bar_showing() ) { return; }  
    $wp_admin_bar->add_menu( array(  
        'id' => 'custom_menu',  
        'title' => '<img src="'.get_theme_file_uri( '/images/setting.png').'" width="25" height="25" style="width:18px"> ' . _x( '主题设置', 'menu', 'i_theme' ),      /* 设置菜单名 */  
		'href' => '/wp-admin/admin.php?page=theme_settings'  )
	); 
    $wp_admin_bar->add_menu( array(  
        'parent' => 'custom_menu',  
        'id'     => 'custom_links',  
        'title' => __( '主题设置', 'i_theme' ),            /* 设置链接名*/  
        'href' => '/wp-admin/admin.php?page=theme_settings',      /* 设置链接地址 */  
        'meta'  => array( 'target' => '_self' ) )  
    );  
    if(io_get_option('site_map')) {
    $wp_admin_bar->add_menu( array(  
        'parent' => 'custom_menu',  
        'id'     => 'rumen',  
        'title' => __( '网站地图' , 'i_theme' ),  
        'href' => '/wp-admin/admin.php?page=theme_settings#tab=seo-%e6%8e%a8%e5%b9%bf/sitemap%e6%8e%a8%e9%80%81', 
        'meta'  => array( 'target' => '_self' ) )  
    ); }
    $wp_admin_bar->add_menu( array(  
        'parent' => 'custom_menu',  
        'id'     => 'faq',  
        'title' => __( '帮助中心' , 'i_theme' ), 
        'href' => 'https://www.iotheme.cn/help', 
        'meta'  => array( 'target' => '_blank' ) )  
    ); 
}  
add_action( 'admin_bar_menu', 'custom_adminbar_menu', 35 );
function custom_menu_css() {  
    $custom_menu_css = '<style type="text/css">  
        #wp-admin-bar-custom_menu img {vertical-align:sub} /** moves icon over */  
        #wp-admin-bar-custom_menu { width:75px; } /** sets width of custom menu */  
		#wp-admin-bar-custom_menu {width:92px;}
		.wp-first-item.wp-not-current-submenu.wp-menu-separator,.hide-if-no-customize{display: none;}
    </style>';  
    echo $custom_menu_css;  
}  
add_action( 'admin_head', 'custom_menu_css' );

