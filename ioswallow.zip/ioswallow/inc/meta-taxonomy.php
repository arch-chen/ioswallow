<?php 
/*
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:27
 * @LastEditors: iowen
 * @LastEditTime: 2021-08-20 05:38:52
 * @FilePath: \ioswallow\inc\seo.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
 

// 文章分类SEO设置
if( class_exists( 'CSF' ) ) {
    $prefix = 'category_meta'; 
  
    CSF::createTaxonomyOptions( $prefix, array(
        'taxonomy'  => 'category',
        'data_type' => 'serialize', 
    ) );

  
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => __('文章分类SEO设置（可留空）','io_setting'),
            ),
            array(
                'id'    => 'seo_title',
                'type'  => 'text',
                'title' => __('自定义标题','io_setting'),
            ),
            array(
                'id'    => 'seo_metakey',
                'type'  => 'text',
                'title' => __('设置关键词','io_setting'),
            ),
            array(
                'id'    => 'seo_desc',
                'type'  => 'textarea',
                'title' => __('自定义描述','io_setting'),
            ),

        )
    ));
}

// 文章标签SEO设置
if( class_exists( 'CSF' ) ) {
    $prefix = 'post_tag_meta'; 
  
    CSF::createTaxonomyOptions( $prefix, array(
        'taxonomy'  => 'post_tag',
        'data_type' => 'serialize', 
    ) );
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => __('文章标签SEO设置（可留空）','io_setting'),
            ),
            array(
                'id'    => 'seo_title',
                'type'  => 'text',
                'title' => __('自定义标题','io_setting'),
            ),
            array(
                'id'    => 'seo_metakey',
                'type'  => 'text',
                'title' => __('设置关键词','io_setting'),
            ),
            array(
                'id'    => 'seo_desc',
                'type'  => 'textarea',
                'title' => __('自定义描述','io_setting'),
            ),

        )
    ));
}