<?php
/*
 * @Theme Name:Swallow
 * @Theme URI:https://www.iotheme.cn/
 * @Author: iowen
 * @Author URI: https://www.iowen.cn/
 * @Date: 2021-08-07 21:18:25
 * @LastEditors: iowen
 * @LastEditTime: 2022-07-25 19:17:57
 * @FilePath: \ioswallow\inc\download.php
 * @Description: 
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $wpdb;
function io_show_down($content) {
	if(is_single() && get_post_meta(get_the_ID(), '_down_start', true)) {

		$custom_fields 		= get_post_custom();
		$password_start		= isset($custom_fields['_password_start'])?$custom_fields['_password_start'][0]:false;
		$down_name			= isset($custom_fields['_down_name'])?$custom_fields['_down_name'][0]:'';
		$file_inf			= isset($custom_fields['_file_inf'])?$custom_fields['_file_inf'][0]:'';
		$file_os			= isset($custom_fields['_file_os'])?$custom_fields['_file_os'][0]:'';
		$down_size			= isset($custom_fields['_down_size'])?$custom_fields['_down_size'][0]:'';
		$instructions		= isset($custom_fields['_instructions'])?$custom_fields['_instructions'][0]:'';
		$down_demo			= isset($custom_fields['_down_demo'])?$custom_fields['_down_demo'][0]:'';
		$official_website	= isset($custom_fields['_official_website'])?$custom_fields['_official_website'][0]:'';
		$r_baidu_password	= isset($custom_fields['_baidu_password'])?$custom_fields['_baidu_password'][0]:'';
		$r_rar_password		= isset($custom_fields['_rar_password'])?$custom_fields['_rar_password'][0]:'';
		$click_count 		= isset($custom_fields['down_count'])?$custom_fields['down_count'][0]:0;
		
		$click_count_on = $rr_password = $official_content = $demo_content = '';


		if($official_website) {
			$official_content = '<a class="m-0 mb-2 mr-2" rel="external nofollow"   href="'.go_to($official_website).'" target="_blank" title="'.__('官网地址','i_theme').'"><i class="iconfont icon-home" ></i>'.__('官网地址','i_theme').'</a>';
		}

		if($down_demo) {
			$demo_content = '<a class="yanshibtn m-0 mb-2 mr-2" rel="external nofollow"   href="'.home_url().'/preview/?id='.get_the_ID().'" target="_blank" title="'.__('查看演示','i_theme').'"><i class="iconfont icon-eye" ></i>'.__('查看演示','i_theme').'</a>';
		}
		if($password_start) {
			if($r_rar_password){$r_rar_password='<strong>'.__('解压密码：','i_theme').'</strong><i class="iconfont icon-explain"></i>'.$r_rar_password;}
			if($r_baidu_password){$r_baidu_password='<strong>'.__('下载密码：','i_theme').'</strong><i class="iconfont icon-explain"></i>'.$r_baidu_password;}
			$rr_password .=  '[pass]<span>'.$r_rar_password.'</span><span>'.$r_baidu_password.'</span>[/pass]';
		}
		
		$click_count_on .=  '<span><strong>'. sprintf(__('文件下载：</strong>%s 次', 'i_theme'), $click_count).'</span>';
		
		if($down_name) {
			$down_name = '<strong>'.__('资源名称：','i_theme').'</strong>'. $down_name;
		}
		
		if($file_inf) {
			$file_inf = '<strong>'.__('资源版本：','i_theme').'</strong>'. $file_inf;
		}
	
		if($file_os) {
			$file_os = '<strong>'.__('应用平台：','i_theme').'</strong>'. $file_os;
		}
	
		if($down_size) {
			$down_size = '<strong>'.__('资源大小：','i_theme').'</strong>'. $down_size;
		}
	
		if($instructions) {
			$instructions = '<strong>'.__('使用说明：','i_theme').'</strong>'. $instructions;
		}

		$content .= '
		<div class="down-form">
			<i class="iconfont icon-download"></i>
			<fieldset>
				<legend>'.__('下载信息','i_theme').'</legend>
				<span class="down-form-inf mb-2">
					<span>'.$down_name.'</span>
					<span>'.$file_os.'</span>
					<span>'.$file_inf.'</span>
					<span>'.$down_size.'</span>
					'.$click_count_on.'
					<span class="pass"> '.$rr_password.'</span>
					<span>'.$instructions.'</span>
				</span>
				<span class="down">
					<a class="m-0 mb-2 mr-2" title="'.__('下载地址','i_theme').'" href="'.home_url().'/down/?id='.get_the_ID().'" rel="external nofollow" target="_blank"><i class="iconfont icon-download"></i>'.__('下载地址','i_theme').'</a>
				</span>
				<span class="down">
					'.$demo_content.'
				</span>
				<span class="down">
					'.$official_content.'
				</span>
			</fieldset>
		</div>';
	}
	return $content;
}
add_action('the_content','io_show_down');
