<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action('wp_ajax_nopriv_create-bigger-image','get_bigger_img');
add_action('wp_ajax_create-bigger-image','get_bigger_img');


function substr_ext($str, $start = 0, $length=120, $charset = 'utf-8', $suffix = ''){
	if (function_exists('mb_substr')) {
		return mb_substr($str, $start, $length, $charset) . $suffix;
	}
	if (function_exists('iconv_substr')) {
		return iconv_substr($str, $start, $length, $charset) . $suffix;
	}
	$re['utf-8'] = '/[-]|[?-?][?-?]|[?-?][?-?]{2}|[?-?][?-?]{3}/';
	$re['gb2312'] = '/[-]|[?-?][?-?]/';
	$re['gbk'] = '/[-]|[?-?][@-?]/';
	$re['big5'] = '/[-]|[?-?]([@-~]|?-?])/';
	preg_match_all($re[$charset], $str, $match);
	$slice = join('', array_slice($match[0], $start, $length));
	return $slice . $suffix;
}

function io_str_encode($string){
	return $string;
}
/**
 * 绘制多行文本 
 * @param resource|GdImage $card 画布
 * @param array $pos
 * @param string $str 内容
 * @param bool $iswrite 直接写入
 * @param string $font_file 字体
 * @return int 行数
 */
function draw_txt_to($card, $pos, $str, $iswrite, $font_file){
	$_str_h = $pos['top'];
	$fontsize = $pos['fontsize'];
	$width = $pos['width'];
	$margin_lift = $pos['left'];
	$hang_size = $pos['hang_size'];
	$temp_string = '';
	$tp = 0;
	$font_color = imagecolorallocate($card, $pos['color'][0], $pos['color'][1], $pos['color'][2]);
	$i = 0;
	while ($i < mb_strlen($str)) {
		$box = imagettfbbox($fontsize, 0, $font_file, io_str_encode($temp_string));
		$_string_length = $box[2] - $box[0];
		$temptext = mb_substr($str, $i, 1);
		$temp = imagettfbbox($fontsize, 0, $font_file, io_str_encode($temptext));
		if ($_string_length + $temp[2] - $temp[0] < $width) {
			$temp_string .= mb_substr($str, $i, 1);
			if ($i == mb_strlen($str) - 1) {
				$_str_h = $_str_h + $hang_size;
				$_str_h += $hang_size;
				$tp = $tp + 1;
				if ($iswrite) {
					imagettftext($card, $fontsize, 0, $margin_lift, $_str_h, $font_color, $font_file, io_str_encode($temp_string));
				}
			}
		} else {
			$texts = mb_substr($str, $i, 1);
			$isfuhao = preg_match('/[\\pP]/u', $texts) ? true : false;
			if ($isfuhao) {
				$temp_string .= $texts;
				$f = mb_substr($str, $i + 1, 1);
				$fh = preg_match('/[\\pP]/u', $f) ? true : false;
				if ($fh) {
					$temp_string .= $f;
					$i = $i + 1;
				}
			} else {
				$i = $i + -1;
			}
			$tmp_str_len = mb_strlen($temp_string);
			$s = mb_substr($temp_string, $tmp_str_len - 1, 1);
			if (is_firstfuhao($s)) {
				$temp_string = rtrim($temp_string, $s);
				$i = $i + -1;
			}
			$_str_h = $_str_h + $hang_size;
			$_str_h += $hang_size;
			$tp = $tp + 1;
			if ($iswrite) {
				imagettftext($card, $fontsize, 0, $margin_lift, $_str_h, $font_color, $font_file, io_str_encode($temp_string));
			}
			$temp_string = '';
		}
		$i = $i + 1;
	}
	return $tp ;//* $hang_size;
}

function is_firstfuhao($str){
	$fuhaos = array('0' => '"', '1' => '“', '2' => '\'', '3' => '<', '4' => '《');
	return in_array($str, $fuhaos);
}

/**
 * 裁剪图像
 * @param string $source_path
 * @param string $target_width
 * @param string $target_height
 */
function imageCropper($source_path, $target_width, $target_height){
	$source			= get_url_img($source_path);
	$source_info	= getimagesizefromstring($source);
	$source_width	= $source_info[0];
	$source_height	= $source_info[1];
	$source_mime	= $source_info['mime'];
	$source_ratio	= $source_height / $source_width;
	$target_ratio	= $target_height / $target_width;
	if ($source_ratio > $target_ratio){
	  	// image-to-height
		$cropped_width = $source_width;
		$cropped_height = $source_width * $target_ratio;
		$source_x = 0;
		$source_y = ($source_height - $cropped_height) / 2;
	}elseif ($source_ratio < $target_ratio){
	  	// image-to-widht
		$cropped_width = $source_height / $target_ratio;
		$cropped_height = $source_height;
		$source_x = ($source_width - $cropped_width) / 2;
		$source_y = 0;
	}else{
	  	// image-size-ok
		$cropped_width = $source_width;
		$cropped_height = $source_height;
		$source_x = 0;
		$source_y = 0;
	}
	$source_image = imagecreatefromstring($source);
	switch ($source_mime) {
		case 'image/jpeg':
			//$source_image = imagecreatefromjpeg($source_path);
			break;
		case 'image/png':
			//$source_image = imagecreatefrompng($source_path);
			imagealphablending( $source_image, true );
			imagesavealpha( $source_image, true );
			break;
		case 'image/gif':
			//$source_image = imagecreatefromgif($source_path);
			break;
		default:
	}

	$target_image  = imagecreatetruecolor($target_width, $target_height);
	// 为图像创建新的透明颜色
	$target_colour = imagecolorallocatealpha($target_image, 0, 0, 0, 127);
	// 用透明颜色填充新图像的背景。
	imagefill($target_image, 0, 0, $target_colour);

	// 恢复透明度混合
	imagesavealpha($target_image,true);
	// 裁剪 缩放
	imagecopyresampled($target_image, $source_image, 0, 0, $source_x, $source_y, $target_width, $target_height, $cropped_width, $cropped_height);
	return $target_image;
}
/**
 * 生成封面
 * 
 * @param int $post_id
 * @param array $date
 * @param string $title
 * @param string $content
 * @param string $head_img
 * @param string $qrcode_img
 * @return string
 */
function create_bigger_image($post_id,$date,$title,$content,$head_img,$qrcode_img=null){
	$im 				= imagecreatetruecolor(800,1360);	  //设置海报整体的宽高
	$white 				= imagecolorallocate($im,255,255,255);	// 海报背景色
	$gray 				= imagecolorallocate($im,200,200,200);	 // 海报水平图文分割线颜色
	$red 				= imagecolorallocate($im,240,66,66);	 // 海报水平图文分割线颜色
	$foot_text_color 	= imagecolorallocate($im,153,153,153);	// 海报左下角文字（网站副标题）颜色
	$black 				= imagecolorallocate($im,0,0,0);	  // 设置偏移标题的字体颜色
	$date_back_color	= imagecolorallocatealpha($im,10,10,10,50);
	$english_font 		= get_theme_file_path('/css/fonts/Montserrat-Regular.ttf');	   // 海报中用到的英文字体（图像日期）
	$chinese_font 		= get_theme_file_path('/css/fonts/huakang-l.ttf');	   // 海报中用到的中文字体（文章标题）
	$chinese_font_2 	= $chinese_font;	   // 海报中用到的中文字体2（文章摘要/网站副标题）
	imagefill($im,0,0,$white);	  //设置海报底色填充
	$head_img 			= imageCropper($head_img,800,650);// 海报头部图片宽高尺寸
	imagecopy($im,$head_img,0,0,0,0,800,650);	  // 海报头部图片框宽高尺寸
	$day 				= trim($date['day']);		// 获取海报中显示的文章发布日期（天）
	$day_width 			= imagettfbbox(80,0,$english_font,$day);	  // 计算并返回一个包围着 TrueType 文本范围的虚拟方框的像素大小（字体大小,旋转角度，字体文件，文本字符）
	$day_width 			= abs($day_width[2]-$day_width[0]);
	$year 				= trim($date['year']);	  // 获取海报中显示的文章发布日期（年）
	$year_width 		= imagettfbbox(24,0,$english_font,$year);	  // 计算并返回一个包围着 TrueType 文本范围的虚拟方框的像素大小（字体大小,旋转角度，字体文件，文本字符）
	$year_width 		= abs($year_width[2]-$year_width[0]);
	$day_left 			= ($year_width-$day_width)/4.0;		  // 海报头部图片悬浮日期（天）距离左侧边缘
	imagefilledrectangle($im, 35, 430, 65+$year_width, 610, $date_back_color);
	imagettftext($im,80,0,50+$day_left,530,$white,$english_font,$day);	  // 海报头部图片中绘制日期（天）（源图像，字体大小，旋转角度，X轴坐标，Y轴坐标，字体颜色，字体文件，文本字符）
	imageline($im,50,550,50+$year_width,550,$white);	  // 海报头部图片中绘制日期间隔线的属性
	imagettftext($im,24,0,50,590,$white,$english_font,$year);	  // 海报头部图片中绘制日期（年）（源图像，字体大小，旋转角度，X轴坐标，Y轴坐标，字体颜色，字体文件，文本字符）
	$title 				= io_str_encode($title);
	$title_conf 		= array('color'=>array(0,0,0),'fontsize'=>28,'width'=>680,'left'=>60,'top'=>660,'hang_size'=>24);
	$title_conf2 		= array('color'=>array(0,0,0),'fontsize'=>28,'width'=>680,'left'=>61,'top'=>660,'hang_size'=>24);
 	$rows 				= draw_txt_to($im,$title_conf ,$title,true,$chinese_font);	 // 在海报上绘制文章标题 
 	draw_txt_to($im,$title_conf2 ,$title,true,$chinese_font); // 加粗标题
	$des_conf 			= array('color'=>array(99,99,99),'fontsize'=>20,'width'=>680,'left'=>60,'top'=>(700+($rows*48)),'hang_size'=>18);
	draw_txt_to($im,$des_conf,$content,true,$chinese_font_2);	// 在海报上绘制文章摘要 
	//输出内容换行 

	//文章摘要下方间隔线条设置（源图像，X1坐标，Y1坐标，X2坐标，Y2坐标，线条颜色）
	$line_style = array($gray, $gray, $gray, $gray, $gray, $white, $white, $white, $white);
	imagesetstyle($im, $line_style);
	imageline($im,0,1130,800,1130,IMG_COLOR_STYLED);

	// 获取海报底部网站描述文字（网站副标题）
	$foot_text	= io_str_encode(io_get_option('poster_desc',get_bloginfo('description')));
	// 获取海报底部 Logo 文件
	$logo_img	= io_get_option('poster_logo',io_get_option('logo',get_theme_file_uri('/images/logo.png')));
	$logo_img	= imageCropper($logo_img,240,50);
	
	$foot_text_width = imagettfbbox(19,0,$chinese_font,$foot_text);//（字体大小,旋转角度，字体文件，文本字符）
	$foot_text_width = abs($foot_text_width[2]-$foot_text_width[0]);
	// 判断海报中是否生成二维码图片
	if($qrcode_img){
		$foot_text_left = 60; //200-$foot_text_width/2;80
		imagecopy($im,$logo_img,60,1190,0,0,240,50);
		imagettftext($im,19,0,$foot_text_left,1300,$foot_text_color,$chinese_font_2,$foot_text); // 网站描述文字（副标题）（源图像，字体大小，旋转角度，X轴坐标，Y轴坐标，字体颜色，字体文件，文本字符）
		$qrcode_str 	= get_url_img($qrcode_img);
		$qrcode_size 	= getimagesizefromstring($qrcode_str);
		$qrcode_img 	= imagecreatefromstring($qrcode_str);
		imagecopyresized($im,$qrcode_img,565,1150,0,0,190,190,$qrcode_size[0],$qrcode_size[1]);	// 复制并重定义二维码尺寸（源图像，目标图像，源X轴，源Y轴，目标X轴，目标Y轴，宽度，高度）
	}else{
		$foot_text_left = 400-$foot_text_width/2;
		imagecopy($im,$logo_img,400-240/2,1190,0,0,240,50);
		imagettftext($im,19,0,$foot_text_left,1300,$foot_text_color,$chinese_font_2,$foot_text);
	}
	// 上传生成的海报图片至指定文件夹
	$upload_dir = wp_upload_dir();
	$poster_dir = $upload_dir['basedir'].'/posterimg';
	if (!is_dir($poster_dir)){
		wp_mkdir_p($poster_dir);
	}	
	$filename = '/poster-'.$post_id.'.png';
	$file = $poster_dir.$filename;
	imagepng($im,$file);
	$src = $upload_dir['baseurl'].'/posterimg'.$filename;
	error_reporting(0);
	imagedestroy($im);
	if(is_wp_error($src)){
		return false;
	}
	return $src;
}

function trim_all($str){
	$charlist = array(" ","　","\t","\n","\r");
	return str_replace($charlist, '', $str);  
}
/**
 * @description: 
 * @param *
 * @return *
 */
function get_bigger_img(){
	$post_id = (int)sanitize_key($_POST['id']);
	if(wp_verify_nonce($_POST['nonce'],'mi-create-bigger-image-'.$post_id)){
		if($result = get_post_meta($post_id,'_bigger_cover',true)){
			$cover_share	= unserialize(base64_decode(get_post_meta($post_id,'_bigger_cover_share',true)));
			$title			= get_the_title($post_id);
			$msg			= show_poster($result,$cover_share,$title);
		} else {
			$date 					= array('day'=>get_the_time('d',$post_id),'year'=>get_the_time('Y/m',$post_id));
			$post_title 			= get_the_title($post_id);
			$title 					= substr_ext($post_title,0,50,'utf-8','');
			$post 					= get_post($post_id);
			$content 				= $post->post_excerpt ? $post->post_excerpt : $post->post_content;
			$content 				= trim_all(substr_ext(strip_tags(strip_shortcodes($content)),0,120,'utf-8','...'));
			$share_content 			= trim_all(substr_ext(strip_tags(strip_shortcodes($content)),0,80,'utf-8','...'));
			$share_content_title 	= '「'.urlencode($post_title).'」'. $share_content;
			$head_img 				= io_theme_get_thumb($post);
			$qrcode_img 			= io_get_option('share_poster_img_qrcode')? get_theme_file_uri('/inc/qr/qrcode.php?data='.get_the_permalink($post_id)):NULL;
			$result 				= create_bigger_image($post_id,$date,$title,$content,$head_img,$qrcode_img);
			if($result){
				update_post_meta($post_id,'_bigger_cover',$result);
				$pic = '&pic='.urlencode($result);
				$share_link_weibo 	= sprintf('https://service.weibo.com/share/share.php?url=%s&type=button&language=zh_cn&searchPic=true%s&title=%s',urlencode(get_the_permalink($post_id)),$pic,$share_content_title);
				$share_link_qzone 	= sprintf('https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=%s&title=%s&pics=%s&summary=%s',urlencode(get_the_permalink($post_id)),$post_title,urlencode($result),$share_content);
				$share_link_qq 		= sprintf('https://connect.qq.com/widget/shareqq/index.html?url=%s&title=%s&pics=%s&summary=%s',urlencode(get_the_permalink($post_id)),$post_title,urlencode($result),$share_content);
				$share_link_douban 	= sprintf('https://www.douban.com/share/service?href=%s&name=%s&text=%s&image=%s',urlencode(get_the_permalink($post_id)),$post_title,$share_content,urlencode($result));

				$cover_share = array(
					'weibo' 	=> $share_link_weibo,
					'qzone' 	=> $share_link_qzone,
					'qq' 		=> $share_link_qq,
					'douban' 	=> $share_link_douban,
				);
				update_post_meta($post_id,'_bigger_cover_share',base64_encode(serialize($cover_share)));
				$msg = show_poster($result,$cover_share,$post_title);
			}else{
				$msg = array('s'=>404,'m'=>__('封面生成失败，请稍后再试！','i_theme'));
			}
		}
	}else{
		$msg = array('s'=>404,'m'=>__('图片消失啦~请联系管理员解决此问题！','i_theme'));
	}
	echo json_encode($msg);
	exit(0);
}

/**
 * 输出海报
 * @uses json_encode()
 * @param string $result 海报url地址
 * @param array $share_link 分享内容
 * @param string $title			 标题
 * @return array 
 */
function show_poster($result,$share_link,$title){
	$msg=array(
		's'		=> 200,
		'html'	=> '<div class="cover-image"><img src="'.$result.'"></div>
<div class="cover-share">
	<a class="weibo" href="'.$share_link['douban'].'" target="_blank" data-balloon="'.__('分享到豆瓣','i_theme').'" data-balloon-pos="up" ><i class="iconfont icon-douban"></i></a>
	<a class="weibo" href="'.$share_link['weibo'].'" target="_blank" data-balloon="'.__('分享到微博','i_theme').'" data-balloon-pos="up"><i class="iconfont icon-weibo"></i></a>
	<a class="weibo" href="'.$share_link['qzone'].'" target="_blank" data-balloon="'.__('分享到空间','i_theme').'" data-balloon-pos="up"><i class="iconfont icon-qzone"></i></a>
	<a class="qq" href="'.$share_link['qq'].'" target="_blank" data-balloon="'.__('分享到 QQ','i_theme').'" data-balloon-pos="up"><i class="iconfont icon-qq"></i></a>		
	<a href="'.$result.'" download="'.$title.'.png" data-balloon="'.__('下载封面','i_theme').'" data-balloon-pos="up"><i class="iconfont icon-download"></i></a>
</div>
<div class="cover-text">'.__('分享朋友圈请先下载海报','i_theme').'</div>'
	);
	return $msg;
}
function get_url_img($url){
	$url = preg_replace('/ /', '%20', $url);
	if (function_exists('curl_init')) {
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_TIMEOUT, 20);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false );
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, 0);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
		$curlResult = curl_exec($curl);

		if ($curlResult === false) {
			$msg = array('code' => 404, 'msg' => curl_error($curl),'img'=>$url);
			exit(json_encode($msg));
		}

		curl_close($curl);
		return $curlResult;
	} else {
		$context = stream_context_create(['http' => ['timeout' => 20]]);
		$img     = @file_get_contents($url, false, $context);

		if ($img === false) {
			$err    = error_get_last();
			$errMsg = isset($err['message']) ? $err['message'] : $err;
			$msg    = array('code' => 404, 'msg' => $errMsg,'img'=>$url);
			exit(json_encode($msg));
		}

		return $img;
	}
}
