<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
//前端Ajax合集

//home_post_list

function io_home_post_list_ajax(){
	$page = esc_sql($_POST['page']);
	$type = esc_sql($_POST['type']);
	$cat  = isset($_POST['tabcat']) ? sanitize_text_field($_POST['tabcat']) : '-1';
	$args = array(
		'paged'               => $page,
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => true,
		//'post__not_in' => get_option( 'sticky_posts' ),

	);
	if ($cat != '-1') {
		$args['cat'] = $cat;
	}
	$category_posts = new WP_Query($args);

	if ($category_posts->have_posts()) {
		while ($category_posts->have_posts()):
			$category_posts->the_post();
            io_get_post_list($type);
		endwhile;
	} else {
		echo 0;
	}
	wp_reset_postdata();
	exit();
}
add_action( 'wp_ajax_home_post_list' , 'io_home_post_list_ajax' );
add_action( 'wp_ajax_nopriv_home_post_list' , 'io_home_post_list_ajax' );


//提交友情链接 
function io_submit_link()
{
    if (isset($_COOKIE['io_links_submit_time'])) {
        echo (json_encode(array('status' => 0, 'msg' =>  __('操作过于频繁，请稍候再试','i_theme'))));
        exit(); 
    }
    if (empty($_POST['link_name'])) { 
        echo (json_encode(array('status' => 0, 'msg' =>  __('请填写链接名称','i_theme'))));
        exit(); 
    }
    if (empty($_POST['link_url'])) {
        echo (json_encode(array('status' => 0, 'msg' =>  __('请填写链接地址','i_theme'))));
        exit(); 
    }
    $linkdata = array(
        'link_name'   => esc_attr($_POST['link_name']),
        'link_url'    => esc_url($_POST['link_url']),
        'link_description' => !empty($_POST['link_description']) ? esc_attr($_POST['link_description']) : '',
        'link_image' => !empty($_POST['link_image']) ? esc_attr($_POST['link_image']) : '',
        'link_target' => "_blank",
        'link_visible' => 'N'// 表示链接默认不可见
    );
    $links_id = wp_insert_link($linkdata);
    if (is_wp_error($links_id)) {
        echo (json_encode(array('status' => 0, 'msg' => $links_id->get_error_message())));
        exit();  
    }
    //设置浏览器缓存限制提交的间隔时间
    $expire = time() + 30;
    setcookie('io_links_submit_time', time(), $expire, '/', '', false);

    /**添加执行挂钩 */
    do_action('io_ajax_add_links_submit_success', $_POST);
	echo (json_encode(array('status' => 1, 'msg' => __('提交成功，等待管理员处理','i_theme')))); 
    exit();
}
add_action('wp_ajax_nopriv_io_submit_link', 'io_submit_link');
add_action('wp_ajax_io_submit_link', 'io_submit_link');


//点赞按钮
function iowen_like_button($post_id){	
	$like_count	= get_post_meta($post_id, '_like_count', true) ?: '0';
	$liked		= isset($_COOKIE['liked_' . $post_id]) ? 'liked' : '';
	echo '<div class="post-action text-center mt-4 mt-lg-5 pb-4"><a href="javascript:;" data-id="'.$post_id.'" class="like btn vc-theme btn-primary '.$liked.'"><i class="iconfont icon-like"></i> 赞(<span class="count">'.$like_count.'</span>)</a></div>';
}
function iowen_like_button_vertical($post_id){	
	$like_count	= get_post_meta($post_id, '_like_count', true) ?: '0';
	$liked		= isset($_COOKIE['liked_' . $post_id]) ? 'liked' : '';
	echo '<li class="py-1"><a href="javascript:;" data-id="'.$post_id.'" class="like btn btn-light w-40 p-0 rounded-circle button-fx '.$liked.'"><i class="iconfont icon-like"></i><span class="count">'.$like_count.'</span></a></li>';
}
function iowen_like_button_shoushou($post_id){	
	$like_count	= get_post_meta($post_id, '_like_count', true) ?: '0';
	$liked		= isset($_COOKIE['liked_' . $post_id]) ? 'liked' : '';
	echo '<a href="javascript:;" data-id="'.$post_id.'" class="like ss-favorite '.$liked.'"><i class="iconfont icon-like"></i><span class="count">'.$like_count.'</span></a>';
}

//点赞
function iowen_like_ajax_handler(){  
	global $wpdb, $post;  
	if($post_id = $_POST["post_id"]){
		$like_count = get_post_meta($post_id, '_like_count', true);  

		$expire = time() + 99999999;  
		$domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost  

		setcookie('liked_' . $post_id, $post_id, $expire, '/', $domain, false);  
		if (!$like_count || !is_numeric($like_count)){
			update_post_meta($post_id, '_like_count', 1);
		}else{
			update_post_meta($post_id, '_like_count', ($like_count + 1));
		};  

		echo get_post_meta($post_id, '_like_count', true); 
	}
	exit;  
}
add_action('wp_ajax_nopriv_post_like', 'iowen_like_ajax_handler');  
add_action('wp_ajax_post_like', 'iowen_like_ajax_handler');

//下载量
add_action( 'wp_ajax_down_count', 'io_add_down_count' );
add_action( 'wp_ajax_nopriv_down_count', 'io_add_down_count' );
function io_add_down_count() {
	if( empty( $_POST['post_id'] ) )
		return;

	$post_id =  (int) sanitize_key( $_POST['post_id'] );
	if( $post_id > 0 ) {
		$down_count = get_post_meta($post_id, 'down_count', true);  
		if (!$down_count || !is_numeric($down_count)){
			$down_count = 0;
		}
		update_post_meta($post_id, 'down_count', ($down_count + 1));
		echo $down_count+1;
		exit();
	}
}

//显示模式切换
function iowen_switch_dark_mode(){	
	$mode = $_POST["mode_toggle"];
	$expire = time() + 3600 * 24 * 30;  
	$domain = ($_SERVER['HTTP_HOST'] != 'localhost') ? $_SERVER['HTTP_HOST'] : false; // make cookies work with localhost  
	setcookie('io_night_mode', $mode, $expire, '/', $domain, false);  
	exit; 
}
add_action('wp_ajax_nopriv_switch_dark_mode', 'iowen_switch_dark_mode');  
add_action('wp_ajax_switch_dark_mode', 'iowen_switch_dark_mode');

//search_hot_post
function io_search_hot_post_ajax(){
	echo io_get_hot_posts();
	exit; 
}
add_action('wp_ajax_nopriv_search_hot_post', 'io_search_hot_post_ajax');  
add_action('wp_ajax_search_hot_post', 'io_search_hot_post_ajax');


//编辑器上传图片
function io_ajax_img_upload(){
    $file_id = 'file';
    if (empty($_FILES[$file_id])) {
        io_error(array('status' => 2,'msg' =>__('上传信息错误，请重新选择文件','i_theme')));
    }

    if (!wp_verify_nonce($_POST['_wpnonce'],'file_upload_img')){
        io_error('{"status":2,"msg":"'.__('对不起!您没有通过安全检查','i_theme').'"}');
    } 

    $max_size = io_get_option('upload_img_size', 256);
    if(0==$max_size || !io_get_option('comm-up-img', false)){
        io_error(array('status' => 2,'msg' =>__('图片上传功能已关闭。','i_theme')));
    }
    //文件类型判断
    if (!stristr($_FILES[$file_id]['type'], 'image')) {
        io_error(array('status' => 2,'msg' =>__('文件不属于图片格式','i_theme')));
    }

    //文件大小判断
    if ($_FILES[$file_id]['size'] > $max_size * 1024) {
        io_error(array('status' => 2,'msg' => sprintf(__('图片大小不能超过 %s kb','i_theme'),$max_size)));
    }
    //开始上传
    $_img = IOTOOLS::addImg($_FILES[$file_id],$file_id);
    if (!empty($_img['id'])) {
        io_error(array('status' => 1,'src' => $_img['src'], 'img_id' => $_img['id'],'msg' =>__('上传成功！','i_theme')));
    }

    io_error(array('status' => 4,'msg' =>__('上传失败！','i_theme')));
}
add_action('wp_ajax_edit_file_upload', 'io_ajax_img_upload');
add_action('wp_ajax_nopriv_edit_file_upload', 'io_ajax_img_upload');

/**
 * 输出提示
 * @description: 
 * @param array|string $errMsg 1 success 2 info 3 warning 4 danger
 * @param bool $err 错误
 * @param int $cache 缓存时间，分钟
 * @return null
 */
function io_error($errMsg, $err=false, $cache = 0) {
    if($err){
        header('HTTP/1.0 500 Internal Server Error');
    }
    header("Content-type:application/json;character=utf-8");
    if($cache>0){
        header("Cache-Control: public"); 
        header("Pragma: cache"); 
        $offset = 60*$cache;  
        $ExpStr = "Expires: ".gmdate("D, d M Y H:i:s", time() + $offset)." GMT"; 
        header($ExpStr); 
    }
    if(is_array($errMsg))
        echo json_encode($errMsg);
    else
        echo $errMsg;
    exit;
} 